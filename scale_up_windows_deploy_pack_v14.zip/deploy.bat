@echo off
setlocal EnableExtensions EnableDelayedExpansion
title Scale Up - Windows Deployment
color 0A

echo.
echo  ===================================================
echo    Scale Up - Windows Desktop Build
echo    Deployment Pack v14
echo  ===================================================
echo.

:: ── Paths ─────────────────────────────────────────────────────
set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "DEPLOY_DIR=%ROOT%\deploy"
set "STATE_DIR=%ROOT%\runtime\state"
set "LOG=%ROOT%\runtime\logs\deploy.log"

if not exist "%ROOT%\runtime\logs"     mkdir "%ROOT%\runtime\logs"
if not exist "%ROOT%\runtime\state"    mkdir "%ROOT%\runtime\state"
if not exist "%ROOT%\runtime\artifacts" mkdir "%ROOT%\runtime\artifacts"
if not exist "%ROOT%\runtime\settings" mkdir "%ROOT%\runtime\settings"
if not exist "%STATE_DIR%"             mkdir "%STATE_DIR%"

echo.>>"%LOG%"
echo =================================================>>"%LOG%"
echo [%DATE% %TIME%] Scale Up v14 deploy start>>"%LOG%"
echo  [..] Log: %LOG%

:: ── Admin check ───────────────────────────────────────────────
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" set "PS=powershell"
"%PS%" -ExecutionPolicy Bypass -NoProfile -Command ^
  "if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { exit 1 }"
if %errorlevel% neq 0 (
    echo  [!!] Admin required. Elevating...
    "%PS%" -ExecutionPolicy Bypass -Command "Start-Process cmd -ArgumentList '/c \"%~f0\" %*' -Verb RunAs"
    exit /b
)
echo  [OK] Running as Administrator

:: ── Verify deploy folder ──────────────────────────────────────
if not exist "%DEPLOY_DIR%\utils.py" (
    echo  [FATAL] deploy\utils.py not found. Pack is incomplete.
    echo  [FATAL] deploy\utils.py not found>>"%LOG%"
    pause & exit /b 1
)

:: ═════════════════════════════════════════════════════════════
::  FIND OR INSTALL PYTHON
::
::  Adapted from BoreholeIQ v2 R27 — battle-tested on fresh
::  Windows machines. NEVER uses bare 'python', 'py -3.12', or
::  multi-token PYTHON_EXE variables. Always resolves to a full
::  absolute path to a real python.exe before proceeding.
::
::  Root cause of v8 crash: winget installed 9NQ7512CXL7T (the
::  Python Install Manager / py launcher), then PYTHON_EXE was
::  set to "py -3.12" (two tokens). BAT then ran:
::    py -3.12 -m deploy.stage1_prereqs --root ...
::  which fails because -m requires the CWD to be the pack root
::  AND deploy/ to be an importable package. This new pattern
::  avoids ALL of that by calling stages as direct file paths.
:: ═════════════════════════════════════════════════════════════

set "PY="

:: Phase 1: Remove Windows Store Python stubs
:: They return exit 9009 and are the #1 cause of fresh-machine
:: Python detection failures.
del "%LOCALAPPDATA%\Microsoft\WindowsApps\python.exe"  >nul 2>&1
del "%LOCALAPPDATA%\Microsoft\WindowsApps\python3.exe" >nul 2>&1

:: Phase 2: Check all known real install locations, newest first
for %%P in (
    "C:\Program Files\Python314\python.exe"
    "C:\Program Files\Python313\python.exe"
    "C:\Program Files\Python312\python.exe"
    "C:\Program Files\Python311\python.exe"
    "C:\Program Files\Python310\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    "C:\Python314\python.exe"
    "C:\Python313\python.exe"
    "C:\Python312\python.exe"
    "C:\Python311\python.exe"
    "C:\Python310\python.exe"
) do (
    if exist %%P (
        set "PY=%%~P"
        goto :py_found
    )
)

:: Phase 3: 'where' scan — skip WindowsApps stubs
for /f "tokens=*" %%i in ('where python.exe 2^>nul') do (
    echo %%i | findstr /i "WindowsApps" >nul
    if errorlevel 1 (
        "%%i" -c "import sys" >nul 2>&1
        if !errorlevel! equ 0 (
            set "PY=%%i"
            goto :py_found
        )
    )
)

:: Phase 4: py launcher — resolve to the actual exe, not "py -3.x"
where py.exe >nul 2>&1
if %errorlevel% equ 0 (
    for /f "tokens=*" %%i in ('py -3 -c "import sys; print(sys.executable)" 2^>nul') do (
        if exist "%%i" (
            set "PY=%%i"
            goto :py_found
        )
    )
)

:: Phase 5: Install Python via winget (real package, not launcher)
:: Use Python.Python.3.12 — the actual interpreter, not 9NQ7512CXL7T
echo  [..] Python not found. Installing via winget...
echo  [..] Installing Python 3.12 via winget>>"%LOG%"
winget install --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements >nul 2>&1

:: Refresh SYSTEM PATH from registry after install
for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "PATH=%%B"

for %%P in (
    "C:\Program Files\Python314\python.exe"
    "C:\Program Files\Python313\python.exe"
    "C:\Program Files\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "C:\Python314\python.exe"
    "C:\Python313\python.exe"
    "C:\Python312\python.exe"
) do (
    if exist %%P (
        set "PY=%%~P"
        goto :py_found
    )
)

:: Phase 6: Direct download fallback
echo  [..] winget failed. Trying direct download...
echo  [..] winget failed, trying direct download>>"%LOG%"
for %%V in (3.12.10 3.12.9 3.12.7) do (
    set "PY_URL=https://www.python.org/ftp/python/%%V/python-%%V-amd64.exe"
    set "PY_INS=%TEMP%\python-%%V-amd64.exe"
    "%PS%" -ExecutionPolicy Bypass -NoProfile -Command ^
        "Invoke-WebRequest -Uri '!PY_URL!' -OutFile '!PY_INS!' -UseBasicParsing" >nul 2>&1
    if exist "!PY_INS!" (
        echo  [..] Installing Python %%V...
        "!PY_INS!" /quiet InstallAllUsers=1 PrependPath=1 Include_pip=1
        timeout /t 5 /nobreak >nul
        for /f "tokens=2*" %%A in ('reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v Path 2^>nul') do set "PATH=%%B"
        for %%Q in (
            "C:\Program Files\Python312\python.exe"
            "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
            "C:\Python312\python.exe"
        ) do (
            if exist %%Q (
                set "PY=%%~Q"
                goto :py_found
            )
        )
    )
)

echo  [FATAL] Cannot find or install Python. Download from python.org and re-run.
echo  [FATAL] Python resolution failed>>"%LOG%"
pause & exit /b 1

:py_found
echo  [OK] Python: %PY%
echo  [OK] Python: %PY%>>"%LOG%"

:: Final verification — make sure it actually runs
"%PY%" -c "import sys; print('Python', sys.version)" >nul 2>&1
if !errorlevel! neq 0 (
    echo  [FATAL] Python at %PY% is not working.
    echo  [....] Go to Settings ^> Apps ^> Advanced app settings ^> App execution aliases
    echo  [....] and turn OFF both python.exe and python3.exe aliases, then re-run.
    echo  [FATAL] Python exe verification failed>>"%LOG%"
    pause & exit /b 1
)
echo  [OK] Python smoke check passed.
echo  [OK] Python smoke check passed>>"%LOG%"

:: ═════════════════════════════════════════════════════════════
::  STAGE RUNNER
::
::  Each stage is called as a DIRECT FILE PATH, not -m module.
::  This matches BoreholeIQ's pattern and avoids all the CWD /
::  package import issues that broke v8.
::
::  Every stage file has sys.path.insert(0, deploy_dir) at the
::  top so imports of utils always work regardless of CWD.
::
::  State files written to %STATE_DIR% (pack_root\runtime\state)
::  so partial runs can be resumed without re-running clean steps.
:: ═════════════════════════════════════════════════════════════

:: ── STEP 1/5: Prerequisites ───────────────────────────────────
echo.
echo  ---------------------------------------------------
echo    STEP 1/5: Prerequisites (MSVC, Node.js, Rust, WebView2)
echo  ---------------------------------------------------
if exist "%STATE_DIR%\01_prereqs.ok" (
    echo  [SKIP] Prerequisites already completed.
    echo  [SKIP] Step 1 already done>>"%LOG%"
) else (
    echo  [RUN ] 1_prereqs.py
    echo  [RUN ] 1_prereqs.py>>"%LOG%"
    "%PY%" "%DEPLOY_DIR%\1_prereqs.py" --root "%ROOT%"
    set "STAGE_RC=!errorlevel!"
    if !STAGE_RC! neq 0 (
        echo  [FAIL] Step 1 Prerequisites FAILED [exit !STAGE_RC!]
        echo  [FAIL] Step 1 failed [exit !STAGE_RC!]>>"%LOG%"
        echo  [....] Check %LOG% then fix the issue and re-run.
        pause & exit /b !STAGE_RC!
    )
    echo OK>"%STATE_DIR%\01_prereqs.ok"
    echo  [OK] Step 1 complete
    echo  [OK] Step 1 complete>>"%LOG%"
)

:: ── STEP 2/5: Binaries / cache policy ─────────────────────────
echo.
echo  ---------------------------------------------------
echo    STEP 2/5: Cache and Network Policy
echo  ---------------------------------------------------
if exist "%STATE_DIR%\02_binaries.ok" (
    echo  [SKIP] Cache setup already completed.
) else (
    echo  [RUN ] 2_binaries.py
    "%PY%" "%DEPLOY_DIR%\2_binaries.py" --root "%ROOT%"
    set "STAGE_RC=!errorlevel!"
    if !STAGE_RC! neq 0 (
        echo  [FAIL] Step 2 FAILED [exit !STAGE_RC!]
        echo  [FAIL] Step 2 failed>>"%LOG%"
        pause & exit /b !STAGE_RC!
    )
    echo OK>"%STATE_DIR%\02_binaries.ok"
    echo  [OK] Step 2 complete
)

:: ── STEP 3/5: LLM settings ────────────────────────────────────
echo.
echo  ---------------------------------------------------
echo    STEP 3/5: LLM Settings (optional)
echo  ---------------------------------------------------
if exist "%STATE_DIR%\03_llm.ok" (
    echo  [SKIP] LLM settings already configured.
) else (
    echo  [RUN ] 3_llm.py
    "%PY%" "%DEPLOY_DIR%\3_llm.py" --root "%ROOT%"
    set "STAGE_RC=!errorlevel!"
    if !STAGE_RC! neq 0 (
        echo  [FAIL] Step 3 LLM FAILED [exit !STAGE_RC!]
        echo  [FAIL] Step 3 failed>>"%LOG%"
        pause & exit /b !STAGE_RC!
    )
    echo OK>"%STATE_DIR%\03_llm.ok"
    echo  [OK] Step 3 complete
)

:: ── STEP 4/5: Scaffold + Build ────────────────────────────────
echo.
echo  ---------------------------------------------------
echo    STEP 4/5: Scaffold Source Files + Build App
echo  ---------------------------------------------------
if exist "%STATE_DIR%\04_build.ok" (
    echo  [SKIP] Build already completed.
) else (
    if not exist "%STATE_DIR%\01_prereqs.ok" (
        echo  [FATAL] Prerequisites not completed. Run from Step 1.
        pause & exit /b 1
    )
    echo  [RUN ] 4_build.py
    "%PY%" "%DEPLOY_DIR%\4_build.py" --root "%ROOT%"
    set "STAGE_RC=!errorlevel!"
    if !STAGE_RC! neq 0 (
        echo  [FAIL] Step 4 Build FAILED [exit !STAGE_RC!]
        echo  [FAIL] Step 4 failed>>"%LOG%"
        echo  [....] Check %LOG% for Rust / Tauri errors.
        pause & exit /b !STAGE_RC!
    )
    echo OK>"%STATE_DIR%\04_build.ok"
    echo  [OK] Step 4 complete
)

:: ── STEP 5/5: Verify ──────────────────────────────────────────
echo.
echo  ---------------------------------------------------
echo    STEP 5/5: Verify Artifacts
echo  ---------------------------------------------------
if exist "%STATE_DIR%\05_verify.ok" (
    echo  [SKIP] Verification already completed.
) else (
    echo  [RUN ] 5_verify.py
    "%PY%" "%DEPLOY_DIR%\5_verify.py" --root "%ROOT%"
    set "STAGE_RC=!errorlevel!"
    if !STAGE_RC! neq 0 (
        echo  [FAIL] Step 5 Verify FAILED [exit !STAGE_RC!]
        pause & exit /b !STAGE_RC!
    )
    echo OK>"%STATE_DIR%\05_verify.ok"
    echo  [OK] Step 5 complete
)

echo.
echo  ===================================================
echo    BUILD COMPLETE
echo    Artifacts: %ROOT%\runtime\artifacts
echo    Log:       %LOG%
echo  ===================================================
echo.
echo  [OK] Deployment complete>>"%LOG%"
pause
