// export.ts — DOCX export using pako (already bundled)
// A DOCX is a ZIP of XML files. We build the minimum viable structure.

import * as pako from "pako";
import type { Plan } from "./engine";

// ─── Tiny ZIP builder using pako ─────────────────────────────────────────

function crc32(buf: Uint8Array): number {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    crc ^= buf[i];
    for (let j = 0; j < 8; j++) crc = (crc >>> 1) ^ (crc & 1 ? 0xEDB88320 : 0);
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function makeZip(files: { name: string; data: Uint8Array }[]): Uint8Array {
  const entries: { name: Uint8Array; compressed: Uint8Array; crc: number; size: number; compSize: number; offset: number }[] = [];
  const parts: Uint8Array[] = [];
  let offset = 0;

  for (const f of files) {
    const nameBytes = new TextEncoder().encode(f.name);
    const crc = crc32(f.data);
    const compressed = pako.deflateRaw(f.data);
    const header = new Uint8Array(30 + nameBytes.length);
    const v = new DataView(header.buffer);
    v.setUint32(0, 0x04034b50, true);  // local file header sig
    v.setUint16(4, 20, true);           // version needed
    v.setUint16(8, 8, true);            // compression: deflate
    v.setUint32(14, crc, true);
    v.setUint32(18, compressed.length, true);
    v.setUint32(22, f.data.length, true);
    v.setUint16(26, nameBytes.length, true);
    header.set(nameBytes, 30);

    entries.push({ name: nameBytes, compressed, crc, size: f.data.length, compSize: compressed.length, offset });
    parts.push(header, compressed);
    offset += header.length + compressed.length;
  }

  // Central directory
  const cdStart = offset;
  for (const e of entries) {
    const cd = new Uint8Array(46 + e.name.length);
    const v = new DataView(cd.buffer);
    v.setUint32(0, 0x02014b50, true);
    v.setUint16(4, 20, true);
    v.setUint16(6, 20, true);
    v.setUint16(10, 8, true);
    v.setUint32(16, e.crc, true);
    v.setUint32(20, e.compSize, true);
    v.setUint32(24, e.size, true);
    v.setUint16(28, e.name.length, true);
    v.setUint32(42, e.offset, true);
    cd.set(e.name, 46);
    parts.push(cd);
    offset += cd.length;
  }

  // End of central directory
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(8, entries.length, true);
  ev.setUint16(10, entries.length, true);
  ev.setUint32(12, offset - cdStart, true);
  ev.setUint32(16, cdStart, true);
  parts.push(eocd);

  const total = parts.reduce((a, p) => a + p.length, 0);
  const result = new Uint8Array(total);
  let pos = 0;
  for (const p of parts) { result.set(p, pos); pos += p.length; }
  return result;
}

// ─── DOCX XML templates ─────────────────────────────────────────────────

function esc(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}

function para(text: string, bold = false, size = 22): string {
  const bTag = bold ? "<w:b/>" : "";
  return `<w:p><w:pPr><w:rPr>${bTag}<w:sz w:val="${size}"/></w:rPr></w:pPr><w:r><w:rPr>${bTag}<w:sz w:val="${size}"/></w:rPr><w:t xml:space="preserve">${esc(text)}</w:t></w:r></w:p>`;
}

function heading(text: string): string {
  return para(text, true, 28);
}

function subheading(text: string): string {
  return para(text, true, 24);
}

function field(label: string, value: string): string {
  if (!value) return "";
  return `<w:p><w:r><w:rPr><w:b/><w:sz w:val="20"/></w:rPr><w:t xml:space="preserve">${esc(label)}: </w:t></w:r><w:r><w:rPr><w:sz w:val="22"/></w:rPr><w:t xml:space="preserve">${esc(value)}</w:t></w:r></w:p>`;
}

function divider(): string {
  return `<w:p><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="4" w:space="1" w:color="CCCCCC"/></w:pBdr></w:pPr></w:p>`;
}

function tableRow(cells: string[], bold = false): string {
  const tcs = cells.map(c => {
    const bTag = bold ? "<w:b/>" : "";
    return `<w:tc><w:p><w:r><w:rPr>${bTag}<w:sz w:val="18"/></w:rPr><w:t xml:space="preserve">${esc(c)}</w:t></w:r></w:p></w:tc>`;
  }).join("");
  return `<w:tr>${tcs}</w:tr>`;
}

function table(rows: string[][]): string {
  const header = rows[0] ? tableRow(rows[0], true) : "";
  const body = rows.slice(1).map(r => tableRow(r)).join("");
  return `<w:tbl><w:tblPr><w:tblBorders><w:top w:val="single" w:sz="4" w:color="999999"/><w:bottom w:val="single" w:sz="4" w:color="999999"/><w:insideH w:val="single" w:sz="4" w:color="CCCCCC"/><w:insideV w:val="single" w:sz="4" w:color="CCCCCC"/></w:tblBorders><w:tblW w:w="5000" w:type="pct"/></w:tblPr>${header}${body}</w:tbl>`;
}

// ─── Build DOCX from Plan ────────────────────────────────────────────────

export function exportPlanToDocx(plan: Plan): void {
  const body: string[] = [];

  body.push(heading("Scale Up — Account Strategy Plan"));
  body.push(para(`Generated: ${new Date().toISOString().slice(0, 10)}`, false, 18));
  body.push(divider());

  // Header fields
  body.push(field("Account", plan.account));
  if (plan.division) body.push(field("Division", plan.division));
  if (plan.project) body.push(field("Project", plan.project));
  body.push(field("Sector", plan.sector));
  body.push(field("State of Account", plan.stateOfAccount));
  body.push(field("Champion", plan.champion));
  body.push(field("Mode", plan.planMode === "pipeline" ? "Pipeline (Web + LLM enriched)" : "Deterministic"));
  body.push(field("Grounding", `${plan.groundingScore}%`));
  body.push(divider());

  // Roles
  if (plan.roles.length > 0) {
    body.push(subheading("Roles"));
    const roleRows: string[][] = [["Name", "Role", "Influence", "Stance"]];
    for (const r of plan.roles) roleRows.push([r.name, r.role, String(r.influenceScore), r.stance]);
    body.push(table(roleRows));
    body.push(divider());
  }

  // Org Chart narrative
  if (plan.orgAlt) {
    body.push(subheading("Org Chart"));
    body.push(para(plan.orgAlt));
    if (plan.orgNodeOutline.length > 0 && !plan.orgNodeOutline[0].includes("[ASSUMPTION")) {
      for (const node of plan.orgNodeOutline) body.push(para("• " + node, false, 20));
    }
    body.push(divider());
  }

  // Critical Project Issue
  body.push(subheading("Critical Project Issue"));
  body.push(para(plan.criticalProjectIssue));
  body.push(divider());

  // Solution
  body.push(subheading("Solution"));
  body.push(para(plan.solution));
  body.push(divider());

  // Advantage
  body.push(subheading("Advantage"));
  body.push(para(plan.advantage));
  body.push(divider());

  // Case Study
  if (plan.caseStudy && !plan.caseStudy.includes("[ASSUMPTION")) {
    body.push(subheading("Case Study"));
    body.push(para(plan.caseStudy));
    body.push(divider());
  }

  // Solution Architecture narrative
  if (plan.archAlt) {
    body.push(subheading("Solution Architecture"));
    body.push(para(plan.archAlt));
    if (plan.archFlowOutline.length > 0) {
      for (const flow of plan.archFlowOutline) body.push(para("• " + flow, false, 20));
    }
    body.push(divider());
  }

  // Action Items
  if (plan.actionItems.length > 0) {
    body.push(subheading("Action Items"));
    const aiRows: string[][] = [["#", "Action", "Owner", "Deadline"]];
    for (const a of plan.actionItems) aiRows.push([String(a.index), a.action, a.owner, a.deadline || ""]);
    body.push(table(aiRows));
    body.push(divider());
  }

  // Projects
  if (plan.projects.length > 0) {
    body.push(subheading("Projects"));
    const projRows: string[][] = [["Project", "Status", "Phase", "Bentley Fit", "Source"]];
    for (const p of plan.projects) projRows.push([p.name, p.status.replace(/_/g, " "), p.phase, p.bentleyFit.join(", "), p.source]);
    body.push(table(projRows));
    body.push(divider());
  }

  // RACI
  if (plan.raci.length > 0) {
    body.push(subheading("RACI"));
    const raciRows: string[][] = [["Activity", "Responsible", "Accountable", "Consulted", "Informed"]];
    for (const r of plan.raci) raciRows.push([r.activity, r.responsible, r.accountable, r.consulted, r.informed]);
    body.push(table(raciRows));
    body.push(divider());
  }

  // Red Flags
  if (plan.redFlags.length > 0) {
    body.push(subheading("Red Flags"));
    const rfRows: string[][] = [["Flag", "Likelihood", "Impact", "Mitigation"]];
    for (const f of plan.redFlags) rfRows.push([f.flag, f.likelihood, f.impact, f.mitigation]);
    body.push(table(rfRows));
    body.push(divider());
  }

  // Assumptions
  if (plan.assumptions.length > 0) {
    body.push(subheading("Assumptions Register"));
    const aRows: string[][] = [["Field", "Value", "Verify By"]];
    for (const a of plan.assumptions) aRows.push([a.field, a.value, a.verifyBy]);
    body.push(table(aRows));
    body.push(divider());
  }

  // Opportunities
  if (plan.opportunities.length > 0) {
    body.push(subheading("Opportunities"));
    const oRows: string[][] = [["Title", "Problem", "Why Now", "Score", "Grounded"]];
    for (const o of plan.opportunities) oRows.push([o.title, o.problem, o.whyNow, String(o.totalScore), o.grounded ? "Yes" : "No"]);
    body.push(table(oRows));
  }

  body.push(para(""));
  body.push(para("Prototype by Orven Fajardo — Bentley Systems", false, 16));

  // Assemble DOCX XML
  const documentXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
  xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"
  xmlns:o="urn:schemas-microsoft-com:office:office"
  xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"
  xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"
  xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"
  xmlns:w10="urn:schemas-microsoft-com:office:word"
  xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
  xmlns:w14="http://schemas.microsoft.com/office/word/2010/wordml"
  xmlns:wpg="http://schemas.microsoft.com/office/word/2010/wordprocessingGroup"
  xmlns:wpi="http://schemas.microsoft.com/office/word/2010/wordprocessingInk"
  xmlns:wne="http://schemas.microsoft.com/office/word/2006/wordml"
  xmlns:wps="http://schemas.microsoft.com/office/word/2010/wordprocessingShape"
  mc:Ignorable="w14 wp14">
  <w:body>${body.join("")}</w:body>
</w:document>`;

  const contentTypes = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>`;

  const rels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

  const docRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
</Relationships>`;

  const enc = new TextEncoder();
  const zip = makeZip([
    { name: "[Content_Types].xml", data: enc.encode(contentTypes) },
    { name: "_rels/.rels", data: enc.encode(rels) },
    { name: "word/document.xml", data: enc.encode(documentXml) },
    { name: "word/_rels/document.xml.rels", data: enc.encode(docRels) },
  ]);

  // Download
  const blob = new Blob([zip.buffer as ArrayBuffer], { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const accountSlug = plan.account.replace(/[^a-zA-Z0-9]/g, "_").slice(0, 30) || "plan";
  a.href = url;
  a.download = `ScaleUp_${accountSlug}_${new Date().toISOString().slice(0, 10)}.docx`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 3000);
}
