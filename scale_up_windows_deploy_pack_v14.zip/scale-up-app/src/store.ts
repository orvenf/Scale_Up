// store.ts — Persistence layer (localStorage)
// Tauri secure store deferred to v1.0. This module centralises all
// persistence so the migration is a single-file change when ready.

import type { LLMConfig } from "./llm";
import type { PromptSlots } from "./types";

const KEY_CFG   = "su_cfg";
const KEY_SLOTS = "su_slots";

// ─── Secrets (API keys, endpoints) ───────────────────────────────────────

export async function saveSecrets(cfg: LLMConfig): Promise<void> {
  try { localStorage.setItem(KEY_CFG, JSON.stringify(cfg)); } catch {}
}

export async function migrateFromLocalStorage(defaults: LLMConfig): Promise<LLMConfig> {
  try {
    const raw = localStorage.getItem(KEY_CFG);
    if (raw) return { ...defaults, ...JSON.parse(raw) };
  } catch {}
  return { ...defaults };
}

export async function clearSecrets(): Promise<void> {
  try { localStorage.removeItem(KEY_CFG); } catch {}
}

// ─── Prompt slots ────────────────────────────────────────────────────────

export function loadSlots(): PromptSlots {
  try {
    const raw = localStorage.getItem(KEY_SLOTS);
    if (raw) return JSON.parse(raw) as PromptSlots;
  } catch {}
  return { planner: "", extractor: "", composer: "", verifier: "" };
}

export function saveSlots(s: PromptSlots): void {
  try { localStorage.setItem(KEY_SLOTS, JSON.stringify(s)); } catch {}
}
