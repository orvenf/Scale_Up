// engine.ts — Scale Up deterministic engine
// Deterministic layer always runs first. LLM is additive enrichment only.
// Every ungrounded field is tagged [INFERRED] or [ASSUMPTION — verify by DATE].

export interface ParsedContext {
  rawInput: string;
  accountName: string;
  division: string;
  project: string;
  sector: string;
  stakeholders: Stakeholder[];
  signals: Signal[];
  opportunities: Opportunity[];
  projects: ProjectEntry[];
  webContext: WebSnippet[];
  planMode: "pipeline" | "manual";
  _norm?: NormalizedInput;
}

export interface Stakeholder {
  nameOrRole: string;
  title: string;
  influenceScore: number;
  stance: "champion" | "neutral" | "risk" | "unknown";
  contact: string;
  isChampion: boolean;
  source: string;
}

export interface Signal {
  claim: string;
  confidence: "high" | "medium" | "low";
  source: string;
  tag: "[WEB]" | "[INPUT]" | "[LLM]" | "[INFERRED]";
}

export interface Opportunity {
  id: string;
  title: string;
  problem: string;
  whyNow: string;
  scores: { budget: number; timing: number; traction: number; value: number; fit: number };
  totalScore: number;
  selected: boolean;
  grounded: boolean;
}

export interface WebSnippet {
  title: string;
  snippet: string;
  url: string;
}

export interface Plan {
  planMode: "pipeline" | "manual";
  account: string;
  division: string;
  project: string;
  sector: string;
  stateOfAccount: string;
  orgMermaid: string;
  orgAlt: string;
  orgNodeOutline: string[];
  roles: RoleEntry[];
  contacts: string[];
  champion: string;
  criticalProjectIssue: string;
  solution: string;
  advantage: string;
  caseStudy: string;
  archMermaid: string;
  archAlt: string;
  archFlowOutline: string[];
  actionItems: ActionItem[];
  raci: RACIRow[];
  opportunities: Opportunity[];
  selectedOpportunity: Opportunity;
  signals: Signal[];
  sourceTags: string[];
  groundingScore: number;
  assumptions: Assumption[];
  redFlags: RedFlag[];
  projects: ProjectEntry[];
  mindMap: string;
}

export interface RoleEntry {
  role: string;
  name: string;
  influenceScore: number;
  stance: string;
}

export interface ActionItem {
  index: number;
  action: string;
  owner: string;
  deadline: string;
  source: string;
}

export interface RACIRow {
  activity: string;
  responsible: string;
  accountable: string;
  consulted: string;
  informed: string;
}

export interface Assumption {
  field: string;
  value: string;
  verifyBy: string;
}

export interface RedFlag {
  flag: string;
  likelihood: "high" | "medium" | "low";
  impact: "high" | "medium" | "low";
  mitigation: string;
}

export interface ProjectEntry {
  id: string;
  name: string;
  status: "active_tender" | "planning" | "execution" | "completed" | "on_hold" | "unknown";
  phase: string;
  bentleyFit: string[];
  confidence: "high" | "medium" | "low";
  source: string;
}

// ─── Domain taxonomy — ENGINE-03 ─────────────────────────────────────────

const DOMAIN_KEYWORDS: Record<string, string[]> = {
  "Infrastructure & Assets":    ["infrastructure","asset","utility","water","energy","power","grid","pipeline","network","facility","maintenance","GIS","spatial","subsurface","geotechnical","PLAXIS","Leapfrog","OpenUtilities","STAAD","transmission","OHL","PLS-CADD","Cesium","3D Tiles","AssetWise","WaterGEMS","SewerGEMS"],
  "Buildings & Construction":   ["BIM","building","construction","design","architecture","structural","MEP","fit-out","contractor","EPC","schedule","claims","RFI","rework","change order","ProjectWise","OpenBuildings","4D","5D","SYNCHRO","MicroStation","GenerativeComponents"],
  "Digital Twin & Operations":  ["digital twin","iTwin","CDE","operations","OT","IoT","sensor","telemetry","analytics","real-time","SCADA","monitoring","iModel","Bentley","Cesium ion","ContextCapture","BIC"],
  "Mining & Geosciences":       ["mining","geoscience","ore","deposit","drill","subsurface","geology","PLAXIS","Leapfrog","seismic","reservoir","GeoStudio","Oasis montaj","Imago","OpenGround","Seequent","Central","gINT","slope stability"],
  "Rail & Transportation":      ["rail","metro","transit","highway","road","bridge","airport","port","tunnel","OpenRail","OpenRoads","OpenBridge","OpenSite","LumenRT"],
  "Plant & Process":            ["plant","process","refinery","chemical","oil","gas","offshore","AVEVA","E3D","PDMS","P&ID","instrumentation","SACS","AutoPIPE","MOSES"],
};

function detectSector(text: string): string {
  const lower = text.toLowerCase();
  let best = ""; let bestCount = 0;
  for (const [sector, kws] of Object.entries(DOMAIN_KEYWORDS)) {
    const count = kws.filter(kw => lower.includes(kw.toLowerCase())).length;
    if (count > bestCount) { bestCount = count; best = sector; }
  }
  return best || "Enterprise";
}

// ─── Product knowledge graph — hardcoded Bentley domain expertise ────────

interface ProductKnowledge {
  name: string;
  brand: "Bentley" | "Seequent" | "PLS" | "Cesium";
  category: string;
  solves: string;         // what problem this product addresses
  competitors: string[];  // specific competing products
  integratesWith: string[]; // other Bentley products it connects to
  useCases: string[];     // concrete project scenarios
  differentiator: string; // why this beats the competition
}

const PRODUCT_KNOWLEDGE: ProductKnowledge[] = [
  { name: "PLAXIS 2D/3D", brand: "Bentley", category: "Geotechnical",
    solves: "Subsurface and foundation risk — slope stability, excavation, tunnelling, dam foundation analysis",
    competitors: ["Rocscience RS2/RS3", "DIANA", "Midas GTS", "FLAC3D"],
    integratesWith: ["Leapfrog", "gINT", "OpenGround", "ProjectWise"],
    useCases: ["Dam foundation analysis", "Deep excavation", "Tunnel design", "Slope stability", "Retaining walls"],
    differentiator: "Direct model continuity from Leapfrog geological models into PLAXIS geotechnical analysis — competitors require manual re-modelling" },
  { name: "Leapfrog", brand: "Seequent", category: "Geological Modelling",
    solves: "Subsurface uncertainty — 3D geological model building from drill/survey data",
    competitors: ["Vulcan", "Surpac", "Datamine", "Micromine"],
    integratesWith: ["PLAXIS 2D/3D", "gINT", "Seequent Central", "OpenGround", "Imago", "iTwin Platform"],
    useCases: ["Mining resource estimation", "Hydroelectric dam geology", "Groundwater modelling", "Environmental contamination"],
    differentiator: "Implicit modelling engine updates automatically as new data arrives — traditional explicit modelling requires manual surface rebuilds" },
  { name: "ProjectWise", brand: "Bentley", category: "CDE",
    solves: "Document chaos — version control, access management, audit trail for engineering data",
    competitors: ["Autodesk Construction Cloud", "Aconex", "SharePoint", "Procore", "Newforma"],
    integratesWith: ["MicroStation", "OpenRoads Designer", "OpenBuildings Designer", "SYNCHRO 4D/5D", "iTwin Platform"],
    useCases: ["Multi-contractor CDE", "BIM mandate compliance", "Design review workflows", "Regulatory submission management"],
    differentiator: "Native integration with all Bentley design tools — competitors require middleware and lose metadata fidelity" },
  { name: "iTwin Platform", brand: "Bentley", category: "Digital Twin",
    solves: "Siloed engineering data — federates models from multiple tools into a single navigable digital twin",
    competitors: ["Autodesk Tandem", "Aveva Digital Twin", "Siemens Xcelerator"],
    integratesWith: ["ProjectWise", "Cesium", "ContextCapture", "SYNCHRO 4D/5D", "AssetWise APM"],
    useCases: ["Asset lifecycle visualisation", "Construction progress tracking", "Operational digital twin", "ESG reporting"],
    differentiator: "Open iModel format federates ANY source (not just Bentley) — competitors lock you into their ecosystem" },
  { name: "SYNCHRO 4D/5D", brand: "Bentley", category: "Construction",
    solves: "Schedule and cost blindness — links 3D models to time and cost for visual construction sequencing",
    competitors: ["Navisworks", "Primavera P6", "Asta Powerproject", "Synchro (standalone)"],
    integratesWith: ["ProjectWise", "iTwin Platform", "OpenBuildings Designer", "OpenRoads Designer"],
    useCases: ["Bid visualisation", "Construction sequencing", "Quantity takeoff", "Progress claims", "Delay analysis"],
    differentiator: "Integrated 4D+5D in one platform with iTwin federation — competitors separate schedule from cost and lack model federation" },
  { name: "PLS-CADD", brand: "PLS", category: "Transmission",
    solves: "Transmission line design complexity — sag-tension, clearance, tower loading for overhead lines",
    competitors: ["Trimble PLS Suite (legacy)", "Kalpataru proprietary", "Manual calculation"],
    integratesWith: ["PLS-POLE", "PLS-TOWER", "iTwin Platform", "ContextCapture"],
    useCases: ["Overhead transmission routing", "Tower design and loading", "Clearance analysis", "Galloping studies"],
    differentiator: "Industry standard for OHL design — 90%+ market share in transmission engineering globally" },
  { name: "Cesium", brand: "Cesium", category: "3D Geospatial",
    solves: "Large-scale 3D visualisation — streaming massive reality meshes, point clouds, terrain at global scale",
    competitors: ["Google Earth Enterprise", "Mapbox", "ArcGIS Scene Viewer"],
    integratesWith: ["iTwin Platform", "ContextCapture", "ProjectWise"],
    useCases: ["Geospatial context for engineering", "Reality mesh overlay", "Public consultation visualisation", "Environmental impact"],
    differentiator: "OGC 3D Tiles standard — open format, streams terabyte-scale data in browser, no proprietary lock-in" },
  { name: "OpenRoads Designer", brand: "Bentley", category: "Civil",
    solves: "Road and highway design inefficiency — corridor modelling, drainage, earthworks",
    competitors: ["Autodesk Civil 3D", "Trimble Business Center", "12d Model"],
    integratesWith: ["ProjectWise", "SYNCHRO 4D/5D", "iTwin Platform", "OpenBridge Designer"],
    useCases: ["Highway design", "Interchange modelling", "Drainage design", "Rail corridor"],
    differentiator: "Model-based design with automatic plan production — Civil 3D requires manual drawing extraction" },
  { name: "AssetWise APM", brand: "Bentley", category: "Operations",
    solves: "Reactive maintenance — moves from break-fix to predictive/reliability-centred maintenance",
    competitors: ["IBM Maximo", "SAP PM", "Hexagon EAM"],
    integratesWith: ["iTwin Platform", "ProjectWise", "SYNCHRO 4D/5D"],
    useCases: ["Asset lifecycle management", "Predictive maintenance", "Inspection management", "Regulatory compliance"],
    differentiator: "Direct link from as-built digital twin to operational asset — competitors start from blank asset register" },
  { name: "ContextCapture", brand: "Bentley", category: "Reality Capture",
    solves: "Site documentation gaps — creates 3D reality meshes from drone/photo/LiDAR surveys",
    competitors: ["Pix4D", "DroneDeploy", "Agisoft Metashape"],
    integratesWith: ["iTwin Platform", "Cesium", "ProjectWise", "OpenRoads Designer"],
    useCases: ["Construction progress monitoring", "Existing conditions capture", "Quantity verification", "Heritage documentation"],
    differentiator: "Engineering-grade accuracy with direct iTwin federation — survey competitors produce visual models without engineering-grade metadata" },
  { name: "STAAD.Pro", brand: "Bentley", category: "Structural",
    solves: "Structural analysis complexity — steel, concrete, timber design and code checking",
    competitors: ["ETABS", "SAP2000", "Tekla Structural Designer", "Robot Structural Analysis"],
    integratesWith: ["ProjectWise", "OpenBuildings Designer", "iTwin Platform"],
    useCases: ["Building structural design", "Industrial structures", "Tower design", "Seismic analysis"],
    differentiator: "70+ international design codes built in — broadest global code coverage of any structural analysis tool" },
  { name: "GeoStudio", brand: "Seequent", category: "Geotechnical",
    solves: "Geotechnical analysis for slopes, seepage, and dynamic loading",
    competitors: ["Rocscience Slide", "PLAXIS (for some cases)", "GEO5"],
    integratesWith: ["Leapfrog", "PLAXIS 2D/3D", "Seequent Central"],
    useCases: ["Dam seepage analysis", "Slope stability (Slope/W)", "Consolidation (SIGMA/W)", "Earthquake response (QUAKE/W)"],
    differentiator: "Coupled multi-physics analysis (seepage + stability + deformation in one model) — competitors solve each independently" },
  { name: "OpenBuildings Designer", brand: "Bentley", category: "Buildings",
    solves: "Building design fragmentation — architecture, structural, MEP in one environment",
    competitors: ["Autodesk Revit", "Archicad", "Vectorworks"],
    integratesWith: ["ProjectWise", "SYNCHRO 4D/5D", "iTwin Platform", "STAAD.Pro"],
    useCases: ["Data centre design", "Industrial facilities", "Campus planning", "Fit-out"],
    differentiator: "Handles massive models (airports, campuses) where Revit hits performance limits — no file size ceiling" },
];

// Quick lookup helpers
function findProductKnowledge(name: string): ProductKnowledge | undefined {
  return PRODUCT_KNOWLEDGE.find(p => name.toLowerCase().includes(p.name.toLowerCase().split(" ")[0]));
}

function detectProductsInText(text: string): ProductKnowledge[] {
  const found: ProductKnowledge[] = [];
  const lower = text.toLowerCase();
  for (const pk of PRODUCT_KNOWLEDGE) {
    const nameKey = pk.name.toLowerCase().split(" ")[0].replace(/[^a-z]/g, "");
    if (lower.includes(nameKey) && !found.includes(pk)) found.push(pk);
  }
  return found;
}

function detectCompetitorsInText(text: string): string[] {
  const competitors: string[] = [];
  const lower = text.toLowerCase();
  const allCompetitors = new Set(PRODUCT_KNOWLEDGE.flatMap(p => p.competitors));
  for (const c of allCompetitors) {
    if (lower.includes(c.toLowerCase().split(" ")[0].replace(/[^a-z]/g, ""))) competitors.push(c);
  }
  return competitors;
}

// ─── Opportunity builder — grounded to actual domain ──────────────────────

function buildOpportunityFromDomain(sector: string, budget: number, timing: number, traction: number, signals: number, rawInput?: string): Opportunity[] {
  const grounded = budget + timing + traction > 0;

  // ── Intent-driven: if specific products detected, build opportunities FROM them ──
  const detectedProducts = rawInput ? detectProductsInText(rawInput) : [];
  if (detectedProducts.length > 0) {
    const candidates = detectedProducts.slice(0, 3).map((pk, idx) => {
      const b = Math.max(0, budget - idx);
      const t = Math.max(0, timing - idx);
      const tr = Math.max(0, traction - (idx > 0 ? 1 : 0));
      const scores = {
        budget:   Math.min(100, b  * 25 + 40),
        timing:   Math.min(100, t  * 20 + 35),
        traction: Math.min(100, tr * 30 + 30),
        value: 80 - idx * 5,
        fit:   85 - idx * 3,
      };
      const totalScore = Math.round(Object.values(scores).reduce((a,v) => a+v, 0) / 5);
      return {
        id: `opp-${idx+1}`,
        title: pk.solves.split("—")[0].trim(),
        problem: pk.solves,
        whyNow: pk.useCases.slice(0, 2).join(", "),
        scores, totalScore,
        selected: idx === 0,
        grounded: idx === 0 && grounded,
      };
    });
    return candidates.sort((a,b) => b.totalScore - a.totalScore).map((o,i) => ({...o, selected: i===0}));
  }

  // ── Sector fallback: generic opportunities ──
  const domainOpps: Record<string, [string,string,string][]> = {
    "Infrastructure & Assets": [
      ["Asset Lifecycle Digitisation","Manual inspection and data silos creating maintenance risk","GIS/asset data consolidation mandate"],
      ["Utility Network Modernisation","Ageing network with compliance and resilience gaps","Regulatory review or renewal trigger"],
      ["Spatial Analytics Platform","Decision-making limited by fragmented geospatial data","Digital infrastructure programme funding"],
    ],
    "Buildings & Construction": [
      ["BIM Mandate Compliance","Design/construction data fragmentation increasing rework costs","Government BIM mandate or tender requirement"],
      ["CDE & ProjectWise Consolidation","Multiple disconnected document environments causing version risk","Project mobilisation or contract renewal"],
      ["4D/5D Schedule & Cost Control","Schedule slippage and claims from poor baseline visibility","Active project with contractor disputes"],
    ],
    "Digital Twin & Operations": [
      ["iTwin Operational Intelligence","Siloed OT/IT data preventing predictive maintenance","Digital twin programme or ESG reporting deadline"],
      ["CDE Maturity Uplift","Low CDE adoption limiting collaboration and audit trail","Upcoming audit or compliance review"],
      ["Real-Time Analytics Deployment","Reactive operations with no telemetry-driven insights","Budget approved for operational efficiency"],
    ],
    "Mining & Geosciences": [
      ["Subsurface Data Integration","Fragmented drill/seismic data slowing resource decisions","Reserve declaration deadline or investor review"],
      ["Geotechnical Risk Reduction","Manual slope/stability analysis with slow turnaround","Safety audit or regulatory filing window"],
      ["Exploration Digitalisation","Legacy systems unable to support modern ML-driven workflows","New exploration budget or JV announcement"],
    ],
    "Rail & Transportation": [
      ["Digital Corridor Planning","Disconnected design tools increasing rework on major corridors","Tender submission or feasibility milestone"],
      ["Asset Management Transformation","Paper-based inspection regime failing compliance requirements","Regulator review or concession renewal"],
      ["Simulation & Visualisation","Stakeholder approvals delayed by inadequate visualisation","Public consultation or planning approval stage"],
    ],
    "Plant & Process": [
      ["Plant Data Migration","Legacy 3D models not federated, blocking maintenance workflows","Turnaround or shutdown planning window"],
      ["Engineering Data Integrity","Disconnected P&ID and instrument data causing safety risk","HSE audit or HAZOP review timeline"],
      ["Digital Handover Readiness","Contractor deliverables not meeting owner data requirements","Project completion or commissioning milestone"],
    ],
    "Enterprise": [
      ["Digital Transformation","Legacy systems limiting operational agility","Regulatory or competitive pressure"],
      ["Operational Excellence","Manual processes and fragmentation increasing cost","Budget cycle or executive OKR alignment"],
      ["Risk & Compliance","Governance and audit exposure","Upcoming audit, renewal, or tender trigger"],
    ],
  };

  const candidates = (domainOpps[sector] ?? domainOpps["Enterprise"]).map((([title, problem, whyNow], idx) => {
    const b = Math.max(0, budget - idx);
    const t = Math.max(0, timing - idx);
    const tr = Math.max(0, traction - (idx > 0 ? 1 : 0));
    const scores = {
      budget:   Math.min(100, b  * 25 + 40),
      timing:   Math.min(100, t  * 20 + 35),
      traction: Math.min(100, tr * 30 + 30),
      value: 70 - idx * 5,
      fit:   75 - idx * 3,
    };
    const totalScore = Math.round(Object.values(scores).reduce((a,v) => a+v, 0) / 5);
    return { id: `opp-${idx+1}`, title, problem, whyNow, scores, totalScore, selected: idx === 0, grounded: idx === 0 && grounded };
  }));

  return candidates.sort((a,b) => b.totalScore - a.totalScore).map((o,i) => ({...o, selected: i===0}));
}

// ─── Extraction patterns ──────────────────────────────────────────────────

const TITLE_PAT    = /\b(CIO|CTO|CFO|CEO|COO|CISO|CDO|CDIO|VP\s+\w+|Director\s+\w+|Head\s+of\s+\w+|Manager\s+\w+|Lead\s+\w+|Engineer\s+\w+|Architect\s+\w+|Project\s+Manager|Programme\s+Manager|General\s+Manager|Country\s+Manager|Chief\s+\w+\s+Officer|Managing\s+Director|Group\s+Director)/gi;
const NAME_PAT     = /\b([A-Z][a-z]{1,18}\s+[A-Z][a-z]{1,18})\b/g;
const ACCOUNT_PAT  = /\b(?:account|client|customer|company|organisation|organization|agency|authority)[:\s]+([A-Z][A-Za-z0-9\s&.,\-]{2,50})/i;
const ACCOUNT_PAT2 = /\b(?:met with|meeting with|call with|visited|at|for)\s+([A-Z][A-Za-z0-9\s&]{2,40}?)(?:\s+(?:CDO|CTO|CIO|CEO|CFO|COO|team|about|regarding|to discuss|on|in|last|this|yesterday))/i;
const DIV_PAT      = /\b(division|department|dept|business\s+unit|bu|ministry|bureau)[:\s]+([A-Z][A-Za-z0-9\s&.,\-]{2,40})/i;
const PROJ_PAT     = /\b(project|programme|program|initiative|workstream|phase)[:\s]+([A-Z][A-Za-z0-9\s&.,\-#]{2,60})/i;
const HIGH_CONF    = /\b(confirmed|committed|signed|approved|budgeted|awarded|contracted|executive\s+sponsor|champion)\b/i;
const MED_CONF     = /\b(mentioned|discussed|considering|likely|possible|potential|may|might|evaluating|shortlisted|exploring)\b/i;
const BUDGET_SIG   = /\b(budget|funding|approved|investment|capex|opex|spend|cost|million|billion|\$[0-9]|USD|SGD|PHP|IDR|MYR|THB|AUD|JPY|RM[0-9])\b/i;
const TIMING_SIG   = /\b(deadline|quarter|Q[1-4]|FY\s*\d{2,4}|fiscal|renewal|contract|expires|urgent|mobiliz|tender|closing\s+date|this\s+year|H[12]\s*\d{4}|end\s+of\s+year|FID|feasibility)\b/i;
const TRACTION_SIG = /\b(pilot|trial|poc|proof\s+of\s+concept|demo|evaluation|shortlist|selected|preferred|reference\s+site|site\s+visit|workshop|existing\s+user|already\s+using|adopted|deployed)\b/i;
const CHAMPION_PAT = /\b(champion|sponsor|executive\s+sponsor|internal\s+champion|supporter|advocate|driving|pushing|CDO|CIO|CTO|Chief\s+Digital|Chief\s+Information|Chief\s+Technology)\b/i;
const RISK_PAT     = /\b(concern|risk|blocker|against|resistant|competitor|autodesk|hexagon|trimble|aveva|esri|ptc|oracle|sap|ibm|rocscience|vulcan|surpac|datamine|micromine|pix4d|dronedeploy|maximo|navisworks|civil\s+3d|revit|aconex|procore|midas|diana|flac3d|etabs|sap2000)\b/i;
const TENDER_PAT   = /\b(GeBIZ|PhilGEPS|LPSE|KONEPS|muasamcong|MyProcurement|tender|RFQ|RFP|ITQ|ITT|EOI|procurement|bid)\b/i;

// ─── Project phase & status patterns ────────────────────────────────────

const PHASE_PATS: [RegExp, string][] = [
  [/\b(feasibility|pre-feasibility|concept|scoping|masterplan|master\s*plan)\b/i, "Feasibility / Concept"],
  [/\b(detailed\s+design|design\s+phase|preliminary\s+design|schematic|FEL[- ]?[123]|FEED)\b/i, "Design"],
  [/\b(tender|bidding|procurement|RFP|RFQ|ITT|ITQ|EOI|GeBIZ|PhilGEPS|LPSE|KONEPS)\b/i, "Tender / Procurement"],
  [/\b(construction|execution|build|site\s+works?|mobiliz|EPC|D&B|design[\s-]+build)\b/i, "Construction / Execution"],
  [/\b(commissioning|handover|completion|closeout|testing|as[\s-]?built|defects\s+liability)\b/i, "Commissioning / Handover"],
  [/\b(operation|O&M|maintenance|asset\s+management|lifecycle|rehabilitation|renewal)\b/i, "Operations / Maintenance"],
];

const STATUS_PATS: [RegExp, "active_tender" | "planning" | "execution" | "completed" | "on_hold"][] = [
  [/\b(active\s+tender|open\s+tender|currently\s+tendering|bidding\s+now|tender\s+closing|submission\s+deadline)\b/i, "active_tender"],
  [/\b(planning|planned|upcoming|proposed|pipeline|future|under\s+study|feasibility)\b/i, "planning"],
  [/\b(under\s+construction|ongoing|in\s+progress|executing|mobiliz|site\s+works?|construction\s+phase)\b/i, "execution"],
  [/\b(completed|finished|operational|commissioned|handed\s+over|as[\s-]?built)\b/i, "completed"],
  [/\b(on\s+hold|delayed|suspended|deferred|stalled|paused)\b/i, "on_hold"],
];

const BENTLEY_PRODUCTS: [RegExp, string][] = [
  // ── Bentley Systems: CDE & Platform ──
  [/\b(ProjectWise|PW)\b/i, "ProjectWise"],
  [/\b(Bentley\s+Infrastructure\s+Cloud|BIC)\b/i, "Bentley Infrastructure Cloud"],
  // ── Digital Twins ──
  [/\b(iTwin|iModel|digital\s+twin|iTwin\s+Capture|iTwin\s+Experience|iTwin\s+IoT)\b/i, "iTwin Platform"],
  // ── Construction ──
  [/\b(SYNCHRO)\b/i, "SYNCHRO 4D/5D"],
  [/\b(4D\s+schedule|4D\s+planning|5D\s+cost)\b/i, "SYNCHRO 4D/5D"],
  // ── Design Foundations ──
  [/\b(MicroStation)\b/i, "MicroStation"],
  // ── Civil / Transport ──
  [/\b(OpenRoads)\b/i, "OpenRoads Designer"],
  [/\b(OpenRail)\b/i, "OpenRail Designer"],
  [/\b(OpenBridge)\b/i, "OpenBridge Designer"],
  [/\b(OpenSite)\b/i, "OpenSite Designer"],
  // ── Water / Waste / Storm ──
  [/\b(OpenFlows|WaterGEMS|SewerGEMS|HAMMER|StormCAD|CivilStorm|PondPack|FLOOD)\b/i, "OpenFlows"],
  // ── Structural ──
  [/\b(STAAD)\b/i, "STAAD.Pro"],
  [/\b(RAM\s+Structural|RAM\s+Steel|RAM\s+Concept)\b/i, "RAM Structural"],
  [/\b(SACS)\b/i, "SACS"],
  [/\b(AutoPIPE)\b/i, "AutoPIPE"],
  // ── Geotechnical ──
  [/\b(PLAXIS)\b/i, "PLAXIS 2D/3D"],
  // ── Buildings / Campus ──
  [/\b(OpenBuildings|GenerativeComponents)\b/i, "OpenBuildings Designer"],
  // ── Utilities / Networks ──
  [/\b(OpenUtilities)\b/i, "OpenUtilities"],
  // ── Reality & Survey ──
  [/\b(ContextCapture|iTwin\s+Capture)\b/i, "ContextCapture"],
  // ── Operations & Reliability ──
  [/\b(AssetWise|eB|APM|RAMS)\b/i, "AssetWise APM"],
  // ── Subsurface data ──
  [/\b(gINT)\b/i, "gINT"],

  // ── Seequent (Subsurface & Geoscience) ──
  [/\b(Leapfrog\s+Geo|Leapfrog\s+Works|Leapfrog\s+Hydro|Leapfrog\s+Edge|Leapfrog)\b/i, "Leapfrog"],
  [/\b(GeoStudio|Slope\/W|SEEP\/W|SIGMA\/W|QUAKE\/W)\b/i, "GeoStudio"],
  [/\b(Oasis\s+montaj)\b/i, "Oasis montaj"],
  [/\b(Seequent\s+Central|Central)\b/i, "Seequent Central"],
  [/\b(Imago)\b/i, "Imago"],
  [/\b(OpenGround)\b/i, "OpenGround"],

  // ── Power Line Systems (PLS) ──
  [/\b(PLS[\s-]?CADD)\b/i, "PLS-CADD"],
  [/\b(PLS[\s-]?POLE)\b/i, "PLS-POLE"],
  [/\b(PLS[\s-]?TOWER)\b/i, "PLS-TOWER"],
  [/\b(transmission\s+line|overhead\s+line|OHL)\b/i, "PLS (Transmission)"],

  // ── Cesium (3D Geospatial) ──
  [/\b(CesiumJS|Cesium\s+ion|Cesium)\b/i, "Cesium"],
  [/\b(3D\s+Tiles|OGC\s+3D\s+Tiles)\b/i, "Cesium 3D Tiles"],

  // ── Generic catch-alls (lower priority — placed last) ──
  [/\b(CDE|common\s+data\s+environment)\b/i, "CDE (ProjectWise)"],
  [/\b(BIM)\b/i, "BIM Platform"],
  [/\b(GIS|geospatial|spatial)\b/i, "Geospatial / GIS"],
];

// ─── Input normalizer — DETERM-001: handle structured documents ──────────

interface NormalizedInput {
  account: string;
  division: string;
  project: string;
  champion: string;
  championTitle: string;
  criticalIssue: string;
  solution: string;
  advantage: string;
  caseStudy: string;
  stateOfAccount: string;
  orgMermaid: string;
  archMermaid: string;
  orgAlt: string;
  archAlt: string;
  orgNodeOutline: string[];
  archFlowOutline: string[];
  actionItems: ActionItem[];
  raciRows: RACIRow[];
  contacts: string[];
  extraStakeholders: Stakeholder[];
  cleanedText: string; // input with Mermaid/tables stripped for regex pass
}

function normalizeInput(raw: string): NormalizedInput {
  const result: NormalizedInput = {
    account: "", division: "", project: "", champion: "", championTitle: "",
    criticalIssue: "", solution: "", advantage: "", caseStudy: "",
    stateOfAccount: "", orgMermaid: "", archMermaid: "", orgAlt: "", archAlt: "",
    orgNodeOutline: [], archFlowOutline: [], actionItems: [], raciRows: [],
    contacts: [], extraStakeholders: [], cleanedText: raw,
  };

  // ── 0. JSON detection — SE Diligence schema ────────────────────────
  const trimmed = raw.trim();
  if (trimmed.startsWith("{")) {
    try {
      const parsed = JSON.parse(trimmed);
      const data = parsed.sampleResearch || parsed;

      // Metadata
      if (data.metadata?.accountName) result.account = data.metadata.accountName;
      if (data.accountName) result.account = data.accountName;
      if (data.accountSummary) result.stateOfAccount = data.accountSummary.slice(0, 300);

      // Opportunity fields
      const opp = data.opportunity || {};
      if (opp.division) result.division = opp.division;
      if (opp.project) result.project = opp.project;
      if (opp.contact) result.contacts.push(opp.contact);
      if (opp.champion?.name) {
        result.champion = opp.champion.title
          ? `${opp.champion.name}, ${opp.champion.title}`
          : opp.champion.name;
        result.championTitle = opp.champion.title || "";
      }
      if (opp.criticalIssue) result.criticalIssue = opp.criticalIssue;
      if (opp.solution) result.solution = opp.solution;
      if (opp.advantage) result.advantage = opp.advantage;

      // Case study
      const cs = data.caseStudy || {};
      if (cs.title) result.caseStudy = cs.description ? `${cs.title}: ${cs.description}` : cs.title;

      // Org chart Mermaid
      const org = data.orgChart || {};
      if (org.mermaid) result.orgMermaid = org.mermaid;
      if (org.altNarrative) result.orgAlt = org.altNarrative;
      if (org.nodeOutline) {
        result.orgNodeOutline = (typeof org.nodeOutline === "string")
          ? org.nodeOutline.split("\n").map((l: string) => l.replace(/^[-•]\s*/, "").trim()).filter((l: string) => l.length > 5)
          : Array.isArray(org.nodeOutline) ? org.nodeOutline : [];
      }

      // Solution architecture Mermaid
      const arch = data.solutionArchitecture || {};
      if (arch.mermaid) result.archMermaid = arch.mermaid;
      if (arch.altNarrative) result.archAlt = arch.altNarrative;
      if (arch.flowOutline) {
        result.archFlowOutline = (typeof arch.flowOutline === "string")
          ? arch.flowOutline.split("\n").map((l: string) => l.replace(/^[-•]\s*/, "").trim()).filter((l: string) => l.length > 10)
          : Array.isArray(arch.flowOutline) ? arch.flowOutline : [];
      }

      // Action items
      if (Array.isArray(data.actionItems)) {
        result.actionItems = data.actionItems.map((ai: any, i: number) => ({
          index: i + 1,
          action: ai.item || ai.action || "",
          owner: ai.owner || "",
          deadline: ai.due || ai.deadline || "",
          source: "[INPUT]",
        }));
      }

      // RACI
      if (Array.isArray(data.raci)) {
        result.raciRows = data.raci.map((r: any) => ({
          activity: r.deliverable || r.activity || "",
          responsible: r.responsible || "",
          accountable: r.accountable || "",
          consulted: r.consulted || "",
          informed: r.informed || "",
        }));
      }

      // Extract stakeholders from org chart Mermaid nodes
      if (result.orgMermaid) {
        const nodeMatches = [...result.orgMermaid.matchAll(/\w+\["([^"]+)"\]/g)];
        for (const nm of nodeMatches) {
          const label = nm[1].replace(/<br\s*\/?>/gi, " — ").trim();
          const hasExecTitle = /\b(Director|Managing|Chief|Officer|VP|President|Head|CDO|CIO|CTO|CEO|CFO|Manager)\b/i.test(label);
          result.extraStakeholders.push({
            nameOrRole: label.slice(0, 60),
            title: hasExecTitle ? label.slice(0, 60) : "Stakeholder",
            influenceScore: hasExecTitle ? 80 : 55,
            stance: /champion|sponsor|CDO|CIO|CTO/i.test(label) ? "champion" : "neutral",
            contact: "",
            isChampion: /champion|CDO|CIO|CTO/i.test(label),
            source: "[INPUT]",
          });
        }
      }

      // Set cleanedText to the full JSON stringified (for signal/keyword extraction)
      result.cleanedText = JSON.stringify(data, null, 2);

      return result; // skip markdown/regex parsing — we have everything from JSON
    } catch {
      // Not valid JSON — fall through to markdown/regex parsing
    }
  }

  // ── 1. Extract and preserve Mermaid code blocks ──────────────────────
  const mermaidBlocks: string[] = [];
  const cleaned = raw.replace(/```mermaid\s*\n([\s\S]*?)```/gi, (_m, code) => {
    mermaidBlocks.push(code.trim());
    return ""; // strip from text so regex doesn't parse diagram syntax
  });
  // Also catch inline mermaid without fences (starts with "graph TD" or "flowchart LR")
  const inlineMermaid = raw.match(/(?:^|\n)((?:graph\s+(?:TD|LR|TB|BT)|flowchart\s+(?:LR|TD|TB|RL))[\s\S]*?)(?=\n\n|\n[A-Z*#]|$)/gm);
  if (inlineMermaid) {
    for (const block of inlineMermaid) {
      const trimmed = block.trim();
      if (trimmed.length > 30 && !mermaidBlocks.includes(trimmed)) mermaidBlocks.push(trimmed);
    }
  }

  // Classify Mermaid blocks: org chart (graph TD with people) vs architecture (flowchart/subgraph)
  for (const block of mermaidBlocks) {
    if (/subgraph|flowchart/i.test(block) && !result.archMermaid) {
      result.archMermaid = block;
    } else if (/graph\s+TD/i.test(block) && !result.orgMermaid) {
      result.orgMermaid = block;
    }
  }

  result.cleanedText = cleaned;

  // ── 2. Extract markdown-header fields (**Key:** Value or ## Key) ─────

  // Special: parse Intent line for embedded account/project references
  const intentMatch = raw.match(/\*\*Intent:?\*\*\s*(.+)/i);
  if (intentMatch) {
    const intentText = intentMatch[1].trim();
    // "Sell X to AccountName for ProjectDesc"
    const toForMatch = intentText.match(/\bto\s+([A-Z][A-Za-z0-9\s&]{2,40}?)\s+(?:for|about|regarding|on)\s+(.+)/i);
    if (toForMatch) {
      if (!result.account) result.account = toForMatch[1].trim();
      if (!result.project) result.project = toForMatch[2].trim().slice(0, 80);
    }
    // "Sell X to AccountName" (no 'for')
    if (!result.account) {
      const toMatch = intentText.match(/\bto\s+([A-Z][A-Za-z0-9\s&]{2,40}?)(?:\s*$|\s+(?:—|-|,))/i);
      if (toMatch) result.account = toMatch[1].trim();
    }
  }

  const fieldPatterns: [RegExp, keyof NormalizedInput][] = [
    [/\*\*Account:?\*\*\s*(.+)/i, "account"],
    [/^#{1,3}\s*Account[:\s]+(.+)/im, "account"],
    [/\bAccount\s*Name[:\s]+(.+)/i, "account"],
    [/\*\*Division:?\*\*\s*(.+)/i, "division"],
    [/\bDivision[:\s]+([A-Z][\w\s&.,\-—/()]{3,80})/i, "division"],
    [/\*\*Project:?\*\*\s*(.+)/i, "project"],
    [/\bProject[:\s]+([A-Z][\w\s&.,\-—/()]{3,100})/i, "project"],
    [/\*\*Champion:?\*\*\s*(.+)/i, "champion"],
    [/\bChampion[:\s]+([A-Z][\w\s.,\-]{3,60})/i, "champion"],
    [/\*\*Critical\s*(?:Project\s*)?Issue:?\*\*\s*(.+)/i, "criticalIssue"],
    [/\bCritical\s*(?:Project\s*)?Issue[:\s]+(.+)/i, "criticalIssue"],
    [/\*\*Solution:?\*\*\s*(.+)/i, "solution"],
    [/\bSolution[:\s]+([A-Z][\w\s&.,\-—/()]{5,200})/i, "solution"],
    [/\*\*Advantage:?\*\*\s*(.+)/i, "advantage"],
    [/\bAdvantage[:\s]+(.+)/i, "advantage"],
    [/\*\*Case\s*Study:?\*\*\s*(.+)/i, "caseStudy"],
    [/\bCase\s*Study[:\s]+(.+)/i, "caseStudy"],
    [/\*\*State\s*(?:of\s*(?:the\s*)?)?Account:?\*\*\s*(.+)/i, "stateOfAccount"],
    [/\bState\s*of\s*(?:the\s*)?Account[:\s]+(.+)/i, "stateOfAccount"],
    [/\*\*Contact:?\*\*\s*(.+)/i, "contacts" as any],
    [/\bRole[:\s]+([A-Z][\w\s/—\-]{3,60})/i, "contacts" as any],
  ];

  for (const [pat, field] of fieldPatterns) {
    const m = pat.exec(raw);
    if (m && m[1]) {
      const val = m[1].trim().replace(/\*+$/g, "").trim();
      if (val.length < 3) continue;
      if (field === "contacts" as any) {
        result.contacts.push(val);
      } else {
        const key = field as keyof NormalizedInput;
        if (typeof result[key] === "string" && !(result[key] as string)) {
          (result as any)[key] = val;
        }
      }
    }
  }

  // ── 3. Extract ALT narratives and outlines ──────────────────────────
  const altOrgMatch = raw.match(/\*\*ALT\s*Narrative[:\s]*\*\*\s*([\s\S]*?)(?=\n\*\*|\n#{1,3}\s|$)/i)
    || raw.match(/ALT\s*Narrative[:\s]+([\s\S]*?)(?=\n\*\*|\n#{1,3}\s|\nNode\s+Outline|$)/i);
  if (altOrgMatch && !result.orgAlt) result.orgAlt = altOrgMatch[1].trim().slice(0, 500);

  const nodeOutMatch = raw.match(/\*\*Node\s*Outline[:\s]*\*\*\s*([\s\S]*?)(?=\n\*\*|\n#{1,3}\s|$)/i)
    || raw.match(/Node\s*Outline[:\s]+([\s\S]*?)(?=\n\*\*|\n#{1,3}\s|\nState|$)/i);
  if (nodeOutMatch) {
    result.orgNodeOutline = nodeOutMatch[1].trim().split(/\n/).map(l => l.replace(/^[-•]\s*/, "").trim()).filter(l => l.length > 5);
  }

  const flowOutMatch = raw.match(/\*\*Flow\s*Outline[:\s]*\*\*\s*([\s\S]*?)(?=\n\*\*|\n#{1,3}\s|$)/i)
    || raw.match(/Flow\s*Outline[:\s]+([\s\S]*?)(?=\n\*\*|\n#{1,3}\s|\nAction|$)/i);
  if (flowOutMatch) {
    result.archFlowOutline = flowOutMatch[1].trim().split(/\n/).map(l => l.replace(/^[-•]\s*/, "").trim()).filter(l => l.length > 10);
  }

  const archAltMatch = raw.match(/(?:Architecture|Solution)\s*(?:ALT\s*)?Narrative[:\s]+([\s\S]*?)(?=\n\*\*|\n#{1,3}\s|\nFlow|$)/i);
  if (archAltMatch && !result.archAlt) result.archAlt = archAltMatch[1].trim().slice(0, 500);

  // ── 4. Extract stakeholders from org chart Mermaid ──────────────────
  if (result.orgMermaid) {
    const nodeMatches = [...result.orgMermaid.matchAll(/\w+\["([^"]+)"\]/g)];
    for (const nm of nodeMatches) {
      const label = nm[1].replace(/<br>/gi, " ").trim();
      // Try to split "Title\nName" or "Name, Title"
      const parts = label.split(/\\n|\n|<br>/i).map(s => s.trim()).filter(Boolean);
      const nameOrRole = parts.join(" — ").slice(0, 60);
      const hasExecTitle = /\b(Director|Managing|Chief|Officer|VP|President|Head|CDO|CIO|CTO|CEO|CFO)\b/i.test(label);
      result.extraStakeholders.push({
        nameOrRole,
        title: hasExecTitle ? nameOrRole : "Stakeholder",
        influenceScore: hasExecTitle ? 80 : 55,
        stance: /champion|sponsor|advocate|CDO|CIO|CTO/i.test(label) ? "champion" : "neutral",
        contact: "",
        isChampion: /champion|sponsor|CDO|CIO|CTO/i.test(label),
        source: "[INPUT]",
      });
    }
  }

  // ── 5. Parse RACI tables ─────────────────────────────────────────────
  const raciBlock = raw.match(/RACI[:\s]*\n?\|[\s\S]*?\n\n/i)
    || raw.match(/\|.*Responsible.*Accountable[\s\S]*?\n\n/i);
  if (raciBlock) {
    const rows = raciBlock[0].split("\n").filter(l => l.includes("|") && !l.match(/^[\s|:-]+$/));
    for (let i = 1; i < rows.length; i++) { // skip header
      const cells = rows[i].split("|").map(c => c.trim()).filter(Boolean);
      if (cells.length >= 4) {
        result.raciRows.push({
          activity: cells[0] || "", responsible: cells[1] || "",
          accountable: cells[2] || "", consulted: cells[3] || "", informed: cells[4] || "",
        });
      }
    }
  }

  // ── 6. Parse Action Items tables or bullet lists ────────────────────
  const aiBlock = raw.match(/Action\s*Items?[:\s]*\n([\s\S]*?)(?=\n#{1,3}\s|\nRACI|\n\*\*RACI|$)/i);
  if (aiBlock) {
    const aiLines = aiBlock[1].split("\n").filter(l => l.trim().length > 10);
    let idx = 0;
    for (const line of aiLines) {
      if (line.match(/^[\s|:-]+$/) || line.match(/^\|.*#.*Action/i)) continue; // skip table headers/separators
      const cells = line.includes("|") ? line.split("|").map(c => c.trim()).filter(Boolean) : null;
      if (cells && cells.length >= 2) {
        idx++;
        result.actionItems.push({
          index: idx,
          action: cells[1] || cells[0],
          owner: cells[2] || "",
          deadline: cells[3] || "",
          source: "[INPUT]",
        });
      } else {
        const bullet = line.replace(/^[-•*\d.)\s]+/, "").trim();
        if (bullet.length > 10) {
          idx++;
          result.actionItems.push({ index: idx, action: bullet, owner: "", deadline: "", source: "[INPUT]" });
        }
      }
    }
  }

  return result;
}

// ─── Parse ────────────────────────────────────────────────────────────────

export function parseContext(input: string, webSnippets: WebSnippet[] = [], mode: "pipeline"|"manual" = "manual"): ParsedContext {
  // Stage 0: Normalize structured input (markdown, SE Diligence output, tables)
  const norm = normalizeInput(input);

  // Stage 1: Regex extraction on cleaned text (Mermaid/tables stripped)
  const lines = norm.cleanedText.split(/[.\n]+/).map(l => l.trim()).filter(l => l.length > 5);
  const allLines = [...lines, ...webSnippets.map(w => w.snippet).join("\n").split(/[.\n]+/).filter(l => l.length > 5)];

  const accountMatch = !norm.account ? (ACCOUNT_PAT.exec(norm.cleanedText) || ACCOUNT_PAT2.exec(norm.cleanedText)) : null;
  const divMatch     = !norm.division ? DIV_PAT.exec(norm.cleanedText) : null;
  const projMatch    = !norm.project ? PROJ_PAT.exec(norm.cleanedText) : null;
  const sector       = detectSector(input + webSnippets.map(w => w.snippet).join(" "));

  const budget   = allLines.filter(l => BUDGET_SIG.test(l)).length;
  const timing   = allLines.filter(l => TIMING_SIG.test(l)).length;
  const traction = allLines.filter(l => TRACTION_SIG.test(l)).length;

  // Merge stakeholders: normalizer's org chart nodes + regex extraction
  const regexStakeholders = extractStakeholders(lines);
  const mergedStakeholders = mergeStakeholders(norm.extraStakeholders, regexStakeholders);

  // Account name: normalizer > ACCOUNT_PAT (group 1) > ACCOUNT_PAT2 (group 1) > assumption
  const extractedAccount = norm.account || accountMatch?.[1]?.trim() || "";

  return {
    rawInput: input,
    accountName: extractedAccount || "[ASSUMPTION — verify account name]",
    division:    norm.division || divMatch?.[2]?.trim() || "",
    project:     norm.project || projMatch?.[2]?.trim() || "",
    sector,
    stakeholders: mergedStakeholders,
    signals:      extractSignals(lines, webSnippets),
    opportunities: buildOpportunityFromDomain(sector, budget, timing, traction, lines.length, input),
    projects:     extractProjects(lines, webSnippets, sector),
    webContext: webSnippets,
    planMode: mode,
    _norm: norm,
  };
}

// Merge two stakeholder lists, deduplicating by name similarity
function mergeStakeholders(primary: Stakeholder[], secondary: Stakeholder[]): Stakeholder[] {
  const result = [...primary];
  const seenLower = new Set(primary.map(s => s.nameOrRole.toLowerCase().slice(0, 20)));
  for (const s of secondary) {
    if (!seenLower.has(s.nameOrRole.toLowerCase().slice(0, 20))) {
      result.push(s);
      seenLower.add(s.nameOrRole.toLowerCase().slice(0, 20));
    }
  }
  return result;
}

function extractStakeholders(lines: string[]): Stakeholder[] {
  const result: Stakeholder[] = [];
  const seen = new Set<string>();
  for (const line of lines) {
    TITLE_PAT.lastIndex = 0;
    for (const m of [...line.matchAll(TITLE_PAT)]) {
      const key = m[0].toLowerCase().trim();
      if (seen.has(key)) continue;
      seen.add(key);
      NAME_PAT.lastIndex = 0;
      const nameMatch = line.match(NAME_PAT);
      const displayName = nameMatch ? `${nameMatch[0]} (${m[0]})` : m[0];
      result.push({
        nameOrRole: displayName,
        title: m[0],
        influenceScore: /\b(CIO|CTO|CEO|CFO|COO|CISO|General\s+Manager)\b/i.test(m[0]) ? 90
                      : /\bVP\b/i.test(m[0]) ? 75
                      : /\bDirector\b|Programme\s+Manager|Country\s+Manager/i.test(m[0]) ? 65 : 50,
        stance: CHAMPION_PAT.test(line) ? "champion" : RISK_PAT.test(line) ? "risk" : "neutral",
        contact: "",
        isChampion: CHAMPION_PAT.test(line),
        source: "[INPUT]",
      });
    }
  }
  return result;
}

function extractSignals(lines: string[], web: WebSnippet[]): Signal[] {
  const result: Signal[] = [];
  for (const line of lines) {
    if (line.length < 15) continue;
    const conf = HIGH_CONF.test(line) ? "high" : MED_CONF.test(line) ? "medium" : null;
    if (conf) result.push({ claim: line.slice(0, 150), confidence: conf, source: "Input notes", tag: "[INPUT]" });
    if (TENDER_PAT.test(line)) result.push({ claim: line.slice(0, 150), confidence: "high", source: "Procurement signal", tag: "[INPUT]" });
  }
  for (const w of web) {
    if (w.snippet.length > 20)
      result.push({ claim: w.snippet.slice(0, 150), confidence: "medium", source: w.url, tag: "[WEB]" });
  }
  return result;
}

// ─── Project extraction — PROJECT-001 ───────────────────────────────────

function extractProjects(lines: string[], web: WebSnippet[], sector: string): ProjectEntry[] {
  const projects: ProjectEntry[] = [];
  const seen = new Set<string>();

  // Merge input lines + web snippets for scanning
  const allLines = [...lines, ...web.map(w => `${w.title} ${w.snippet}`)];

  for (const line of allLines) {
    // Look for explicit project references
    const projMatches = [...line.matchAll(/\b(?:project|programme|program|initiative|phase|contract|package|lot|tender)[:\s]+([A-Z][A-Za-z0-9\s&.,\-#/()]{3,60})/gi)];

    for (const pm of projMatches) {
      const name = pm[1].trim().replace(/\s+/g, " ").slice(0, 60);
      const key = name.toLowerCase();
      if (seen.has(key) || name.length < 4) continue;
      seen.add(key);

      // Detect phase
      let phase = "Unknown";
      for (const [pat, label] of PHASE_PATS) {
        if (pat.test(line)) { phase = label; break; }
      }

      // Detect status
      let status: ProjectEntry["status"] = "unknown";
      for (const [pat, st] of STATUS_PATS) {
        if (pat.test(line)) { status = st; break; }
      }

      // Detect Bentley product fit
      const bentleyFit: string[] = [];
      for (const [pat, product] of BENTLEY_PRODUCTS) {
        if (pat.test(line) && !bentleyFit.includes(product)) bentleyFit.push(product);
      }
      // If no explicit product, infer from sector
      if (bentleyFit.length === 0) {
        const sectorDefaults: Record<string, string[]> = {
          "Infrastructure & Assets": ["AssetWise APM", "OpenUtilities", "Geospatial / GIS"],
          "Buildings & Construction": ["BIM Platform", "CDE (ProjectWise)", "SYNCHRO 4D/5D"],
          "Digital Twin & Operations": ["iTwin Platform", "CDE (ProjectWise)", "AssetWise APM"],
          "Mining & Geosciences": ["PLAXIS 2D/3D", "Leapfrog", "GeoStudio", "gINT"],
          "Rail & Transportation": ["OpenRoads Designer", "OpenRail Designer", "CDE (ProjectWise)", "SYNCHRO 4D/5D"],
          "Plant & Process": ["SACS", "AutoPIPE", "CDE (ProjectWise)"],
        };
        bentleyFit.push(...(sectorDefaults[sector] ?? ["CDE (ProjectWise)"]));
      }

      const isFromWeb = web.some(w => w.snippet.includes(name.slice(0, 20)) || w.title.includes(name.slice(0, 20)));
      const confidence: "high" | "medium" | "low" = HIGH_CONF.test(line) ? "high" : MED_CONF.test(line) ? "medium" : "low";

      projects.push({
        id: `proj-${projects.length + 1}`,
        name,
        status,
        phase,
        bentleyFit,
        confidence,
        source: isFromWeb ? "[WEB]" : "[INPUT]",
      });
    }
  }

  // Also look for named tenders (GeBIZ, PhilGEPS patterns)
  for (const line of allLines) {
    const tenderMatches = [...line.matchAll(/\b(GeBIZ|PhilGEPS|LPSE|KONEPS)\s*[:#]?\s*([A-Z0-9][A-Za-z0-9\s&.,\-#/]{3,50})/gi)];
    for (const tm of tenderMatches) {
      const name = `${tm[1]}: ${tm[2].trim()}`;
      const key = name.toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);
      projects.push({
        id: `proj-${projects.length + 1}`,
        name,
        status: "active_tender",
        phase: "Tender / Procurement",
        bentleyFit: ["CDE (ProjectWise)"],
        confidence: "high",
        source: "[INPUT]",
      });
    }
  }

  return projects.slice(0, 10);
}

// ─── Red flag detection ───────────────────────────────────────────────────

function detectRedFlags(ctx: ParsedContext): RedFlag[] {
  const flags: RedFlag[] = [];
  const hasBudget   = ctx.signals.some(s => BUDGET_SIG.test(s.claim));
  const hasTiming   = ctx.signals.some(s => TIMING_SIG.test(s.claim));
  const hasChampion = ctx.stakeholders.some(s => s.isChampion);
  const stakeCount  = ctx.stakeholders.length;

  // Standard flags
  if (!hasBudget)    flags.push({ flag: "No budget signal extracted from input", likelihood: "high", impact: "high", mitigation: "Confirm with CFO/controller within 30 days; request FY planning doc" });
  if (!hasTiming)    flags.push({ flag: "No timing/deadline signal detected", likelihood: "medium", impact: "medium", mitigation: "Identify procurement window or fiscal calendar alignment" });
  if (!hasChampion)  flags.push({ flag: "No executive sponsor or champion identified", likelihood: "high", impact: "high", mitigation: "Build multithread — target CIO/CTO directly with business case" });
  if (stakeCount < 2) flags.push({ flag: "Single-thread risk — only one stakeholder identified", likelihood: "high", impact: "high", mitigation: "Map additional influencers; avoid single point of failure" });

  // Competitor-specific flags using knowledge graph — capped to avoid noise
  const detectedProducts = detectProductsInText(ctx.rawInput);
  const detectedCompetitors = detectCompetitorsInText(ctx.rawInput);

  for (const comp of detectedCompetitors.slice(0, 3)) {
    // Find which Bentley product this competitor threatens
    const threatened = PRODUCT_KNOWLEDGE.filter(pk => pk.competitors.some(c => c.toLowerCase().includes(comp.toLowerCase().split(" ")[0])));
    if (threatened.length > 0) {
      const products = threatened.map(p => p.name).join(", ");
      const differentiators = threatened.map(p => p.differentiator).join("; ");
      flags.push({
        flag: `Competitor detected: ${comp} — threatens ${products}`,
        likelihood: "medium", impact: "high",
        mitigation: `Displacement strategy: ${differentiators.slice(0, 200)}`
      });
    } else {
      flags.push({ flag: `Competitor presence: ${comp}`, likelihood: "medium", impact: "high", mitigation: "Prepare displacement analysis; activate reference customers" });
    }
  }
  if (detectedCompetitors.length > 3) {
    flags.push({ flag: `${detectedCompetitors.length - 3} additional competitor(s) detected`, likelihood: "medium", impact: "medium", mitigation: "Review full competitor landscape in discovery workshop" });
  }

  // Product integration gap flags — capped to top 3
  if (detectedProducts.length >= 2) {
    let gapCount = 0;
    for (let i = 0; i < detectedProducts.length && gapCount < 3; i++) {
      for (let j = i + 1; j < detectedProducts.length && gapCount < 3; j++) {
        const a = detectedProducts[i];
        const b = detectedProducts[j];
        if (!a.integratesWith.some(x => x.toLowerCase().includes(b.name.toLowerCase().split(" ")[0]))) {
          flags.push({
            flag: `Integration gap: ${a.name} and ${b.name} may need ProjectWise/iTwin as bridge`,
            likelihood: "low", impact: "medium",
            mitigation: `Ensure CDE (ProjectWise) and iTwin federation are included in the solution to connect ${a.name} with ${b.name}`
          });
          gapCount++;
        }
      }
    }
  }

  return flags;
}

// ─── Compose ─────────────────────────────────────────────────────────────

export function composePlan(ctx: ParsedContext, llmPlan?: Partial<Plan>, selectedId?: string): Plan {
  // Access normalizer data if available
  const norm = ctx._norm;

  const opps = ctx.opportunities.map((o,i) => ({
    ...o, selected: selectedId ? o.id === selectedId : i === 0,
  }));
  const opp = opps.find(o => o.selected) ?? opps[0];
  const champ = ctx.stakeholders.find(s => s.isChampion);
  const topStake = ctx.stakeholders.find(s => s.influenceScore >= 75);
  const assumptions: Assumption[] = [];
  const verifyDate = new Date(Date.now() + 14*24*60*60*1000).toISOString().slice(0,10);

  function assume(field: string, value: string, grounded: boolean): string {
    if (!grounded || !value || value.includes("ASSUMPTION")) {
      assumptions.push({ field, value: value || "[not extracted]", verifyBy: verifyDate });
      return value.includes("[") ? value : `[ASSUMPTION — verify by ${verifyDate}] ${value}`;
    }
    return value;
  }

  // Fields: LLM > normalizer > regex > assumption
  const account = llmPlan?.account ?? (ctx.accountName.includes("ASSUMPTION")
    ? assume("account", ctx.accountName, false) : ctx.accountName);

  const division = llmPlan?.division ?? (norm?.division || ctx.division || "");
  const project  = llmPlan?.project  ?? (norm?.project || ctx.project || "");

  const stateOfAccount = llmPlan?.stateOfAccount ?? (norm?.stateOfAccount || assume("stateOfAccount",
    ctx.signals.filter(s=>s.confidence==="high").length > 2 ? "Active — high-confidence signals"
    : ctx.signals.length > 0 ? "Early stage — signals present, verify recency"
    : "No engagement signals — cold start", ctx.signals.length > 0));

  // Build solution and advantage from product knowledge when available
  const detectedPK = detectProductsInText(ctx.rawInput);
  const pkSolution = detectedPK.length > 0
    ? detectedPK.map(p => `${p.name} (${p.category})`).join(" + ") + " integrated workflow"
    : null;
  const pkAdvantage = detectedPK.length > 0
    ? detectedPK.map(p => p.differentiator).slice(0, 3).join(". ")
    : null;

  const solution     = llmPlan?.solution     ?? (norm?.solution || (pkSolution ? pkSolution : assume("solution", `${opp.title} programme`, opp.grounded)));
  const advantage    = llmPlan?.advantage    ?? (norm?.advantage || (pkAdvantage ? pkAdvantage : assume("advantage", "Open ecosystem, no vendor lock-in, deterministic audit trail", false)));
  const caseStudy    = llmPlan?.caseStudy    ?? (norm?.caseStudy || assume("caseStudy", "[ASSUMPTION — add reference customer]", false));
  const champion     = champ?.nameOrRole ?? llmPlan?.champion ?? (norm?.champion || assume("champion", "[ASSUMPTION — identify champion]", false));
  const critIssue    = llmPlan?.criticalProjectIssue ?? (norm?.criticalIssue || `${opp.problem}. Prerequisite to unlocking ${opp.title.toLowerCase()}.`);

  // Diagrams: passthrough input Mermaid > deterministic generation
  const orgMermaid   = norm?.orgMermaid || buildOrgMermaid(ctx.stakeholders);
  const orgAlt       = llmPlan?.orgAlt ?? (norm?.orgAlt || (ctx.stakeholders.length > 0
    ? `Org chart: ${ctx.stakeholders.length} roles identified. Top influence: ${ctx.stakeholders.slice(0,3).map(s=>s.nameOrRole).join(", ")}.`
    : "[ASSUMPTION — no stakeholders extracted; org chart uses placeholder nodes]"));
  const orgNodeOutline = llmPlan?.orgNodeOutline ?? (norm?.orgNodeOutline?.length ? norm.orgNodeOutline : (ctx.stakeholders.length > 0
    ? ctx.stakeholders.map(s => `${s.nameOrRole} — influence ${s.influenceScore} — ${s.stance}${s.isChampion?" ★":""} — source: ${s.source}`)
    : ["[ASSUMPTION — populate from account mapping session]"]));

  const archMermaid    = norm?.archMermaid || buildSolutionMap(ctx, opp);
  const archAlt        = llmPlan?.archAlt ?? (norm?.archAlt || `[INFERRED] ${opp.title} — solution architecture built from detected Bentley products for ${ctx.sector}. Products flow from design/subsurface tools through CDE (ProjectWise/BIC) with SSO/RBAC/Audit to delivery and operations.`);
  const archFlowOutline = llmPlan?.archFlowOutline ?? (norm?.archFlowOutline?.length ? norm.archFlowOutline : [
    `[INFERRED] L1 Design → L2 CDE: ${opp.problem} — source systems publish design/survey/model data to ProjectWise/BIC`,
    `[INFERRED] L2 CDE → L3 iTwin: Federation services with SSO, RBAC, audit lineage, data residency controls`,
    `[INFERRED] L3 iTwin → L4 Execution: ${opp.title} — SYNCHRO 4D/5D planning, cost, field mobile`,
    `[INFERRED] L3 iTwin → L5 Analytics: Domain-specific analysis (structural, hydraulic, geotechnical, telemetry)`,
    `[INFERRED] L4/L5 → L6 Operations: AssetWise APM — predictive maintenance, reliability, KPI dashboards`,
    `[INFERRED] L2 CDE ↔ Integrations: ERP, GIS, SCADA, IoT, CMMS — bidirectional data contracts`,
  ]);

  const roles: RoleEntry[] = ctx.stakeholders.map(s => ({
    role: s.title, name: s.nameOrRole, influenceScore: s.influenceScore, stance: s.stance,
  }));

  const contacts = ctx.stakeholders.filter(s => s.influenceScore >= 50).map(s => s.contact || s.nameOrRole);

  const knownRoles = ctx.stakeholders.map(s => s.nameOrRole);
  const r = (fallback: string) => knownRoles[0] ?? fallback;

  const actionItems: ActionItem[] = llmPlan?.actionItems ?? (norm?.actionItems?.length ? norm.actionItems : [
    { index:1, action:"Confirm executive sponsor and technical champion", owner: topStake?.nameOrRole ?? "Account Lead",   deadline:"[ASSUMPTION]", source:"[INFERRED]" },
    { index:2, action:`Discovery workshop — ${opp.problem.slice(0,60).toLowerCase()}`, owner:"SE",                        deadline:"[ASSUMPTION]", source:"[INFERRED]" },
    { index:3, action:"Quantify ROI: time, cost, risk reduction, ESG impact",           owner:"AE",                        deadline:"[ASSUMPTION]", source:"[INFERRED]" },
    { index:4, action:"Align success criteria with all stakeholders",                   owner:"Account Lead",               deadline:"[ASSUMPTION]", source:"[INFERRED]" },
    { index:5, action:"Publish phased delivery plan with milestones",                   owner:"SE",                        deadline:"[ASSUMPTION]", source:"[INFERRED]" },
    { index:6, action:"Executive review and human sign-off gate",                       owner:champion,                    deadline:"[ASSUMPTION]", source:"[INFERRED]" },
  ]);

  const raci: RACIRow[] = llmPlan?.raci ?? (norm?.raciRows?.length ? norm.raciRows : [
    { activity:"Executive alignment", responsible:r("Account Lead"), accountable:"AE",          consulted:champion,         informed:"All stakeholders" },
    { activity:"Discovery workshop",  responsible:"SE",              accountable:r("Acct Lead"), consulted:"Tech champion",   informed:r("VP") },
    { activity:"Business case",       responsible:"AE",              accountable:r("Acct Lead"), consulted:"Finance",         informed:champion },
    { activity:"Solution design",     responsible:"SE",              accountable:r("Sol Dir."),  consulted:"Tech team",       informed:"All" },
    { activity:"Sign-off gate",       responsible:champion,          accountable:champion,       consulted:"Legal/InfoSec",   informed:"Board" },
  ]);

  const sourceTags = [...new Set([
    "[INPUT]",
    ...(ctx.webContext.length > 0 ? ["[WEB]"] : []),
    ...(llmPlan ? ["[LLM]"] : []),
    ...(assumptions.length > 0 ? ["[ASSUMPTION]"] : []),
  ])];

  const totalFields = 12;
  const groundedFields = Math.max(0, totalFields - assumptions.length);
  const groundingScore = Math.round(groundedFields / totalFields * 100);

  const redFlags = llmPlan?.redFlags ?? detectRedFlags(ctx);

  return {
    planMode: ctx.planMode,
    account, division, project, sector: ctx.sector,
    stateOfAccount, orgMermaid, orgAlt, orgNodeOutline,
    roles, contacts, champion,
    criticalProjectIssue: critIssue, solution, advantage, caseStudy,
    archMermaid, archAlt, archFlowOutline,
    actionItems, raci,
    opportunities: opps, selectedOpportunity: opp,
    signals: ctx.signals, sourceTags, groundingScore, assumptions, redFlags,
    projects: ctx.projects,
    mindMap: buildMindMap(ctx, { account, champion, solution, criticalProjectIssue: critIssue }, opp),
  };
}

// ─── Org chart diagram ────────────────────────────────────────────────────

function buildOrgMermaid(stakeholders: Stakeholder[]): string {
  const top = [...stakeholders].sort((a,b) => b.influenceScore - a.influenceScore).slice(0, 7);
  if (top.length === 0) {
    return [
      "graph TD",
      "  classDef default fill:#fff,stroke:#000,stroke-width:1px,color:#000",
      '  A["[ASSUMPTION]\\nExecutive Sponsor"]',
      '  B["[ASSUMPTION]\\nTechnical Champion"]',
      '  C["[ASSUMPTION]\\nBudget Owner"]',
      '  D["[ASSUMPTION]\\nImplementation Lead"]',
      "  A --> B",
      "  A --> C",
      "  B --> D",
    ].join("\n");
  }
  const lines = ["graph TD"];
  const ids = top.map((_,i) => `N${i}`);
  lines.push("  classDef default fill:#fff,stroke:#000,stroke-width:1px,color:#000");

  // Tier nodes: executives (>=75), managers (>=50), others — shape conveys tier
  top.forEach((s,i) => {
    const label = s.nameOrRole.replace(/"/g,"'").slice(0,36);
    const shape = s.influenceScore >= 80 ? `["${label}"]` : s.influenceScore >= 60 ? `("${label}")` : `(["${label}"])`;
    lines.push(`  ${ids[i]}${shape}`);
  });

  // Edges: solid for reporting (higher influence → lower), dotted for lateral influence
  for (let i = 0; i < top.length; i++) {
    for (let j = i + 1; j < top.length; j++) {
      const gap = top[i].influenceScore - top[j].influenceScore;
      if (gap >= 15) {
        // Clear hierarchy — solid reporting line
        lines.push(`  ${ids[i]} --> ${ids[j]}`);
        break; // each node reports to its nearest superior only
      } else if (gap > 0 && gap < 15) {
        // Lateral influence — dotted line
        lines.push(`  ${ids[i]} -.->|influence| ${ids[j]}`);
        break;
      }
    }
  }

  return lines.join("\n");
}

// ─── Solution map — built from ACTUAL detected products, not templates ───

function buildSolutionMap(ctx: ParsedContext, opp: Opportunity): string {
  // Scan input for actual Bentley products mentioned
  const detected: string[] = [];
  const fullText = ctx.rawInput + " " + ctx.webContext.map(w => w.snippet).join(" ");
  for (const [pat, product] of BENTLEY_PRODUCTS) {
    if (pat.test(fullText) && !detected.includes(product)) detected.push(product);
  }

  // If nothing detected, use opportunity title + sector defaults
  if (detected.length === 0) {
    const defaults: Record<string, string[]> = {
      "Infrastructure & Assets": ["AssetWise APM", "OpenUtilities", "ProjectWise"],
      "Buildings & Construction": ["OpenBuildings Designer", "ProjectWise", "SYNCHRO 4D/5D"],
      "Digital Twin & Operations": ["iTwin Platform", "ProjectWise", "AssetWise APM"],
      "Mining & Geosciences": ["Leapfrog", "PLAXIS 2D/3D", "ProjectWise"],
      "Rail & Transportation": ["OpenRoads Designer", "ProjectWise", "SYNCHRO 4D/5D"],
      "Plant & Process": ["SACS", "AutoPIPE", "ProjectWise"],
      "Enterprise": ["ProjectWise", "iTwin Platform"],
    };
    detected.push(...(defaults[ctx.sector] ?? defaults["Enterprise"]));
  }

  // Classify products into layers
  const design: string[] = [];
  const platform: string[] = [];
  const delivery: string[] = [];
  const subsurface: string[] = [];
  const ops: string[] = [];

  for (const p of detected) {
    if (/Leapfrog|PLAXIS|GeoStudio|Oasis|gINT|OpenGround|Imago|Seequent/i.test(p)) subsurface.push(p);
    else if (/ProjectWise|BIC|CDE|Seequent Central/i.test(p)) platform.push(p);
    else if (/iTwin|Cesium|ContextCapture|3D Tiles/i.test(p)) platform.push(p);
    else if (/SYNCHRO|4D|5D/i.test(p)) delivery.push(p);
    else if (/AssetWise|APM/i.test(p)) ops.push(p);
    else design.push(p);
  }

  // Ensure at least CDE in platform
  if (platform.length === 0) platform.push("ProjectWise");

  const lines: string[] = ["flowchart LR"];
  lines.push("  classDef default fill:#fff,stroke:#000,stroke-width:1px,color:#000");
  lines.push("  classDef group fill:#fff,stroke:#000,stroke-width:1.5px");

  let nodeId = 0;
  const id = () => `P${nodeId++}`;
  const designIds: string[] = [];
  const subIds: string[] = [];
  const platIds: string[] = [];
  const delivIds: string[] = [];
  const opsIds: string[] = [];

  // Use subgraphs for layer structure instead of colors
  if (design.length > 0) {
    lines.push("  subgraph Design");
    for (const p of design) { const n = id(); designIds.push(n); lines.push(`    ${n}["${p}"]`); }
    lines.push("  end");
  }
  if (subsurface.length > 0) {
    lines.push("  subgraph Subsurface");
    for (const p of subsurface) { const n = id(); subIds.push(n); lines.push(`    ${n}["${p}"]`); }
    lines.push("  end");
  }
  if (platform.length > 0) {
    lines.push("  subgraph Platform");
    for (const p of platform) { const n = id(); platIds.push(n); lines.push(`    ${n}["${p}"]`); }
    lines.push("  end");
  }
  if (delivery.length > 0) {
    lines.push("  subgraph Delivery");
    for (const p of delivery) { const n = id(); delivIds.push(n); lines.push(`    ${n}["${p}"]`); }
    lines.push("  end");
  }
  if (ops.length > 0) {
    lines.push("  subgraph Operations");
    for (const p of ops) { const n = id(); opsIds.push(n); lines.push(`    ${n}["${p}"]`); }
    lines.push("  end");
  }

  // Connect: design → platform, subsurface → platform, platform → delivery, delivery → ops
  const allInputs = [...designIds, ...subIds];
  for (const src of allInputs) {
    if (platIds[0]) lines.push(`  ${src} --> ${platIds[0]}`);
  }
  // Chain platform nodes
  for (let i = 0; i < platIds.length - 1; i++) lines.push(`  ${platIds[i]} --- ${platIds[i+1]}`);
  // Platform → delivery
  for (const d of delivIds) {
    lines.push(`  ${platIds[platIds.length - 1] || platIds[0]} --> ${d}`);
  }
  // Delivery → ops
  for (const o of opsIds) {
    const src = delivIds[delivIds.length - 1] || platIds[platIds.length - 1];
    if (src) lines.push(`  ${src} --> ${o}`);
  }

  return lines.join("\n");
}

// ─── Mind map — connects account, opportunity, products, people, signals ─

function buildMindMap(ctx: ParsedContext, plan: { account: string; champion: string; solution: string; criticalProjectIssue: string }, opp: Opportunity): string {
  // Sanitize labels for mindmap — no parens, brackets, colons, or special chars in node text
  const mmSafe = (s: string) => s.replace(/[()[\]{}<>:;"'`|\\/#*★⚠]/g, "").replace(/\s+/g, " ").trim();
  const account = mmSafe(plan.account.replace(/\[.*?\]/g, "").trim().slice(0, 40)) || "Account";
  const champion = mmSafe(plan.champion.replace(/\[.*?\]/g, "").trim().slice(0, 40));
  const solution = mmSafe(plan.solution.replace(/\[.*?\]/g, "").trim().slice(0, 50));
  const issue = mmSafe(plan.criticalProjectIssue.replace(/\[.*?\]/g, "").trim().slice(0, 50));

  const lines: string[] = ["mindmap"];
  lines.push(`  root((${account}))`);

  // Opportunity branch
  lines.push(`    ${mmSafe(opp.title)}`);
  if (issue) lines.push(`      ${issue}`);
  if (solution) lines.push(`      ${solution}`);

  // Products branch — from actual detection
  const products: string[] = [];
  const fullText = ctx.rawInput;
  for (const [pat, product] of BENTLEY_PRODUCTS) {
    if (pat.test(fullText) && !products.includes(product)) products.push(product);
  }
  if (products.length > 0) {
    lines.push("    Products");
    for (const p of products.slice(0, 8)) lines.push(`      ${mmSafe(p)}`);
  }

  // Stakeholders branch
  if (ctx.stakeholders.length > 0) {
    lines.push("    Stakeholders");
    for (const s of ctx.stakeholders.slice(0, 5)) {
      const label = mmSafe(s.nameOrRole.slice(0, 35));
      lines.push(`      ${label}`);
    }
  }

  // Signals branch — top 3
  const topSignals = ctx.signals.filter(s => s.confidence === "high").slice(0, 3);
  if (topSignals.length > 0) {
    lines.push("    Signals");
    for (const s of topSignals) lines.push(`      ${mmSafe(s.claim.slice(0, 50))}`);
  }

  return lines.join("\n");
}

// ─── Web search query builder — FIX-GEN-002: dynamic year ────────────────

export function buildWebQueries(ctx: ParsedContext): string[] {
  const acc = ctx.accountName.includes("ASSUMPTION") ? "" : ctx.accountName;
  const queries: string[] = [];
  const year = new Date().getFullYear();
  const yearRange = `${year - 1} ${year}`;

  if (acc) {
    // ENGINE A — Opportunity discovery: who are they, what do they do, what are they buying
    queries.push(`${acc} leadership team executive management`);
    queries.push(`${acc} annual report revenue ${year}`);

    // ENGINE B — Validation: tenders, procurement, active projects
    queries.push(`${acc} tender procurement project ${yearRange}`);

    // ENGINE D — Competition: existing tech footprint
    queries.push(`${acc} Autodesk Hexagon Trimble Bentley software BIM`);

    // Sector-specific enrichment
    if (ctx.sector && ctx.sector !== "Enterprise") {
      queries.push(`${acc} ${ctx.sector} project ${yearRange}`);
    }
  }

  // Fallback: if no account name, search by sector
  if (queries.length === 0) {
    queries.push(`${ctx.sector} infrastructure project tender ${yearRange}`);
  }

  return queries.slice(0, 5);
}

// ─── Web-to-stakeholder extraction — ENGINE A enrichment ─────────────────

export function extractStakeholdersFromWeb(webSnippets: WebSnippet[]): Stakeholder[] {
  const result: Stakeholder[] = [];
  const seen = new Set<string>();

  for (const w of webSnippets) {
    const text = `${w.title} ${w.snippet}`;

    // Look for "Name, Title" or "Name — Title" or "Title Name" patterns in web results
    const patterns = [
      // "John Smith, Chief Executive Officer" or "John Smith — CEO"
      /\b([A-Z][a-z]{1,18}\s+(?:[A-Z][a-z]{1,18}\s*){1,3}),?\s*(?:–|—|-|,)\s*((?:Chief|Group|Managing|Executive|Senior|Vice|Deputy)\s+(?:\w+\s*){1,4}(?:Officer|Director|President|Manager))/gi,
      // "CEO John Smith" or "Director of Engineering Jane Doe"
      /\b((?:CEO|CTO|CFO|COO|CIO|CISO|CDO|MD|VP|SVP|EVP|President|Director|Head)\s*(?:of\s+\w+)?)\s*[:\s]+([A-Z][a-z]{1,18}\s+[A-Z][a-z]{1,18})/gi,
    ];

    for (const pat of patterns) {
      pat.lastIndex = 0;
      for (const m of [...text.matchAll(pat)]) {
        const isNameFirst = /^[A-Z][a-z]/.test(m[1]);
        const name = isNameFirst ? m[1].trim() : m[2].trim();
        const title = isNameFirst ? m[2].trim() : m[1].trim();
        const key = name.toLowerCase();
        if (seen.has(key) || name.length < 4) continue;
        seen.add(key);

        const isExec = /Chief|Director|President|VP|Managing|Head|Officer/i.test(title);
        result.push({
          nameOrRole: `${name} (${title})`,
          title,
          influenceScore: isExec ? 80 : 60,
          stance: "neutral",
          contact: "",
          isChampion: false,
          source: `[WEB] ${w.url.slice(0, 60)}`,
        });
      }
    }
  }

  return result.slice(0, 10);
}

// ─── ENGINE A-F extraction system prompt ─────────────────────────────────

export function buildLLMExtractionPrompt(input: string, webContext: string, sector: string): string {
  return `You are a strategic account planning analyst running a 6-engine intelligence stack for a ${sector} account.

ENGINES YOU MUST RUN (internally, do not output your reasoning):
ENGINE A — OPPORTUNITY DISCOVERY: Identify the single best opportunity maximising Budget×Timing×Traction×Value from all signals. Consider: CRM telemetry, license variance, project storage, procurement signals (GeBIZ/PhilGEPS/LPSE/KONEPS/tenders), multilaterals (ADB/AIIB/JICA/WB), regulatory triggers (BIM mandate/ESG/safety), corporate filings, hiring signals, competitor footprints (Autodesk/Hexagon/Trimble/Aveva/ESRI/PTC), executive OKRs, asset lifecycle gaps.
ENGINE B — VALIDATION: Every claim needs ≥2 independent time-stamped sources. Stale data (>90 days) must be flagged. BudgetScore: verify capex/opex mapping. TimingScore: identify immovable windows. TractionScore: sponsor strength and multithread depth.
ENGINE C — SOLUTION ENGINEERING: Architecture blueprint with roles, data flows, interop/API fit, consumption KPIs, adoption ladder, quantified business case (time/cost/risk/ESG). No FX conversion — use local currency as stated in input only.
ENGINE D — COMPETITION & PROOF: Identify displacement hooks, migration risk, evidence library. Reference specific competitors mentioned. Flag open ecosystem advantage and anti-lock-in.
ENGINE E — COMMERCIAL/RISK/GOVERNANCE: Consumption forecast (P10/P50/P90) in local currency only. Legal/InfoSec controls (DPA/SoW/SSO/RBAC/residency). Change management. Red flags: budget age, price variance >10%, single-thread risk.
ENGINE F — QA: No unverifiable claims. All numerical values cited. Names/titles verified against input. PII minimised. ISO-8601 dates. [ASSUMPTION] tags with verify-by dates. Human-authentic language — concrete nouns, specific numbers, zero hype.

RULES (STRICT):
- Return ONLY valid JSON. No markdown fences. No commentary outside JSON.
- If a field cannot be extracted from the input with confidence → set to null. Do NOT invent.
- All role names in RACI must appear in the input or be null.
- Do NOT generate Mermaid syntax — diagrams are handled deterministically.
- Mark any inference with "[INFERRED]" prefix on that specific value string.
- [ASSUMPTION] tags must include a verify-by date in ISO-8601 format.
- Local currency amounts only — no USD conversion unless input uses USD.

OUTPUT SCHEMA (return ONLY this JSON object):
{
  "account": string | null,
  "division": string | null,
  "project": string | null,
  "stateOfAccount": string | null,
  "sector": string | null,
  "champion": string | null,
  "criticalProjectIssue": string | null,
  "solution": string | null,
  "advantage": string | null,
  "caseStudy": string | null,
  "orgAlt": string | null,
  "orgNodeOutline": string[] | null,
  "archAlt": string | null,
  "archFlowOutline": string[] | null,
  "actionItems": [{"index": number, "action": string, "owner": string, "deadline": string | null, "source": string}] | null,
  "raci": [{"activity": string, "responsible": string, "accountable": string, "consulted": string, "informed": string}] | null,
  "redFlags": [{"flag": string, "likelihood": "high"|"medium"|"low", "impact": "high"|"medium"|"low", "mitigation": string}] | null
}

ACCOUNT NOTES:
${input.slice(0, 7000)}

${webContext ? `WEB CONTEXT (time-stamped public sources — cite URL if used):\n${webContext.slice(0, 3000)}` : ""}`;
}
