// rag.ts — Lightweight local RAG for Scale Up
// Deterministic keyword index. No embeddings. No LLM. No drift.
// User points to a folder → Sync builds a JSON manifest → Generate queries it.

import * as pako from "pako";

// ─── Types ───────────────────────────────────────────────────────────────

export interface RAGConfig {
  folderPath: string;       // user-selected folder
  lastSync: string;         // ISO timestamp
  intent: string;           // what the user is trying to do — the drift anchor
  docCount: number;
  totalSizeKb: number;
}

export interface RAGDocument {
  path: string;
  filename: string;
  modified: string;
  sizeKb: number;
  summary: string;          // first ~500 chars of extracted text
  keywords: Record<string, number>;  // term → frequency
  relevance: number;        // 0–1 score vs current intent
  used: boolean;            // was this doc pulled into a plan generation?
  lastUsed: string;         // ISO timestamp of last use
}

export interface RAGIndex {
  version: 1;
  createdAt: string;
  updatedAt: string;
  intent: string;
  folderPath: string;
  documents: RAGDocument[];
  stats: {
    totalDocs: number;
    relevantDocs: number;
    totalSizeKb: number;
    syncDurationMs: number;
  };
}

export interface RAGQueryResult {
  chunks: { filename: string; text: string; relevance: number }[];
  docsUsed: number;
  docsSkipped: number;
  totalChars: number;
}

// ─── Constants ───────────────────────────────────────────────────────────

const SUPPORTED_EXTENSIONS = new Set([
  ".txt", ".md", ".csv", ".json",
  ".docx", ".xlsx",
  // PDF text extraction is limited — we do best-effort
]);

const STOP_WORDS = new Set([
  "the","a","an","and","or","but","in","on","at","to","for","of","with",
  "is","are","was","were","be","been","being","have","has","had","do",
  "does","did","will","would","could","should","may","might","shall",
  "can","this","that","these","those","it","its","i","we","you","he",
  "she","they","my","our","your","his","her","their","not","no","from",
  "by","as","if","then","than","so","very","just","also","about","into",
  "over","after","before","between","through","during","each","all",
  "both","few","more","most","other","some","such","only","own","same",
]);

const MAX_SUMMARY_CHARS = 500;
const MAX_CHUNK_CHARS = 3000;  // per document chunk sent to context
const MAX_TOTAL_CHARS = 15000; // total RAG context budget
const RELEVANCE_THRESHOLD = 0.15;

// ─── Persistence ─────────────────────────────────────────────────────────

const KEY_RAG_CONFIG = "su_rag_config";
const KEY_RAG_INDEX  = "su_rag_index";

export function loadRAGConfig(): RAGConfig | null {
  try {
    const raw = localStorage.getItem(KEY_RAG_CONFIG);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function saveRAGConfig(cfg: RAGConfig): void {
  try { localStorage.setItem(KEY_RAG_CONFIG, JSON.stringify(cfg)); } catch {}
}

export function loadRAGIndex(): RAGIndex | null {
  try {
    const raw = localStorage.getItem(KEY_RAG_INDEX);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

export function saveRAGIndex(idx: RAGIndex): void {
  try {
    const json = JSON.stringify(idx);
    // Guard: localStorage typically has a 5MB limit.
    // Warn and skip if the index is too large (>4MB leaves room for other keys).
    if (json.length > 4 * 1024 * 1024) {
      console.warn(`[RAG] Index too large for localStorage (${Math.round(json.length/1024)}KB). Trimming keywords.`);
      // Reduce size by stripping keyword maps from low-relevance docs
      const trimmed = { ...idx, documents: idx.documents.map((d, i) => ({
        ...d,
        keywords: i < 20 ? d.keywords : {}, // keep keywords only for top 20 docs
        summary: d.summary.slice(0, 200),    // trim summaries
      }))};
      const trimmedJson = JSON.stringify(trimmed);
      if (trimmedJson.length > 4 * 1024 * 1024) {
        console.warn(`[RAG] Index still too large after trimming. Skipping save.`);
        return;
      }
      localStorage.setItem(KEY_RAG_INDEX, trimmedJson);
      return;
    }
    localStorage.setItem(KEY_RAG_INDEX, json);
  } catch (e) {
    // QuotaExceededError or other storage failure
    console.warn(`[RAG] Failed to save index: ${e instanceof Error ? e.message : String(e)}`);
  }
}

// ─── Text extraction (browser-side, mirrors App.tsx readFile) ────────────

function extractTextFromDocxXml(xml: string): string {
  const matches = xml.match(/<w:t[^>]*>([^<]+)<\/w:t>/g) ?? [];
  return matches.map(m => m.replace(/<[^>]+>/g, "")).join(" ");
}

function extractTextFromXlsxXml(sharedStrings: string, sheets: string[]): string {
  const ssMatches = sharedStrings.match(/<si>[\s\S]*?<\/si>/g) ?? [];
  const ssText = ssMatches.map(m => m.replace(/<[^>]+>/g, "").trim()).filter(Boolean).join(" | ");
  if (ssText) return ssText;
  return sheets.map(s => {
    const vals = (s.match(/<v>([^<]+)<\/v>/g) ?? []).map(m => m.replace(/<[^>]+>/g, ""));
    return vals.join(" | ");
  }).join("\n");
}

async function inflateZipEntries(buffer: ArrayBuffer): Promise<Map<string, string>> {
  const result = new Map<string, string>();
  try {
    const bytes = new Uint8Array(buffer);
    let i = 0;
    while (i < bytes.length - 4) {
      if (bytes[i]===0x50 && bytes[i+1]===0x4B && bytes[i+2]===0x03 && bytes[i+3]===0x04) {
        const compression = bytes[i+8] | (bytes[i+9] << 8);
        const compSize = bytes[i+18] | (bytes[i+19] << 8) | (bytes[i+20] << 16) | (bytes[i+21] << 24);
        const nameLen = bytes[i+26] | (bytes[i+27] << 8);
        const extraLen = bytes[i+28] | (bytes[i+29] << 8);
        const nameBytes = bytes.slice(i+30, i+30+nameLen);
        const name = new TextDecoder().decode(nameBytes);
        const dataStart = i+30+nameLen+extraLen;
        const compData = bytes.slice(dataStart, dataStart+compSize);
        let text = "";
        if (compression === 0) {
          text = new TextDecoder("utf-8", {fatal:false}).decode(compData);
        } else if (compression === 8) {
          try { text = new TextDecoder("utf-8", {fatal:false}).decode(pako.inflateRaw(compData)); } catch {}
        }
        if (text) result.set(name, text);
        i = dataStart + compSize;
      } else { i++; }
    }
  } catch {}
  return result;
}

export async function extractTextFromFile(file: File): Promise<string> {
  const name = file.name.toLowerCase();

  if (name.endsWith(".txt") || name.endsWith(".md") || name.endsWith(".csv") || name.endsWith(".json")) {
    return await file.text();
  }

  if (name.endsWith(".docx")) {
    const entries = await inflateZipEntries(await file.arrayBuffer());
    return extractTextFromDocxXml(entries.get("word/document.xml") ?? "");
  }

  if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
    const entries = await inflateZipEntries(await file.arrayBuffer());
    const ss = entries.get("xl/sharedStrings.xml") ?? "";
    const sheets: string[] = [];
    for (const [k, v] of entries) {
      if (k.startsWith("xl/worksheets/") && k.endsWith(".xml")) sheets.push(v);
    }
    return extractTextFromXlsxXml(ss, sheets);
  }

  // Unsupported — return empty
  return "";
}

// ─── Tokenizer (simple TF-IDF) ──────────────────────────────────────────

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s\-]/g, " ")
    .split(/\s+/)
    .filter(w => w.length >= 3 && !STOP_WORDS.has(w));
}

function buildKeywordMap(text: string): Record<string, number> {
  const tokens = tokenize(text);
  const freq: Record<string, number> = {};
  for (const t of tokens) freq[t] = (freq[t] || 0) + 1;
  return freq;
}

function computeRelevance(docKeywords: Record<string, number>, intentKeywords: Record<string, number>): number {
  const intentTerms = Object.keys(intentKeywords);
  if (intentTerms.length === 0) return 0;

  let matchScore = 0;
  let totalWeight = 0;

  for (const term of intentTerms) {
    const intentFreq = intentKeywords[term];
    const docFreq = docKeywords[term] || 0;
    totalWeight += intentFreq;
    if (docFreq > 0) {
      matchScore += Math.min(intentFreq, docFreq) * (1 + Math.log(docFreq));
    }
  }

  return totalWeight > 0 ? Math.min(1, matchScore / (totalWeight * 2)) : 0;
}

// ─── Sync: scan folder and build index ───────────────────────────────────

export interface SyncProgress {
  current: number;
  total: number;
  filename: string;
}

export async function syncFolder(
  files: File[],
  intent: string,
  folderPath: string,
  onProgress?: (p: SyncProgress) => void,
): Promise<RAGIndex> {
  const t0 = Date.now();
  const intentKeywords = buildKeywordMap(intent);
  const documents: RAGDocument[] = [];

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const ext = "." + file.name.split(".").pop()?.toLowerCase();
    if (!SUPPORTED_EXTENSIONS.has(ext)) continue;

    onProgress?.({ current: i + 1, total: files.length, filename: file.name });

    try {
      const text = await extractTextFromFile(file);
      if (!text || text.length < 20) continue;

      const keywords = buildKeywordMap(text);
      const relevance = computeRelevance(keywords, intentKeywords);
      const summary = text.replace(/\s+/g, " ").slice(0, MAX_SUMMARY_CHARS);

      documents.push({
        path: (file as any).webkitRelativePath || file.name,
        filename: file.name,
        modified: new Date(file.lastModified).toISOString(),
        sizeKb: Math.round(file.size / 1024),
        summary,
        keywords,
        relevance,
        used: false,
        lastUsed: "",
      });
    } catch {
      // Skip files that can't be read
    }
  }

  // Sort by relevance
  documents.sort((a, b) => b.relevance - a.relevance);

  const index: RAGIndex = {
    version: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    intent,
    folderPath,
    documents,
    stats: {
      totalDocs: documents.length,
      relevantDocs: documents.filter(d => d.relevance >= RELEVANCE_THRESHOLD).length,
      totalSizeKb: documents.reduce((a, d) => a + d.sizeKb, 0),
      syncDurationMs: Date.now() - t0,
    },
  };

  saveRAGIndex(index);
  return index;
}

// ─── Query: pull relevant chunks for plan generation ─────────────────────

export function queryRAG(
  index: RAGIndex | null,
  intent: string,
): RAGQueryResult {
  if (!index || index.documents.length === 0) {
    return { chunks: [], docsUsed: 0, docsSkipped: 0, totalChars: 0 };
  }

  // Re-score against current intent (may differ from sync-time intent)
  const intentKeywords = buildKeywordMap(intent);
  const scored = index.documents.map(doc => ({
    ...doc,
    liveRelevance: computeRelevance(doc.keywords, intentKeywords),
  })).sort((a, b) => b.liveRelevance - a.liveRelevance);

  const chunks: RAGQueryResult["chunks"] = [];
  let totalChars = 0;
  let docsUsed = 0;
  let docsSkipped = 0;

  for (const doc of scored) {
    if (doc.liveRelevance < RELEVANCE_THRESHOLD) {
      docsSkipped++;
      continue;
    }
    if (totalChars >= MAX_TOTAL_CHARS) {
      docsSkipped++;
      continue;
    }

    const chunk = doc.summary.slice(0, MAX_CHUNK_CHARS);
    chunks.push({
      filename: doc.filename,
      text: chunk,
      relevance: Math.round(doc.liveRelevance * 100) / 100,
    });
    totalChars += chunk.length;
    docsUsed++;
  }

  return { chunks, docsUsed, docsSkipped, totalChars };
}

// ─── Format RAG context for injection into plan generation ───────────────

export function formatRAGContext(result: RAGQueryResult): string {
  if (result.chunks.length === 0) return "";
  const lines = result.chunks.map(c =>
    `[KB: ${c.filename} (relevance ${c.relevance})]\n${c.text}`
  );
  return `LOCAL KNOWLEDGE BASE (${result.docsUsed} docs, ${result.docsSkipped} skipped):\n${lines.join("\n\n")}`;
}
