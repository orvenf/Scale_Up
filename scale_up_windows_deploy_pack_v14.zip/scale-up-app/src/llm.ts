// llm.ts — BYO LLM engine with autodetect + provider fallback
// FIX-NET-002: Ordered fallback chain with health probes and timeout budget.

export type LLMMode = "none" | "openai_compatible" | "ollama" | "gemini" | "anthropic";

export interface LLMConfig {
  mode: LLMMode;
  endpoint: string;
  model: string;
  apiKey: string;
  maxTokens: number;
  temperature: number;
  webSearchKey: string;
  // FIX-NET-002: optional local fallback
  localEndpoint: string;
  localModel: string;
}

export const DEFAULT_LLM_CONFIG: LLMConfig = {
  mode: "none", endpoint: "", model: "", apiKey: "",
  maxTokens: 4096, temperature: 0.1, webSearchKey: "",
  localEndpoint: "http://localhost:11434", localModel: "llama3.2",
};

export interface LLMResult {
  ok: boolean;
  text: string;
  error?: string;
  provider?: string;
  latencyMs?: number;
}

// ─── Autodetect — BYOLLM-01/02: tighter patterns ────────────────────────
// FIX: Always set the correct default model for the detected provider.
// Previous bug: existing?.model preserved the old provider's model (e.g. gpt-4o on Groq).
export function detectLLMInput(raw: string, existing?: LLMConfig): Partial<LLMConfig> {
  const s = raw.trim();
  if (!s) return { mode: "none", apiKey: "", endpoint: "", model: "" };

  // Helper: only keep existing model if same provider endpoint
  const keep = (endpoint: string, fallback: string) =>
    existing?.endpoint === endpoint && existing?.model ? existing.model : fallback;

  if (/^sk-[A-Za-z0-9_-]{40,}$/.test(s))
    return { mode: "openai_compatible", apiKey: s, endpoint: "https://api.openai.com", model: keep("https://api.openai.com", "gpt-4o") };

  if (/^sk-proj-[A-Za-z0-9_-]{20,}$/.test(s))
    return { mode: "openai_compatible", apiKey: s, endpoint: "https://api.openai.com", model: keep("https://api.openai.com", "gpt-4o") };

  if (/^gsk_[A-Za-z0-9]{48,}$/.test(s))
    return { mode: "openai_compatible", apiKey: s, endpoint: "https://api.groq.com/openai", model: keep("https://api.groq.com/openai", "llama-3.3-70b-versatile") };

  if (/^sk-ant-api03-[A-Za-z0-9_-]{20,}$/.test(s))
    return { mode: "anthropic", apiKey: s, endpoint: "https://api.anthropic.com", model: keep("https://api.anthropic.com", "claude-sonnet-4-20250514") };

  if (/^[a-fA-F0-9]{32}$/.test(s))
    return { mode: "openai_compatible", apiKey: s, endpoint: "https://api.mistral.ai", model: keep("https://api.mistral.ai", "mistral-large-latest") };

  // Gemini: AIza + 35 chars
  if (/^AIza[A-Za-z0-9_-]{30,}$/.test(s))
    return { mode: "gemini", apiKey: s, endpoint: "https://generativelanguage.googleapis.com", model: keep("https://generativelanguage.googleapis.com", "gemini-2.0-flash") };

  if (/^https?:\/\/(localhost|127\.0\.0\.1)(:\d{1,5})?(\/.*)?$/.test(s))
    return { mode: "ollama", endpoint: s, apiKey: "", model: existing?.model || "llama3.2" };

  if (/^https?:\/\/.{3,}/.test(s))
    return { mode: "openai_compatible", endpoint: s, apiKey: existing?.apiKey || "", model: existing?.model || "gpt-4o" };

  return { mode: "none", apiKey: "", endpoint: "", model: "" };
}

export function detectLabel(cfg: LLMConfig): string {
  if (cfg.mode === "none") return "Offline";
  if (cfg.mode === "ollama") return `Ollama · ${cfg.model || "llama3.2"}`;
  if (cfg.mode === "gemini") return `Gemini · ${cfg.model || "gemini-2.0-flash"}`;
  if (cfg.mode === "anthropic") return `Anthropic · ${cfg.model || "claude-sonnet-4-20250514"}`;
  const host = cfg.endpoint.includes("openai.com") ? "OpenAI"
    : cfg.endpoint.includes("groq.com")       ? "Groq"
    : cfg.endpoint.includes("mistral.ai")     ? "Mistral"
    : cfg.endpoint.replace(/^https?:\/\//, "").split("/")[0] || "Custom";
  return `${host} · ${cfg.model || "?"}`;
}

// ─── Provider health probe ───────────────────────────────────────────────
export type ProviderHealth = {
  primary: "healthy" | "unreachable" | "auth_error" | "unconfigured";
  local: "healthy" | "unreachable" | "unconfigured";
  activeProvider: "primary" | "local" | "deterministic";
  primaryError?: string;
};

export async function probeHealth(cfg: LLMConfig): Promise<ProviderHealth> {
  const result: ProviderHealth = {
    primary: "unconfigured",
    local: "unconfigured",
    activeProvider: "deterministic",
  };

  // Probe primary
  if (cfg.mode !== "none" && cfg.endpoint) {
    try {
      const r = await callWithTimeout(cfg, "Health check.", "Reply: ok", 8000);
      if (r.ok) {
        result.primary = "healthy";
      } else {
        // Distinguish auth errors from network errors
        const err = r.error || "";
        if (err.includes("HTTP 401") || err.includes("HTTP 403") || err.includes("HTTP 404") || err.includes("HTTP 429")) {
          result.primary = "auth_error";
          result.primaryError = err.slice(0, 200);
        } else {
          result.primary = "unreachable";
          result.primaryError = err.slice(0, 200);
        }
      }
    } catch (e) {
      result.primary = "unreachable";
      result.primaryError = e instanceof Error ? e.message : "Network error";
    }
  }

  // Probe local Ollama fallback
  if (cfg.localEndpoint) {
    try {
      const localCfg: LLMConfig = {
        ...DEFAULT_LLM_CONFIG,
        mode: "ollama",
        endpoint: cfg.localEndpoint,
        model: cfg.localModel || "llama3.2",
      };
      const r = await callWithTimeout(localCfg, "Health check.", "Reply: ok", 5000);
      result.local = r.ok ? "healthy" : "unreachable";
    } catch {
      result.local = "unreachable";
    }
  }

  // Determine active
  if (result.primary === "healthy") result.activeProvider = "primary";
  else if (result.local === "healthy") result.activeProvider = "local";
  else result.activeProvider = "deterministic";

  return result;
}

// ─── Core LLM call with timeout ──────────────────────────────────────────

async function callWithTimeout(cfg: LLMConfig, system: string, user: string, timeoutMs: number): Promise<LLMResult> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    let result: LLMResult;
    if (cfg.mode === "ollama") result = await callOllama(cfg, system, user, controller.signal);
    else if (cfg.mode === "gemini") result = await callGemini(cfg, system, user, controller.signal);
    else if (cfg.mode === "anthropic") result = await callAnthropic(cfg, system, user, controller.signal);
    else result = await callOpenAICompat(cfg, system, user, controller.signal);
    return result;
  } finally {
    clearTimeout(timer);
  }
}

// ─── FIX-NET-002: Call with fallback chain ───────────────────────────────

export async function callLLM(cfg: LLMConfig, system: string, user: string): Promise<LLMResult> {
  if (cfg.mode === "none") return { ok: false, text: "", error: "LLM is offline.", provider: "none" };

  const TIMEOUT = 30_000;

  // Try primary
  try {
    const start = Date.now();
    const result = await callWithTimeout(cfg, system, user, TIMEOUT);
    if (result.ok) return { ...result, provider: detectLabel(cfg), latencyMs: Date.now() - start };
  } catch { /* fall through */ }

  // Try local Ollama fallback
  if (cfg.localEndpoint) {
    try {
      const localCfg: LLMConfig = {
        ...DEFAULT_LLM_CONFIG,
        mode: "ollama",
        endpoint: cfg.localEndpoint,
        model: cfg.localModel || "llama3.2",
        maxTokens: cfg.maxTokens,
        temperature: cfg.temperature,
        webSearchKey: "",
        localEndpoint: "",
        localModel: "",
      };
      const start = Date.now();
      const result = await callWithTimeout(localCfg, system, user, TIMEOUT);
      if (result.ok) return { ...result, provider: `Ollama fallback · ${localCfg.model}`, latencyMs: Date.now() - start };
    } catch { /* fall through */ }
  }

  return { ok: false, text: "", error: "All providers unreachable.", provider: "none" };
}

async function callOpenAICompat(cfg: LLMConfig, system: string, user: string, signal?: AbortSignal): Promise<LLMResult> {
  const url = cfg.endpoint.replace(/\/+$/, "") + "/v1/chat/completions";
  const headers: Record<string,string> = { "Content-Type": "application/json" };
  if (cfg.apiKey) headers["Authorization"] = `Bearer ${cfg.apiKey}`;
  const res = await fetch(url, {
    method: "POST", headers, signal,
    body: JSON.stringify({
      model: cfg.model, max_tokens: cfg.maxTokens, temperature: cfg.temperature,
      messages: [{ role: "system", content: system }, { role: "user", content: user }],
    })
  });
  if (!res.ok) return { ok: false, text: "", error: `HTTP ${res.status}: ${(await res.text()).slice(0,300)}` };
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content ?? "";
  return { ok: true, text };
}

// ─── Anthropic adapter — proper /v1/messages endpoint ───────────────────

async function callAnthropic(cfg: LLMConfig, system: string, user: string, signal?: AbortSignal): Promise<LLMResult> {
  const model = cfg.model || "claude-sonnet-4-20250514";
  const url = "https://api.anthropic.com/v1/messages";
  const res = await fetch(url, {
    method: "POST", signal,
    headers: {
      "Content-Type": "application/json",
      "x-api-key": cfg.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({
      model,
      max_tokens: cfg.maxTokens,
      system,
      messages: [{ role: "user", content: user }],
    }),
  });
  if (!res.ok) return { ok: false, text: "", error: `Anthropic HTTP ${res.status}: ${(await res.text()).slice(0,300)}` };
  const data = await res.json();
  const text = data?.content?.[0]?.text ?? "";
  if (!text) return { ok: false, text: "", error: "Anthropic returned empty response" };
  return { ok: true, text };
}

async function callOllama(cfg: LLMConfig, system: string, user: string, signal?: AbortSignal): Promise<LLMResult> {
  const base = (cfg.endpoint || "http://localhost:11434").replace(/\/+$/, "");
  const res = await fetch(base + "/api/chat", {
    method: "POST", signal,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: cfg.model || "llama3.2", stream: false,
      options: { temperature: cfg.temperature, num_predict: cfg.maxTokens },
      messages: [{ role: "system", content: system }, { role: "user", content: user }],
    })
  });
  if (!res.ok) return { ok: false, text: "", error: `Ollama ${res.status}: ${(await res.text()).slice(0,300)}` };
  const data = await res.json();
  return { ok: true, text: data?.message?.content ?? data?.response ?? "" };
}

// ─── Gemini adapter ──────────────────────────────────────────────────────

async function callGemini(cfg: LLMConfig, system: string, user: string, signal?: AbortSignal): Promise<LLMResult> {
  const model = cfg.model || "gemini-2.0-flash";
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const res = await fetch(url, {
    method: "POST", signal,
    headers: {
      "Content-Type": "application/json",
      "x-goog-api-key": cfg.apiKey,
    },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: system }] },
      contents: [{ role: "user", parts: [{ text: user }] }],
      generationConfig: {
        temperature: cfg.temperature,
        maxOutputTokens: cfg.maxTokens,
      },
    }),
  });
  if (!res.ok) return { ok: false, text: "", error: `Gemini HTTP ${res.status}: ${(await res.text()).slice(0,300)}` };
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
  if (!text) return { ok: false, text: "", error: "Gemini returned empty response" };
  return { ok: true, text };
}

export async function testLLMConnection(cfg: LLMConfig): Promise<LLMResult> {
  if (cfg.mode === "none") return { ok: false, text: "", error: "Mode is offline" };
  return callLLM(cfg, "Connectivity test.", "Reply with exactly the word: ok");
}

// ─── Web search — Serper primary, DuckDuckGo free fallback ───────────────

export interface SearchResult { title: string; snippet: string; url: string; timestamp?: string; }

export async function webSearch(queries: string[], serperKey: string): Promise<SearchResult[]> {
  if (!queries.length) return [];

  // Try Serper first if key is available
  if (serperKey) {
    const results = await serperSearch(queries, serperKey);
    if (results.length > 0) return results;
  }

  // Fallback: DuckDuckGo HTML (no API key needed)
  return ddgSearch(queries);
}

async function serperSearch(queries: string[], apiKey: string): Promise<SearchResult[]> {
  const seen = new Set<string>();
  const results: SearchResult[] = [];
  for (const q of queries.slice(0, 5)) {
    if (!q.trim()) continue;
    try {
      const res = await fetch("https://google.serper.dev/search", {
        method: "POST",
        headers: { "X-API-KEY": apiKey, "Content-Type": "application/json" },
        body: JSON.stringify({ q, num: 5 }),
      });
      if (!res.ok) continue;
      const data = await res.json();
      for (const r of (data?.organic ?? []).slice(0, 5)) {
        const url: string = r.link ?? "";
        if (!url || seen.has(url)) continue;
        seen.add(url);
        results.push({ title: r.title ?? "", snippet: r.snippet ?? "", url, timestamp: r.date ?? undefined });
      }
    } catch { /* skip */ }
  }
  return results.slice(0, 15);
}

async function ddgSearch(queries: string[]): Promise<SearchResult[]> {
  const seen = new Set<string>();
  const results: SearchResult[] = [];
  const DDG_TIMEOUT = 8_000; // 8s per query — DDG can be slow

  for (const q of queries.slice(0, 3)) {
    if (!q.trim()) continue;

    // Per-query timeout controller
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), DDG_TIMEOUT);

    try {
      // Strategy 1: POST to DDG HTML lite
      const res = await fetch("https://html.duckduckgo.com/html/", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        },
        body: `q=${encodeURIComponent(q)}&b=`,
        signal: controller.signal,
      });
      if (!res.ok) { clearTimeout(timer); continue; }
      const html = await res.text();

      // Parse result blocks — multiple class patterns for DDG HTML variance
      const blocks = html.split(/<div[^>]*class="[^"]*result[^"]*links[^"]*"[^>]*>/gi).slice(1, 8);

      let queryHits = 0;
      if (blocks.length > 0) {
        for (const block of blocks) {
          const linkMatch = block.match(/<a[^>]*href="([^"]+)"[^>]*class="[^"]*result__a[^"]*"[^>]*>([\s\S]*?)<\/a>/i)
            || block.match(/<a[^>]*class="[^"]*result__a[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i)
            || block.match(/<a[^>]*href="(\/\/duckduckgo\.com\/l\/\?[^"]+|https?:\/\/[^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
          if (!linkMatch) continue;

          let url = linkMatch[1] || "";
          const uddg = url.match(/[?&]uddg=([^&]*)/);
          if (uddg) url = decodeURIComponent(uddg[1]);
          if (url.startsWith("//")) url = "https:" + url;
          // Validate: must be real http URL, not DDG internal
          if (!url || !url.startsWith("http") || seen.has(url) || url.includes("duckduckgo.com")) continue;
          // Additional validation: URL must have a domain with a dot
          try { const u = new URL(url); if (!u.hostname.includes(".")) continue; } catch { continue; }
          seen.add(url);
          const title = (linkMatch[2] || "").replace(/<[^>]*>/g, "").trim();
          const snippetMatch = block.match(/class="[^"]*result__snippet[^"]*"[^>]*>([\s\S]*?)<\/(?:a|td|div|span)>/i)
            || block.match(/class="[^"]*snippet[^"]*"[^>]*>([\s\S]*?)<\/(?:a|td|div|span)>/i);
          const snippet = (snippetMatch?.[1] || "").replace(/<[^>]*>/g, "").trim();
          if (title) { results.push({ title, snippet, url }); queryHits++; }
        }
      }

      // Strategy 2: Fallback — scan for all uddg links (if Strategy 1 found nothing for this query)
      if (queryHits === 0) {
        const allLinks = [...html.matchAll(/<a[^>]*href="[^"]*uddg=([^&"]+)[^"]*"[^>]*>([\s\S]*?)<\/a>/gi)];
        for (const m of allLinks.slice(0, 8)) {
          let url: string;
          try { url = decodeURIComponent(m[1]); } catch { continue; }
          if (!url || !url.startsWith("http") || seen.has(url) || url.includes("duckduckgo.com")) continue;
          seen.add(url);
          const title = (m[2] || "").replace(/<[^>]*>/g, "").trim();
          if (title) { results.push({ title, snippet: "", url }); queryHits++; }
        }
      }

      // Strategy 3: If HTML parsing returned nothing, try DuckDuckGo Instant Answer API
      if (queryHits === 0) {
        try {
          const apiController = new AbortController();
          const apiTimer = setTimeout(() => apiController.abort(), 5_000);
          const apiRes = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(q)}&format=json&no_html=1&skip_disambig=1`, {
            signal: apiController.signal,
          });
          clearTimeout(apiTimer);
          if (apiRes.ok) {
            const data = await apiRes.json();
            if (data.AbstractText && data.AbstractURL) {
              results.push({ title: data.Heading || q, snippet: data.AbstractText.slice(0, 200), url: data.AbstractURL });
            }
            for (const topic of (data.RelatedTopics || []).slice(0, 5)) {
              if (topic.FirstURL && topic.Text && !seen.has(topic.FirstURL)) {
                seen.add(topic.FirstURL);
                results.push({ title: topic.Text.slice(0, 80), snippet: topic.Text.slice(0, 200), url: topic.FirstURL });
              }
            }
          }
        } catch { /* API fallback failed — acceptable */ }
      }
    } catch { /* Per-query failure — continue to next query */ }
    clearTimeout(timer);
  }
  return results.slice(0, 10);
}
