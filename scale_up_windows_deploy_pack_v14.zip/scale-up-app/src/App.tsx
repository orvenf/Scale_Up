import { useEffect, useState, useCallback, useRef } from "react";
import { createPortal } from "react-dom";
import {
  DEFAULT_LLM_CONFIG, LLMConfig, detectLLMInput, detectLabel,
  testLLMConnection, SearchResult, ProviderHealth, probeHealth,
} from "./llm";
import {
  parseContext, composePlan,
  Plan, WebSnippet,
} from "./engine";
import { runGeneration, RunTrace } from "./orchestrator";
import { saveSecrets, migrateFromLocalStorage, loadSlots, saveSlots } from "./store";
import { exportPlanToDocx } from "./export";
import { loadRAGIndex, saveRAGIndex, syncFolder, RAGIndex, RAGConfig, loadRAGConfig, saveRAGConfig } from "./rag";
import type { PromptSlots } from "./types";
import * as pako from "pako";

const VERSION = "0.9.1";
type Tab = "plan" | "settings" | "history";

// ─── Mermaid (re-initializes on theme change) ───────────────────────────
let mermaidCurrentTheme = "";
async function getMermaid(appTheme: "dark" | "light" = "dark") {
  const m = (await import("mermaid")).default;
  if (mermaidCurrentTheme !== appTheme) {
    m.initialize({
      startOnLoad: false, securityLevel: "loose",
      theme: "base",
      themeVariables: {
        primaryColor: "#ffffff",
        primaryTextColor: "#000000",
        primaryBorderColor: "#000000",
        lineColor: "#000000",
        secondaryColor: "#ffffff",
        tertiaryColor: "#ffffff",
        background: "transparent",
        mainBkg: "#ffffff",
        nodeBorder: "#000000",
        clusterBkg: "#ffffff",
        clusterBorder: "#000000",
        titleColor: "#000000",
        edgeLabelBackground: "transparent",
        textColor: "#000000",
        noteBkgColor: "#ffffff",
        noteTextColor: "#000000",
        noteBorderColor: "#000000",
      },
    });
    mermaidCurrentTheme = appTheme;
  }
  return m;
}

// ─── Mermaid sanitizer — FIX-MERM-001: clean external/LLM Mermaid ────────
function sanitizeMermaid(raw: string): string {
  let code = raw.trim();
  // Strip markdown fences if present
  code = code.replace(/^```mermaid\s*/i, "").replace(/```\s*$/, "").trim();
  // Remove HTML tags that break Mermaid (except <br> which Mermaid supports)
  code = code.replace(/<(?!br\s*\/?>)[^>]+>/gi, "");
  // Fix common LLM artifacts: em-dash in node IDs, smart quotes, zero-width chars
  code = code.replace(/[\u200B\u200C\u200D\uFEFF]/g, "");
  code = code.replace(/[\u201C\u201D]/g, '"');
  code = code.replace(/[\u2018\u2019]/g, "'");
  // Replace em-dashes in edge labels (outside quotes) with --
  code = code.replace(/\u2014/g, "--");
  code = code.replace(/\u2013/g, "--");
  // Ensure each node ID uses only safe chars (alphanumeric + underscore)
  // Don't touch quoted labels inside ["..."] or ("...")
  // Remove %%{ init: ... }%% directives that can conflict with our config
  code = code.replace(/%%\{[\s\S]*?\}%%/g, "");
  // Remove unsupported directives like %%{init:...}%%
  code = code.replace(/^%%\s*{.*$/gm, "");
  // Limit total length to prevent render hangs
  if (code.length > 8000) code = code.slice(0, 8000) + "\n  TRUNC[\"... truncated\"]";
  return code;
}

// ─── Fullscreen diagram overlay ──────────────────────────────────────
function DiagramOverlay({ svg, code, title, onClose }: { svg: string; code: string; title: string; onClose: () => void }) {
  const [scale, setScale] = useState(1);
  const [copied, setCopied] = useState(false);
  const copy = () => navigator.clipboard.writeText(code)
    .then(() => { setCopied(true); setTimeout(() => setCopied(false), 1500); });

  return (
    <div className="diagram-overlay" onClick={onClose}>
      <div className="diagram-overlay-inner" onClick={e => e.stopPropagation()}>
        <div className="diagram-overlay-toolbar">
          <span className="section-label">{title}</span>
          <div className="diagram-overlay-controls">
            <button className="btn-ghost small" onClick={() => setScale(s => Math.max(0.25, s - 0.25))}>−</button>
            <span className="mono muted" style={{fontSize:"11px",minWidth:"40px",textAlign:"center"}}>{Math.round(scale*100)}%</span>
            <button className="btn-ghost small" onClick={() => setScale(s => Math.min(4, s + 0.25))}>+</button>
            <button className="btn-ghost small" onClick={() => setScale(1)}>Fit</button>
            <button className="link-btn" onClick={copy}>{copied ? "Copied" : "Copy Mermaid"}</button>
            <button className="btn-ghost small" onClick={onClose}>✕ Close</button>
          </div>
        </div>
        <div className="diagram-overlay-canvas">
          <div style={{ transform: `scale(${scale})`, transformOrigin: "top center", transition: "transform 0.15s ease" }}
            dangerouslySetInnerHTML={{ __html: svg }} />
        </div>
      </div>
    </div>
  );
}

function MermaidBlock({ code, title, theme }: { code: string; title: string; theme: "dark" | "light" }) {
  const [svg, setSvg] = useState("");
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const sanitized = sanitizeMermaid(code);

  useEffect(() => {
    let cancelled = false;
    setSvg(""); setErr("");
    (async () => {
      try {
        const m = await getMermaid(theme);
        const { svg: s } = await m.render("mer-" + Date.now(), sanitized);
        if (!cancelled) setSvg(s);
      } catch (e: unknown) { if (!cancelled) setErr(String(e)); }
    })();
    return () => { cancelled = true; };
  }, [sanitized, theme]);

  const copy = () => navigator.clipboard.writeText(code)
    .then(() => { setCopied(true); setTimeout(() => setCopied(false), 1500); });

  return (
    <div className="diagram-wrap">
      <div className="diagram-toolbar">
        <span className="section-label">{title}</span>
        <div style={{display:"flex",gap:"6px",alignItems:"center"}}>
          {svg && <button className="link-btn" onClick={() => setExpanded(true)}>⛶ Expand</button>}
          <button className="link-btn" onClick={copy}>{copied ? "Copied" : "Copy Mermaid"}</button>
        </div>
      </div>
      {err    && <pre className="diagram-fallback">{code}</pre>}
      {!err && !svg && <div className="diagram-loading">Rendering…</div>}
      {svg    && <div className="diagram-svg" dangerouslySetInnerHTML={{ __html: svg }} />}
      {expanded && svg && createPortal(
        <DiagramOverlay svg={svg} code={code} title={title} onClose={() => setExpanded(false)} />,
        document.body
      )}
    </div>
  );
}

// ─── File reader — FIX-DATA-001: vendored pako, no CDN ──────────────────

async function inflateZip(buffer: ArrayBuffer): Promise<Map<string,string>> {
  const result = new Map<string,string>();
  try {
    const bytes = new Uint8Array(buffer);
    let i = 0;
    while (i < bytes.length - 4) {
      if (bytes[i]===0x50 && bytes[i+1]===0x4B && bytes[i+2]===0x03 && bytes[i+3]===0x04) {
        const compression  = bytes[i+8]  | (bytes[i+9]  << 8);
        const compSize     = bytes[i+18] | (bytes[i+19] << 8) | (bytes[i+20] << 16) | (bytes[i+21] << 24);
        const nameLen      = bytes[i+26] | (bytes[i+27] << 8);
        const extraLen     = bytes[i+28] | (bytes[i+29] << 8);
        const nameBytes    = bytes.slice(i+30, i+30+nameLen);
        const name         = new TextDecoder().decode(nameBytes);
        const dataStart    = i+30+nameLen+extraLen;
        const compData     = bytes.slice(dataStart, dataStart+compSize);

        let text = "";
        if (compression === 0) {
          text = new TextDecoder("utf-8",{fatal:false}).decode(compData);
        } else if (compression === 8) {
          try {
            const inflated = pako.inflateRaw(compData);
            text = new TextDecoder("utf-8",{fatal:false}).decode(inflated);
          } catch { /* skip */ }
        }
        if (text) result.set(name, text);
        i = dataStart + compSize;
      } else { i++; }
    }
  } catch {
    const text = new TextDecoder("utf-8",{fatal:false}).decode(buffer);
    result.set("__raw__", text);
  }
  return result;
}

async function readFile(file: File): Promise<string> {
  const name = file.name.toLowerCase();

  if (name.endsWith(".txt") || name.endsWith(".md") || name.endsWith(".csv")) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result as string);
      r.onerror = rej;
      r.readAsText(file);
    });
  }

  if (name.endsWith(".xlsx") || name.endsWith(".xls")) {
    const buf = await file.arrayBuffer();
    const entries = await inflateZip(buf);
    let text = "";
    const ss = entries.get("xl/sharedStrings.xml") ?? entries.get("__raw__") ?? "";
    const matches = ss.match(/<si>[\s\S]*?<\/si>/g) ?? [];
    text = matches.map(m => m.replace(/<[^>]+>/g,"").trim()).filter(Boolean).join(" | ");
    if (!text) {
      for (const [k,v] of entries) {
        if (k.startsWith("xl/worksheets/") && k.endsWith(".xml")) {
          const vals = (v.match(/<v>([^<]+)<\/v>/g) ?? []).map(m => m.replace(/<[^>]+>/g,""));
          text += vals.join(" | ") + "\n";
        }
      }
    }
    return `[XLSX: ${file.name}]\n${text.slice(0, 10000) || "[No text extracted — possibly binary-only spreadsheet]"}`;
  }

  if (name.endsWith(".docx")) {
    const buf = await file.arrayBuffer();
    const entries = await inflateZip(buf);
    const doc = entries.get("word/document.xml") ?? entries.get("__raw__") ?? "";
    const matches = doc.match(/<w:t[^>]*>([^<]+)<\/w:t>/g) ?? [];
    const text = matches.map(m => m.replace(/<[^>]+>/g,"")).join(" ");
    return `[DOCX: ${file.name}]\n${text.slice(0, 10000) || "[No text extracted — possibly encrypted DOCX]"}`;
  }

  if (name.endsWith(".pdf")) {
    return `[PDF: ${file.name}]\n⚠ PDF text extraction is not yet supported. Paste the text content directly, or export as DOCX/TXT first.`;
  }

  return new Promise((res, rej) => {
    const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = rej; r.readAsText(file);
  });
}

// ─── Helper components ────────────────────────────────────────────────────

function SourceBadge({ tag }: { tag: string }) {
  const cls = tag==="[WEB]"?"badge-web":tag==="[LLM]"?"badge-llm":tag==="[ASSUMPTION]"?"badge-assumption":"badge-input";
  return <span className={"source-badge "+cls}>{tag}</span>;
}

function PlanField({ label, value }: { label: string; value: string }) {
  if (!value) return null;
  const isAssumption = value.includes("[ASSUMPTION");
  const isInferred   = value.includes("[INFERRED");
  return (
    <div className={"plan-field"+(isAssumption?" field-assumption":isInferred?" field-inferred":"")}>
      <span className="plan-field-label">{label}</span>
      <span className="plan-field-value">{value}</span>
    </div>
  );
}

function RedFlagRow({ flag, likelihood, impact, mitigation }: { flag: string; likelihood: string; impact: string; mitigation: string }) {
  const hi = likelihood==="high"||impact==="high";
  return (
    <div className={"redflag-row"+(hi?" redflag-hi":"")}>
      <span className="redflag-text">⚑ {flag}</span>
      <span className="redflag-meta mono">L:{likelihood} I:{impact}</span>
      <span className="redflag-mit muted small">{mitigation}</span>
    </div>
  );
}

// ─── Mode badge component ────────────────────────────────────────────────

function ModeBadge({ health, config }: { health: ProviderHealth | null; config: LLMConfig }) {
  const hasPremiumWeb = !!config.webSearchKey;

  // No LLM configured
  if (!health || config.mode === "none") {
    return <span className="mode-chip mode-deterministic">Web + Deterministic{hasPremiumWeb ? " (Serper)" : ""}</span>;
  }
  if (health.activeProvider === "primary") {
    return <span className="mode-chip mode-online">Online · {detectLabel(config)}</span>;
  }
  if (health.activeProvider === "local") {
    return <span className="mode-chip mode-local">Local · Ollama</span>;
  }
  if (health.primary === "auth_error") {
    return <span className="mode-chip mode-auth-error">Auth Error · {detectLabel(config)}</span>;
  }
  if (health.primary === "unreachable") {
    return <span className="mode-chip mode-deterministic">Web + Deterministic (LLM offline)</span>;
  }
  return <span className="mode-chip mode-deterministic">Web + Deterministic</span>;
}

// ─── Main App ─────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab]               = useState<Tab>("plan");
  const [input, setInput]           = useState("");
  const [plan, setPlan]             = useState<Plan | null>(null);
  const [loading, setLoading]       = useState(false);
  const [statusSteps, setStatusSteps] = useState<string[]>([]);
  const [llmConfig, setLlmCfg]      = useState<LLMConfig>(DEFAULT_LLM_CONFIG);
  const [slots, setSlots]           = useState<PromptSlots>(loadSlots);
  const [testResult, setTestResult] = useState("");
  const [testing, setTesting]       = useState(false);
  const [dragging, setDragging]     = useState(false);
  const [llmRaw, setLlmRaw]         = useState("");
  const [llmDetected, setLlmDetected] = useState("Offline");
  const [webResults, setWebResults] = useState<SearchResult[]>([]);
  const [health, setHealth]         = useState<ProviderHealth | null>(null);
  const [lastTrace, setLastTrace]   = useState<RunTrace | null>(null);
  const [focusMode, setFocusMode]   = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showApiHelper, setShowApiHelper] = useState(false);
  const [savedAt, setSavedAt]       = useState<string | null>(null);
  const [configReady, setConfigReady] = useState(false);
  const [intent, setIntent]           = useState("");
  const [ragIndex, setRagIndex]       = useState<RAGIndex | null>(loadRAGIndex);
  const [ragSyncing, setRagSyncing]   = useState(false);
  const [ragProgress, setRagProgress] = useState("");
  const [theme, setTheme]             = useState<"dark"|"light">(() => {
    try { return (localStorage.getItem("su_theme") as "dark"|"light") || "dark"; } catch { return "dark"; }
  });
  const [history, setHistory] = useState<{id: string; account: string; date: string; plan: Plan}[]>(() => {
    try { const raw = localStorage.getItem("su_history"); return raw ? JSON.parse(raw) : []; } catch { return []; }
  });
  const initRef = useRef(false);
  const gridRef = useRef<HTMLDivElement>(null);
  const [colWidths, setColWidths] = useState<[number,number,number]>([380, 0, 380]); // 0 = flex
  const resizingRef = useRef<{col: 0|1; startX: number; startW: number} | null>(null);

  // ── Column resize handlers ─────────────────────────────────────────
  const startResize = useCallback((col: 0|1, e: React.MouseEvent) => {
    e.preventDefault();
    const w = col === 0 ? colWidths[0] : colWidths[2];
    resizingRef.current = { col, startX: e.clientX, startW: w };
    const onMove = (ev: MouseEvent) => {
      if (!resizingRef.current) return;
      const delta = ev.clientX - resizingRef.current.startX;
      const newW = Math.max(280, Math.min(700, resizingRef.current.startW + (resizingRef.current.col === 0 ? delta : -delta)));
      setColWidths(prev => {
        const next: [number,number,number] = [...prev] as [number,number,number];
        if (resizingRef.current!.col === 0) next[0] = newW;
        else next[2] = newW;
        return next;
      });
    };
    const onUp = () => {
      resizingRef.current = null;
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
    };
    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
  }, [colWidths]);

  // ── Theme: apply data-theme attribute to root element ───────────────
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
    try { localStorage.setItem("su_theme", theme); } catch {}
  }, [theme]);

  const toggleTheme = () => setTheme(t => t === "dark" ? "light" : "dark");

  // ── Init: migrate secrets from localStorage ────────────────────────────
  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;
    (async () => {
      const cfg = await migrateFromLocalStorage(DEFAULT_LLM_CONFIG);
      setLlmCfg(cfg);
      setLlmRaw(cfg.apiKey || cfg.endpoint || "");
      setLlmDetected(detectLabel(cfg));
      setConfigReady(true);
      // Probe health on startup
      if (cfg.mode !== "none") {
        const h = await probeHealth(cfg);
        setHealth(h);
      }
    })();
  }, []);

  const addStep  = (s: string) => setStatusSteps(prev => [...prev, s]);
  const clearSteps = () => setStatusSteps([]);

  // ── FIX-UX-001: Single Generate action — routes automatically ──────────
  async function handleGenerate() {
    const text = input.trim();
    if (!text) { addStep("⚠ Paste account notes first."); return; }
    clearSteps(); setLoading(true); setPlan(null); setWebResults([]);

    // Prepend intent as a structured field so normalizer and engine can use it
    const intentPrefix = intent.trim() ? `**Intent:** ${intent.trim()}\n\n` : "";
    const fullInput = intentPrefix + text;

    try {
      const result = await runGeneration(fullInput, llmConfig, slots, addStep);
      setPlan(result.plan);
      setWebResults(result.webResults);
      setLastTrace(result.trace);
      setHealth(result.trace.health);
      // Auto-save to history
      const entry = { id: Date.now().toString(), account: result.plan.account, date: new Date().toISOString().slice(0, 16), plan: result.plan };
      setHistory(prev => {
        const next = [entry, ...prev].slice(0, 20); // keep last 20
        try { localStorage.setItem("su_history", JSON.stringify(next)); } catch {}
        return next;
      });
    } catch (e) {
      addStep(`⚠ Generation failed: ${e instanceof Error ? e.message : String(e)}`);
    }
    setLoading(false);
  }

  // ── Opportunity selection ─────────────────────────────────────────────
  function selectOpportunity(id: string) {
    if (!plan) return;
    const webSnips = plan.signals.filter(s=>s.tag==="[WEB]").map(s=>({ title:"", snippet: s.claim, url: s.source }));
    setPlan(composePlan(parseContext(input, webSnips, plan.planMode), undefined, id));
  }

  // ── LLM autodetect — BYOLLM-01/02 fix ────────────────────────────────
  function handleLLMInput(raw: string) {
    setLlmRaw(raw);
    const patch = detectLLMInput(raw, llmConfig);
    const next  = { ...llmConfig, ...patch };
    setLlmCfg(next); persistConfig(next);
    setLlmDetected(detectLabel(next));
  }

  function updateLLM(patch: Partial<LLMConfig>) {
    const next = { ...llmConfig, ...patch };
    setLlmCfg(next); persistConfig(next);
    setLlmDetected(detectLabel(next));
  }

  // FIX-SET-001: Autosave with timestamp indicator
  function persistConfig(cfg: LLMConfig) {
    saveSecrets(cfg);
    setSavedAt(new Date().toLocaleTimeString());
  }

  function updateSlot(k: keyof PromptSlots, v: string) {
    const next = { ...slots, [k]: v }; setSlots(next); saveSlots(next);
    setSavedAt(new Date().toLocaleTimeString());
  }

  async function handleTest() {
    setTesting(true); setTestResult("Testing…");
    const r = await testLLMConnection(llmConfig);
    if (r.ok) {
      setTestResult("✓ Connected");
    } else {
      // Show specific error instead of generic "unreachable"
      setTestResult(`✗ ${r.error || "Connection failed"}`);
    }
    setTesting(false);
    // Update health
    const h = await probeHealth(llmConfig);
    setHealth(h);
  }

  // FIX-OBS-001: Export diagnostics
  function exportDiagnostics() {
    if (!lastTrace) return;
    const blob = new Blob([JSON.stringify(lastTrace, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `scaleup-trace-${lastTrace.id}.json`; a.click();
    URL.revokeObjectURL(url);
  }

  // ── Drag-and-drop ─────────────────────────────────────────────────────
  const handleDrop = useCallback(async (e: React.DragEvent) => {
    e.preventDefault(); setDragging(false);
    const fs = Array.from(e.dataTransfer.files);
    if (!fs.length) return;
    addStep(`Reading ${fs.length} file(s)…`);
    const parts: string[] = [input];
    for (const f of fs) {
      try {
        const t = await readFile(f);
        parts.push(t);
        addStep(`  ✓ ${f.name} (${Math.round(f.size/1024)}KB)`);
      } catch (err) { addStep(`  ✗ ${f.name}: ${String(err)}`); }
    }
    setInput(parts.filter(Boolean).join("\n\n"));
  }, [input]);

  if (!configReady) {
    return <div className="shell"><div className="loading-screen"><span className="loading-text">Loading configuration…</span></div></div>;
  }

  // ── Render ────────────────────────────────────────────────────────────
  return (
    <div className="shell">

      {/* Rail */}
      <nav className="rail">
        <div className="wordmark">SU</div>
        <button className={"rail-item"+(tab==="plan"?" active":"")} onClick={() => setTab("plan")}>
          <span className="rail-icon">◈</span><span className="rail-label">Plan</span>
        </button>
        <button className={"rail-item"+(tab==="history"?" active":"")} onClick={() => setTab("history")}>
          <span className="rail-icon">☰</span><span className="rail-label">History</span>
        </button>
        <button className={"rail-item"+(tab==="settings"?" active":"")} onClick={() => setTab("settings")}>
          <span className="rail-icon">⊙</span><span className="rail-label">Config</span>
        </button>
        <div className="rail-foot">
          <button className="rail-item" onClick={toggleTheme} title={theme === "dark" ? "Switch to light theme" : "Switch to dark theme"}>
            <span className="rail-icon">{theme === "dark" ? "☀" : "☾"}</span>
            <span className="rail-label">{theme === "dark" ? "Light" : "Dark"}</span>
          </button>
          <span className="attr">Prototype by Orven</span>
          <span className="ver">v{VERSION}</span>
        </div>
      </nav>

      <div className="workspace">

        {/* Mode strip — FIX-UX-001 */}
        <div className="mode-strip">
          <ModeBadge health={health} config={llmConfig} />
          {tab === "plan" && (
            <button className="focus-toggle" onClick={() => setFocusMode(!focusMode)}>
              {focusMode ? "Show Evidence" : "Focus Mode"}
            </button>
          )}
        </div>

        {/* ── Plan view ──────────────────────────────────────────────────── */}
        {tab === "plan" && (
          <div className="grid-main"
            ref={gridRef}
            style={!focusMode ? {
              gridTemplateColumns: `${colWidths[0]}px 6px 1fr 6px ${colWidths[2]}px`,
            } : {
              gridTemplateColumns: `${colWidths[0]}px 6px 1fr`,
            }}>

            {/* LEFT: Input */}
            <div className="col"
              onDragOver={e => { e.preventDefault(); setDragging(true); }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}>

              <span className="col-label">
                Input {llmConfig.mode!=="none" && <span className="col-badge">{detectLabel(llmConfig)}</span>}
                {ragIndex && ragIndex.stats.relevantDocs > 0 && (
                  <span className="col-badge badge-kb">KB: {ragIndex.stats.relevantDocs}/{ragIndex.stats.totalDocs} docs</span>
                )}
              </span>

              <div className="card intent-card">
                <input className="intent-input" type="text"
                  value={intent}
                  onChange={e => setIntent(e.target.value)}
                  placeholder="What are you trying to do? e.g. Sell PLAXIS + Leapfrog to Gamuda for Sarawak hydro dams" />
              </div>

              <div className={"card drop-card"+(dragging?" dragging":"")}>
                {dragging && <div className="drop-overlay">Drop files here</div>}
                <textarea className="input-area"
                  placeholder={"Paste account notes, call summaries, CRM exports, emails…\n\nDrag & drop: .txt .csv .xlsx .docx"}
                  value={input} onChange={e => setInput(e.target.value)} />
                <div className="action-row">
                  <button className="btn-primary" onClick={handleGenerate} disabled={loading}>
                    {loading ? <><span className="spinner" />Generating…</> : "Generate Plan"}
                  </button>
                  {plan && <button className="btn-secondary" onClick={() => { setPlan(null); setInput(""); setStatusSteps([]); setWebResults([]); setLastTrace(null); }}>Clear</button>}
                </div>
              </div>

              {statusSteps.length > 0 && (
                <div className="pipeline-log">
                  {statusSteps.map((s,i) => (
                    <div key={i} className={"log-line"+(s.startsWith("⚠")?" log-warn":s.includes("✓")?" log-ok":"")}>
                      {s}
                    </div>
                  ))}
                  {lastTrace && (
                    <div className="log-line log-export">
                      <button className="link-btn" onClick={exportDiagnostics}>Export trace</button>
                      <span className="mono muted" style={{fontSize:"10px", marginLeft:"6px"}}>
                        {lastTrace.mode} · {lastTrace.result}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {plan && (
                <div className="card">
                  <span className="col-label" style={{display:"block",marginBottom:"10px"}}>
                    Opportunities
                    <span className={"plan-mode-badge mode-"+(plan.planMode==="pipeline"?"pipeline":"manual")}>
                      {plan.planMode==="pipeline" ? "● Pipeline" : "○ Deterministic"}
                    </span>
                  </span>
                  <div className="opp-list">
                    {plan.opportunities.map(opp => (
                      <div key={opp.id}
                        className={"opp-row"+(opp.selected?" selected":"")+(opp.grounded?"":" ungrounded")}
                        onClick={() => selectOpportunity(opp.id)}>
                        <div className="opp-info">
                          <span className="opp-title">{opp.title}</span>
                          <span className="opp-why">{opp.whyNow}{!opp.grounded?" [ASSUMPTION]":""}</span>
                        </div>
                        <span className="score-badge">{opp.totalScore}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {plan && (
                <div className="grounding-bar">
                  <span className="grounding-label">Grounding {plan.groundingScore}%</span>
                  <div className="grounding-track"><div className="grounding-fill" style={{width:plan.groundingScore+"%"}} /></div>
                  <div className="source-tags">{plan.sourceTags.map(t => <SourceBadge key={t} tag={t} />)}</div>
                </div>
              )}
            </div>

            {/* ── Resize handle: Input ↔ Plan ── */}
            <div className="col-splitter" onMouseDown={e => startResize(0, e)} />

            {/* CENTRE: Plan output */}
            <div className="col col-plan">
              <div className="col-label-row">
                <span className="col-label">Plan</span>
                {plan && <button className="btn-export" onClick={() => exportPlanToDocx(plan)}>Export DOCX</button>}
              </div>
              {!plan ? (
                <div className="empty-state"><span className="empty-hint">Generate a plan to see results</span></div>
              ) : (
                <div className="card plan-card">
                  <div className="plan-header">
                    <PlanField label="Account"  value={plan.account} />
                    {plan.division && <PlanField label="Division" value={plan.division} />}
                    {plan.project  && <PlanField label="Project"  value={plan.project} />}
                    <PlanField label="Sector"   value={plan.sector} />
                    <PlanField label="State"    value={plan.stateOfAccount} />
                  </div>

                  {plan.roles.length > 0 && (
                    <>
                      <hr className="divider" />
                      <span className="section-label">Roles</span>
                      <div className="roles-list mt6">
                        {plan.roles.map((r,i) => (
                          <div className="role-row" key={i}>
                            <span className={"stance stance-"+r.stance} style={{flexShrink:0}}>
                              {r.stance==="champion"?"★":r.stance==="risk"?"⚠":"·"}
                            </span>
                            <span className="role-name">{r.name}</span>
                            <span className="s-score mono">{r.influenceScore}</span>
                          </div>
                        ))}
                      </div>
                    </>
                  )}

                  {plan.contacts.length > 0 && (
                    <>
                      <hr className="divider" />
                      <span className="section-label">Contacts</span>
                      <div className="mt6">
                        {plan.contacts.map((c,i) => (
                          <div key={i} className="contact-row">{c}</div>
                        ))}
                      </div>
                    </>
                  )}

                  <hr className="divider" />
                  <PlanField label="Champion" value={plan.champion} />

                  <hr className="divider" />
                  <span className="section-label">Critical Project Issue</span>
                  <p className="body-text mt6">{plan.criticalProjectIssue}</p>

                  <hr className="divider" />
                  <span className="section-label">Solution</span>
                  <p className="body-text mt6">{plan.solution}</p>

                  <hr className="divider" />
                  <span className="section-label">Advantage</span>
                  <p className="body-text mt6">{plan.advantage}</p>

                  {plan.caseStudy && !plan.caseStudy.includes("[ASSUMPTION") && (
                    <>
                      <hr className="divider" />
                      <span className="section-label">Case Study</span>
                      <p className="body-text mt6">{plan.caseStudy}</p>
                    </>
                  )}

                  <hr className="divider" />
                  <span className="section-label">Action Items</span>
                  <ol className="action-list mt6">
                    {plan.actionItems.map((item,i) => (
                      <li key={i}>
                        <span>{item.action}</span>
                        {item.owner && <span className="action-owner">{item.owner}</span>}
                        {item.deadline && item.deadline!=="[ASSUMPTION]" && (
                          <span className="action-deadline mono">{item.deadline}</span>
                        )}
                      </li>
                    ))}
                  </ol>

                  {plan.projects.length > 0 && (
                    <>
                      <hr className="divider" />
                      <span className="section-label">Projects</span>
                      <div className="projects-table mt6">
                        <div className="proj-head">
                          <span>Project</span><span>Status</span><span>Phase</span><span>Bentley Fit</span>
                        </div>
                        {plan.projects.map((p) => (
                          <div className={"proj-row proj-status-" + p.status} key={p.id}>
                            <span className="proj-name">
                              {p.name}
                              {p.source === "[WEB]" && <span className="source-badge badge-web" style={{marginLeft:4,fontSize:9}}>[WEB]</span>}
                            </span>
                            <span className={"proj-status-badge status-" + p.status}>
                              {p.status.replace(/_/g, " ")}
                            </span>
                            <span className="proj-phase mono">{p.phase}</span>
                            <span className="proj-fit">{p.bentleyFit.join(", ")}</span>
                          </div>
                        ))}
                      </div>
                    </>
                  )}

                  <hr className="divider" />
                  <span className="section-label">RACI</span>
                  <div className="raci-table mt6">
                    <div className="raci-head"><span>Activity</span><span>R</span><span>A</span><span>C</span><span>I</span></div>
                    {plan.raci.map((row,i) => (
                      <div className="raci-row" key={i}>
                        <span>{row.activity}</span>
                        <span className="mono">{row.responsible}</span>
                        <span className="mono">{row.accountable}</span>
                        <span className="mono">{row.consulted}</span>
                        <span className="mono">{row.informed}</span>
                      </div>
                    ))}
                  </div>

                  {plan.redFlags.length > 0 && (
                    <>
                      <hr className="divider" />
                      <span className="section-label">Red Flags</span>
                      <div className="mt6">
                        {plan.redFlags.map((f,i) => (
                          <RedFlagRow key={i} {...f} />
                        ))}
                      </div>
                    </>
                  )}

                  {plan.assumptions.length > 0 && (
                    <>
                      <hr className="divider" />
                      <span className="section-label">Assumptions Register</span>
                      <div className="assumptions mt6">
                        {plan.assumptions.map((a,i) => (
                          <div className="assumption-row" key={i}>
                            <span className="a-field mono">{a.field}</span>
                            <span className="a-val">{a.value.slice(0,60)}</span>
                            <span className="a-date mono">by {a.verifyBy}</span>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>

            {/* ── Resize handle: Plan ↔ Evidence ── */}
            {!focusMode && <div className="col-splitter" onMouseDown={e => startResize(1, e)} />}

            {/* RIGHT: Diagrams + Evidence — FIX-UI-001: collapsible */}
            {!focusMode && (
              <div className="col col-evidence">
                <span className="col-label">Evidence</span>
                {!plan ? (
                  <div className="empty-state"><span className="empty-hint">Diagrams and evidence appear after generating a plan</span></div>
                ) : (
                  <>
                    <div className="card">
                      <MermaidBlock code={plan.orgMermaid} title="Org Chart" theme={theme} />
                      {plan.orgAlt && (
                        <details className="diagram-detail">
                          <summary className="link-btn">ALT Narrative + Node Outline</summary>
                          <p className="muted small mt6">{plan.orgAlt}</p>
                          <ul className="outline-list">
                            {plan.orgNodeOutline.map((n,i) => <li key={i}>{n}</li>)}
                          </ul>
                        </details>
                      )}
                    </div>

                    <div className="card">
                      <MermaidBlock code={plan.archMermaid} title="Solution Map" theme={theme} />
                      {plan.archAlt && (
                        <details className="diagram-detail">
                          <summary className="link-btn">ALT Narrative + Flow Outline</summary>
                          <p className="muted small mt6">{plan.archAlt}</p>
                          <ul className="outline-list">
                            {plan.archFlowOutline.map((n,i) => <li key={i}>{n}</li>)}
                          </ul>
                        </details>
                      )}
                    </div>

                    {plan.mindMap && (
                      <div className="card">
                        <MermaidBlock code={plan.mindMap} title="Account Mind Map" theme={theme} />
                      </div>
                    )}

                    <div className="card">
                      <span className="col-label" style={{display:"block",marginBottom:"10px"}}>Signals</span>
                      {plan.signals.length === 0
                        ? <p className="muted small">No signals extracted. Add richer context.</p>
                        : plan.signals.slice(0,10).map((s,i) => (
                            <div className="ev-row" key={i}>
                              <SourceBadge tag={s.tag} />
                              <span className="ev-claim">{s.claim}</span>
                              <span className={"conf conf-"+s.confidence}>{s.confidence}</span>
                            </div>
                          ))
                      }
                      {webResults.length > 0 && (
                        <>
                          <hr className="divider" />
                          <span className="section-label">Web Sources</span>
                          {webResults.slice(0,6).map((r,i) => (
                            <div className="web-result" key={i}>
                              <a href={r.url} target="_blank" rel="noreferrer" className="web-title">{r.title}</a>
                              <p className="muted small">{r.snippet.slice(0,140)}</p>
                            </div>
                          ))}
                        </>
                      )}
                    </div>
                  </>
                )}
              </div>
            )}

          </div>
        )}

        {/* ── Settings view ────────────────────────────────────────────── */}
        {tab === "history" && (
          <div className="settings-page">
            <div className="settings-col" style={{maxWidth: 700}}>
              <h2 className="section-label" style={{marginBottom: 16}}>Plan History</h2>
              {history.length === 0 && <p style={{color: "var(--muted)"}}>No plans generated yet. Generate a plan to see it here.</p>}
              {history.map(h => (
                <div key={h.id} className="helper-item" style={{cursor:"pointer", marginBottom: 8}} onClick={() => { setPlan(h.plan); setInput(""); setTab("plan"); }}>
                  <div style={{fontWeight:600}}>{h.account}</div>
                  <div style={{fontSize:12, color:"var(--muted)"}}>{h.date} · {h.plan.planMode === "pipeline" ? "Pipeline" : "Deterministic"} · Grounding {h.plan.groundingScore}%</div>
                </div>
              ))}
              {history.length > 0 && (
                <button className="btn-secondary" style={{marginTop: 16}} onClick={() => {
                  if (confirm("Clear all plan history?")) {
                    setHistory([]);
                    try { localStorage.removeItem("su_history"); } catch {}
                  }
                }}>Clear History</button>
              )}
            </div>
          </div>
        )}

        {tab === "settings" && (
          <div className="settings-page">
            <div className="settings-col">

              {/* FIX-SET-001: Save indicator */}
              {savedAt && (
                <div className="save-indicator">
                  <span className="save-dot">●</span> Saved at {savedAt}
                </div>
              )}

              {/* ── Primary: LLM key ── */}
              <span className="col-label">AI Provider (Optional)</span>
              <div className="card">
                <div className="field">
                  <label className="field-label">Paste your API key — provider detected automatically</label>
                  <input
                    className={"text-input"+(llmConfig.mode!=="none"?" input-detected":"")}
                    type={llmRaw.match(/^(sk-|gsk_|sk-ant-|AIza)/) ? "password" : "text"}
                    value={llmRaw}
                    onChange={e => handleLLMInput(e.target.value)}
                    placeholder="sk-… OpenAI  |  gsk_… Groq  |  AIza… Gemini  |  http://localhost:11434 Ollama"
                  />
                  <div className="detected-badge">
                    <span className={"badge-detected"+(llmConfig.mode==="none"?" badge-offline":" badge-active")}>
                      {llmDetected}
                    </span>
                    {llmConfig.mode!=="none" && (
                      <button className="btn-ghost small" onClick={handleTest} disabled={testing}>
                        {testing ? "Testing…" : "Test"}
                      </button>
                    )}
                    {testResult && <span className={"test-result"+(testResult.startsWith("✓")?" ok":" err")}>{testResult}</span>}
                  </div>
                  <span className="field-hint">Works without an AI provider — plans are generated deterministically from your input. An AI provider enriches the plan with deeper analysis.</span>
                  <button className="link-btn" style={{marginTop:"6px"}} onClick={() => setShowApiHelper(true)}>Don't have an API key? Get one free →</button>
                </div>
              </div>

              {/* API Key helper dialog */}
              {showApiHelper && (
                <div className="card helper-card">
                  <div className="helper-header">
                    <span className="section-label">Get a Free API Key</span>
                    <button className="link-btn" onClick={() => setShowApiHelper(false)}>Close</button>
                  </div>
                  <div className="helper-list">
                    <div className="helper-item">
                      <span className="helper-provider">Google Gemini</span>
                      <span className="helper-desc">Free tier, generous limits. Best for most users.</span>
                      <span className="helper-steps">1. Go to <a href="https://aistudio.google.com/apikey" target="_blank" rel="noreferrer" className="web-title">aistudio.google.com/apikey</a> 2. Sign in with Google 3. Click "Create API Key" 4. Copy and paste it above</span>
                    </div>
                    <div className="helper-item">
                      <span className="helper-provider">Groq</span>
                      <span className="helper-desc">Very fast inference. Free tier available.</span>
                      <span className="helper-steps">1. Go to <a href="https://console.groq.com/keys" target="_blank" rel="noreferrer" className="web-title">console.groq.com/keys</a> 2. Sign up / sign in 3. Create new API key 4. Copy and paste it above</span>
                    </div>
                    <div className="helper-item">
                      <span className="helper-provider">OpenAI</span>
                      <span className="helper-desc">GPT-4o. Requires billing setup.</span>
                      <span className="helper-steps">1. Go to <a href="https://platform.openai.com/api-keys" target="_blank" rel="noreferrer" className="web-title">platform.openai.com/api-keys</a> 2. Sign up / sign in 3. Create new secret key 4. Copy and paste it above</span>
                    </div>
                  </div>
                </div>
              )}

              {/* ── Primary: Web search key ── */}
              <span className="col-label" style={{marginTop:"8px"}}>Web Research (Optional)</span>
              <div className="card">
                <div className="field">
                  <label className="field-label">Serper.dev API key — free at serper.dev (2,500 searches/month, no credit card)</label>
                  <input className="text-input" type="password" value={llmConfig.webSearchKey}
                    onChange={e => updateLLM({ webSearchKey: e.target.value })}
                    placeholder="Paste Serper API key to enable web research" />
                  <span className="field-hint">Web research runs automatically using DuckDuckGo (free, no key needed). Add a Serper key for higher-quality Google-based results.</span>
                </div>
              </div>

              {/* ── Advanced toggle ── */}
              <button className="advanced-toggle" onClick={() => setShowAdvanced(!showAdvanced)}>
                {showAdvanced ? "▾ Hide Advanced Settings" : "▸ Advanced Settings"}
              </button>

              {showAdvanced && (
                <>
                  {/* Model / Endpoint / Temperature / Tokens */}
                  {llmConfig.mode!=="none" && (
                    <>
                      <span className="col-label" style={{marginTop:"4px"}}>Model & Endpoint</span>
                      <div className="card">
                        <div className="field-row">
                          <div className="field half">
                            <label className="field-label">Model</label>
                            <input className="text-input" type="text" value={llmConfig.model}
                              onChange={e => updateLLM({ model: e.target.value })} />
                          </div>
                          <div className="field half">
                            <label className="field-label">Endpoint</label>
                            <input className="text-input" type="text" value={llmConfig.endpoint}
                              onChange={e => updateLLM({ endpoint: e.target.value })} />
                          </div>
                        </div>
                        <div className="field-row">
                          <div className="field half">
                            <label className="field-label">Temperature</label>
                            <input className="text-input" type="number" min="0" max="2" step="0.1"
                              value={llmConfig.temperature} onChange={e => updateLLM({ temperature: parseFloat(e.target.value)||0.1 })} />
                          </div>
                          <div className="field half">
                            <label className="field-label">Max tokens</label>
                            <input className="text-input" type="number" min="512" max="8192" step="256"
                              value={llmConfig.maxTokens} onChange={e => updateLLM({ maxTokens: parseInt(e.target.value)||4096 })} />
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  {/* Local fallback */}
                  <span className="col-label" style={{marginTop:"4px"}}>Local Fallback</span>
                  <div className="card">
                    <div className="field">
                      <label className="field-label">Local Ollama endpoint</label>
                      <input className="text-input" type="text" value={llmConfig.localEndpoint}
                        onChange={e => updateLLM({ localEndpoint: e.target.value })}
                        placeholder="http://localhost:11434" />
                    </div>
                    <div className="field">
                      <label className="field-label">Local model</label>
                      <input className="text-input" type="text" value={llmConfig.localModel}
                        onChange={e => updateLLM({ localModel: e.target.value })}
                        placeholder="llama3.2" />
                    </div>
                  </div>

                  {/* Prompt overrides */}
                  <span className="col-label" style={{marginTop:"4px"}}>Prompt Overrides</span>
                  <div className="card">
                    <p className="muted small" style={{marginBottom:"14px"}}>
                      Override individual pipeline prompts. Empty = built-in defaults.
                    </p>
                    {(["extractor","planner","composer","verifier"] as const).map(slot => (
                      <div className="field" key={slot}>
                        <label className="field-label">{slot}</label>
                        <textarea className="slot-area" rows={3}
                          disabled={llmConfig.mode==="none"}
                          value={slots[slot]}
                          onChange={e => updateSlot(slot, e.target.value)}
                          placeholder={llmConfig.mode==="none" ? "Configure AI provider first" : `Custom ${slot} prompt…`} />
                      </div>
                    ))}
                  </div>

                  {/* Diagnostics */}
                  <span className="col-label" style={{marginTop:"4px"}}>Diagnostics</span>
                  <div className="card">
                    <div className="field-row" style={{gap:"8px"}}>
                      <button className="btn-ghost" onClick={exportDiagnostics} disabled={!lastTrace}>
                        Export Last Trace
                      </button>
                      <button className="btn-ghost" onClick={async () => {
                        const h = await probeHealth(llmConfig);
                        setHealth(h);
                        setTestResult(`Primary: ${h.primary} · Local: ${h.local} · Active: ${h.activeProvider}`);
                      }}>
                        Run Health Check
                      </button>
                    </div>
                    {health && (
                      <div className="health-grid mt6">
                        <span className="health-row"><span className="mono muted">Primary</span><span className={`health-dot health-${health.primary}`}>{health.primary}</span></span>
                        <span className="health-row"><span className="mono muted">Local</span><span className={`health-dot health-${health.local}`}>{health.local}</span></span>
                        <span className="health-row"><span className="mono muted">Active</span><span className="mono">{health.activeProvider}</span></span>
                      </div>
                    )}
                  </div>
                </>
              )}

              {/* ── Knowledge Base (RAG) ── */}
              <span className="col-label" style={{marginTop:"8px"}}>Knowledge Base</span>
              <div className="card">
                <div className="field">
                  <label className="field-label">Sync local files to build a keyword index. Scale Up only pulls relevant data during plan generation.</label>
                  <div className="field-row" style={{gap:"8px",alignItems:"center"}}>
                    <label className="btn-ghost" style={{cursor:"pointer"}}>
                      Select Folder
                      <input type="file" style={{display:"none"}}
                        {...{webkitdirectory:"true",directory:"true",multiple:true} as any}
                        onChange={async (e) => {
                          const files = Array.from(e.target.files || []);
                          if (!files.length) return;
                          const intentText = intent.trim() || input.trim().slice(0, 200);
                          if (!intentText) { setRagProgress("⚠ Set an intent or paste notes first"); return; }
                          setRagSyncing(true); setRagProgress("Syncing…");
                          try {
                            const idx = await syncFolder(files, intentText, files[0]?.webkitRelativePath?.split("/")[0] || "local",
                              (p) => setRagProgress(`${p.current}/${p.total}: ${p.filename}`));
                            setRagIndex(idx);
                            setRagProgress(`✓ ${idx.stats.relevantDocs}/${idx.stats.totalDocs} relevant docs (${idx.stats.syncDurationMs}ms)`);
                          } catch (err) {
                            setRagProgress(`⚠ Sync failed: ${err instanceof Error ? err.message : String(err)}`);
                          }
                          setRagSyncing(false);
                        }} />
                    </label>
                    {ragIndex && (
                      <button className="btn-ghost" onClick={() => { setRagIndex(null); localStorage.removeItem("su_rag_index"); setRagProgress("KB cleared"); }}>
                        Clear KB
                      </button>
                    )}
                  </div>
                  {ragProgress && <span className={"field-hint"+(ragProgress.startsWith("✓")?" hint-ok":ragProgress.startsWith("⚠")?" hint-warn":"")}>{ragProgress}</span>}
                  {ragIndex && (
                    <div className="kb-stats mt6">
                      <span className="mono muted" style={{fontSize:"10px"}}>
                        {ragIndex.stats.totalDocs} docs · {ragIndex.stats.relevantDocs} relevant · {ragIndex.stats.totalSizeKb}KB · synced {new Date(ragIndex.updatedAt).toLocaleDateString()}
                      </span>
                      {ragIndex.documents.slice(0, 5).map((d, i) => (
                        <div key={i} className="kb-doc-row">
                          <span className="kb-doc-name">{d.filename}</span>
                          <span className={"kb-doc-rel"+(d.relevance >= 0.15?" rel-high":" rel-low")}>{Math.round(d.relevance*100)}%</span>
                        </div>
                      ))}
                      {ragIndex.documents.length > 5 && <span className="muted" style={{fontSize:"10px"}}>+{ragIndex.documents.length - 5} more</span>}
                    </div>
                  )}
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
}
