// orchestrator.ts — Generation pipeline as explicit state machine
// FIX-GEN-001: Extracted from App.tsx. Typed stages with merge policy.
// FIX-GEN-002: LLM repair pass for non-JSON responses.

import {
  callLLM, webSearch, probeHealth,
  LLMConfig, LLMResult, SearchResult, ProviderHealth, detectLabel,
} from "./llm";
import {
  parseContext, composePlan, buildLLMExtractionPrompt, buildWebQueries,
  extractStakeholdersFromWeb,
  Plan, WebSnippet, ParsedContext,
} from "./engine";
import { loadRAGIndex, queryRAG, formatRAGContext, RAGQueryResult } from "./rag";
import type { PromptSlots } from "./types";

// ─── Run trace (FIX-OBS-001: diagnostics) ────────────────────────────────

export interface RunStep {
  stage: string;
  message: string;
  ok: boolean;
  durationMs?: number;
  provider?: string;
}

export interface RunTrace {
  id: string;
  startedAt: string;
  completedAt: string;
  steps: RunStep[];
  health: ProviderHealth;
  inputLength: number;
  mode: "pipeline" | "deterministic";
  result: "success" | "partial" | "fallback";
}

export interface GenerateResult {
  plan: Plan;
  webResults: SearchResult[];
  trace: RunTrace;
}

// ─── Orchestrator ────────────────────────────────────────────────────────

export async function runGeneration(
  input: string,
  config: LLMConfig,
  slots: PromptSlots,
  onStep: (msg: string) => void,
  forceOffline?: boolean,
): Promise<GenerateResult> {
  const traceId = `run-${Date.now()}`;
  const steps: RunStep[] = [];
  const started = new Date().toISOString();
  let webResults: SearchResult[] = [];

  function step(stage: string, message: string, ok = true, extra?: Partial<RunStep>) {
    steps.push({ stage, message, ok, ...extra });
    onStep(message);
  }

  // ── Stage 0: Health probe ──────────────────────────────────────────────
  let health: ProviderHealth = { primary: "unconfigured", local: "unconfigured", activeProvider: "deterministic" };
  if (!forceOffline && config.mode !== "none") {
    step("health", "Probing provider health…");
    const t0 = Date.now();
    health = await probeHealth(config);
    step("health", `Provider: ${health.activeProvider} (${Date.now() - t0}ms)`, true, { durationMs: Date.now() - t0 });
  } else {
    health.activeProvider = "deterministic";
    step("health", forceOffline ? "Forced offline — deterministic mode" : "No LLM configured — deterministic mode");
  }

  const isDeterministic = health.activeProvider === "deterministic" || forceOffline;

  // ── Stage 1: Deterministic parse ───────────────────────────────────────
  step("parse", "① Parsing context…");
  const t1 = Date.now();
  const ctxPre = parseContext(input, [], "pipeline");
  step("parse", `  Sector: ${ctxPre.sector} · ${ctxPre.stakeholders.length} stakeholders`, true, { durationMs: Date.now() - t1 });

  // ── Stage 1.5: Local knowledge base query ───────────────────────────
  let ragContext = "";
  const ragIndex = loadRAGIndex();
  if (ragIndex && ragIndex.documents.length > 0) {
    step("rag", "① KB: Querying local knowledge base…");
    const ragResult = queryRAG(ragIndex, input);
    if (ragResult.docsUsed > 0) {
      ragContext = formatRAGContext(ragResult);
      step("rag", `  ✓ ${ragResult.docsUsed} docs used, ${ragResult.docsSkipped} skipped (${Math.round(ragResult.totalChars/1024)}KB)`, true);
    } else {
      step("rag", `  ⚠ No relevant docs found in KB (${ragResult.docsSkipped} below threshold)`, false);
    }
  }

  // ── Stage 2: Web research — always runs (DuckDuckGo fallback if no Serper key)
  let webSnippets: WebSnippet[] = [];
  if (!forceOffline) {
    const queries = buildWebQueries(ctxPre);
    const source = config.webSearchKey ? "Serper" : "DuckDuckGo";
    step("web", `② Web research via ${source} (${queries.length} queries)…`);
    for (const q of queries) step("web", `  → "${q}"`);
    const t2 = Date.now();
    const results = await webSearch(queries, config.webSearchKey);
    webSnippets = results.map(r => ({ title: r.title, snippet: r.snippet, url: r.url }));
    webResults = results;
    if (results.length > 0) {
      step("web", `  ✓ ${results.length} results from ${queries.length} queries [${source}]`, true, { durationMs: Date.now() - t2 });
    } else {
      step("web", `  ⚠ No results returned`, false, { durationMs: Date.now() - t2 });
    }
  } else {
    step("web", "② Web: forced offline — skipped");
  }

  // Re-parse with web context + RAG context
  const enrichedInput = ragContext ? `${input}\n\n${ragContext}` : input;
  const hasWeb = webSnippets.length > 0;
  const ctx = parseContext(enrichedInput, webSnippets, hasWeb || !isDeterministic ? "pipeline" : "manual");

  // ── Stage 2.5: Extract stakeholders from web results ─────────────────
  if (webResults.length > 0) {
    const webStakeholders = extractStakeholdersFromWeb(webResults);
    if (webStakeholders.length > 0) {
      step("web", `  ✓ ${webStakeholders.length} stakeholder(s) identified from web`);
      // Merge web-discovered stakeholders (avoid duplicates)
      const existingNames = new Set(ctx.stakeholders.map(s => s.nameOrRole.toLowerCase().slice(0, 20)));
      for (const ws of webStakeholders) {
        if (!existingNames.has(ws.nameOrRole.toLowerCase().slice(0, 20))) {
          ctx.stakeholders.push(ws);
          existingNames.add(ws.nameOrRole.toLowerCase().slice(0, 20));
        }
      }
    }
  }

  // ── Stage 3: LLM extraction ────────────────────────────────────────────
  let llmPlan: Partial<Plan> | undefined;
  if (!isDeterministic) {
    const label = health.activeProvider === "local"
      ? `Ollama · ${config.localModel || "llama3.2"}`
      : detectLabel(config);
    step("llm", `③ LLM extraction (${label})…`);

    const webCtx = webSnippets.map(w => `[${w.url}] ${w.title}: ${w.snippet}`).join("\n");
    const fullCtx = [webCtx, ragContext].filter(Boolean).join("\n\n");
    const sys = slots.extractor || buildLLMExtractionPrompt(input, fullCtx, ctx.sector);
    const t3 = Date.now();
    const result = await callLLM(config, sys, "Return the JSON now. ONLY JSON, no fences.");

    if (result.ok) {
      llmPlan = tryParseLLMResponse(result.text);
      if (llmPlan) {
        // FIX-GEN-001: Validate extracted fields — null out low-confidence fabrications
        llmPlan = validateLLMFields(llmPlan, ctx);
        step("llm", `  ✓ LLM extraction complete (${result.provider}, ${Date.now() - t3}ms)`, true,
          { durationMs: Date.now() - t3, provider: result.provider });
      } else {
        step("llm", `  ⚠ LLM non-JSON — repair failed, deterministic fallback`, false);
      }
    } else {
      step("llm", `  ⚠ LLM error: ${result.error}`, false);
    }
  } else {
    step("llm", "③ LLM: deterministic mode — skipped");
  }

  // ── Stage 4: Compose ───────────────────────────────────────────────────
  step("compose", "④ Composing plan…");
  const t4 = Date.now();
  const composed = composePlan(ctx, llmPlan);
  step("compose", `  ✓ Grounding: ${composed.groundingScore}% · ${composed.assumptions.length} assumptions · ${composed.redFlags.length} red flags`,
    true, { durationMs: Date.now() - t4 });

  const trace: RunTrace = {
    id: traceId,
    startedAt: started,
    completedAt: new Date().toISOString(),
    steps,
    health,
    inputLength: input.length,
    mode: isDeterministic ? "deterministic" : "pipeline",
    result: llmPlan ? "success" : (isDeterministic ? "fallback" : "partial"),
  };

  return { plan: composed, webResults, trace };
}

// ─── LLM response repair (FIX-GEN-002) ──────────────────────────────────

function tryParseLLMResponse(text: string): Partial<Plan> | undefined {
  // Attempt 1: direct parse
  const cleaned = text.replace(/```json|```/g, "").trim();
  try { return JSON.parse(cleaned); } catch {}

  // Attempt 2: find first { ... } block
  const braceStart = cleaned.indexOf("{");
  const braceEnd = cleaned.lastIndexOf("}");
  if (braceStart >= 0 && braceEnd > braceStart) {
    try { return JSON.parse(cleaned.slice(braceStart, braceEnd + 1)); } catch {}
  }

  // Attempt 3: line-by-line cleanup (trailing commas, comments)
  try {
    const lines = cleaned.slice(braceStart >= 0 ? braceStart : 0, (braceEnd > 0 ? braceEnd + 1 : undefined))
      .split("\n")
      .map(l => l.replace(/\/\/.*$/, "").replace(/,(\s*[}\]])/, "$1"))
      .join("\n");
    return JSON.parse(lines);
  } catch {}

  return undefined;
}

// ─── FIX-GEN-001: Validate LLM-extracted fields ─────────────────────────

function validateLLMFields(llm: Partial<Plan>, ctx: ParsedContext): Partial<Plan> {
  const validated = { ...llm };

  // Null out fields that look fabricated (very long strings not in input)
  const inputLower = ctx.rawInput.toLowerCase();

  // Validate account — if LLM invented a name not in input, discard
  if (validated.account && validated.account.length > 3) {
    const nameCore = validated.account.replace(/\[.*?\]/g, "").trim().toLowerCase();
    if (nameCore.length > 5 && !inputLower.includes(nameCore.slice(0, 15))) {
      validated.account = undefined; // let deterministic handle it
    }
  }

  // Validate champion — must reference someone from input
  if (validated.champion && validated.champion.length > 3) {
    const champCore = validated.champion.replace(/\[.*?\]/g, "").trim().toLowerCase();
    if (champCore.length > 5 && !inputLower.includes(champCore.slice(0, 12))) {
      validated.champion = undefined;
    }
  }

  // Validate action items — owners must be from input or generic roles
  const genericRoles = new Set(["ae", "se", "account lead", "acct lead", "sol dir.", "board", "all", "finance", "legal/infosec", "tech champion", "tech team", "all stakeholders"]);
  if (validated.actionItems) {
    validated.actionItems = validated.actionItems.map(item => {
      if (item.owner && !genericRoles.has(item.owner.toLowerCase()) && !inputLower.includes(item.owner.toLowerCase().slice(0, 10))) {
        return { ...item, owner: "Account Lead", source: "[INFERRED]" };
      }
      return item;
    });
  }

  return validated;
}
