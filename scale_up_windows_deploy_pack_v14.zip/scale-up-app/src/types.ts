// types.ts — Shared type definitions

export type PromptSlots = {
  planner: string;
  extractor: string;
  composer: string;
  verifier: string;
};
