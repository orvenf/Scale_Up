"""
Scale Up v14 - deploy/5_verify.py
Final verification: confirms all required outputs exist.

Called by deploy.bat as a direct file path:
    python.exe deploy\5_verify.py --root <pack_root>
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import utils

args = utils.parse_common_args()
root, cfg, log = utils.setup(args)
start = utils.stage_timer_start()

utils.log_line(log, "[INFO] Stage 5: final verification")

app_root        = root / cfg["paths"]["app_root"]
artifacts       = root / cfg["paths"]["artifacts_root"]
runtime_settings = root / cfg["paths"]["settings_root"] / "app_runtime.json"
timings         = root / cfg["paths"]["logs_root"] / "stage_timings.json"

if not app_root.exists():
    utils.fail(log, "App root missing after scaffold/build")
if not runtime_settings.exists():
    utils.fail(log, "Runtime settings file was not produced by Stage 3")
if not artifacts.exists():
    utils.fail(log, "Artifacts directory is missing")
if not timings.exists():
    utils.fail(log, "Stage timings file missing (stage_timings.json)")

artifact_files = [p for p in artifacts.rglob("*") if p.is_file()]
if not artifact_files:
    utils.fail(log, "No packaged artifacts found in runtime/artifacts")

msi_files = [p for p in artifact_files if p.suffix.lower() == ".msi"]
if not msi_files:
    utils.fail(log, "No MSI artifact found in runtime/artifacts")

# Verify required stage timing keys are present
timing_data = utils.load_json(timings)
required_keys = ["1_prereqs", "2_binaries", "3_llm", "4_build"]
for key in required_keys:
    if key not in timing_data:
        utils.fail(log, f"Missing stage timing entry: {key}")

ms = utils.stage_timer_end(root, "5_verify", start)
utils.write_marker(root, "05_verify.ok")
utils.log_line(log, f"[OK] Found {len(artifact_files)} artifact file(s), "
                    f"including {len(msi_files)} MSI file(s)")
utils.log_line(log, f"[OK] Stage 5 complete in {ms} ms")
