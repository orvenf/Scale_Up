"""
Scale Up v14 - deploy/2_binaries.py
Cache directory setup and network policy confirmation.

Called by deploy.bat as a direct file path:
    python.exe deploy\2_binaries.py --root <pack_root>
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import utils

args = utils.parse_common_args()
root, cfg, log = utils.setup(args)
start = utils.stage_timer_start()

utils.log_line(log, "[INFO] Stage 2: cache and network policy preparation")

downloads = root / cfg["paths"]["downloads_root"]
utils.ensure_dir(downloads)
(root / "runtime" / "cache" / ".gitkeep").write_text("", encoding="utf-8")

if not cfg["install"]["always_use_internet"]:
    utils.log_line(log, "[WARN] Config does not match current deployment policy. "
                        "This pack expects internet-enabled bootstrap.")
else:
    utils.log_line(log, "[OK] Internet-enabled bootstrap policy confirmed")

ms = utils.stage_timer_end(root, "2_binaries", start)
utils.write_marker(root, "02_binaries.ok")
utils.log_line(log, f"[OK] Stage 2 complete in {ms} ms")
