ALLOWED_OUTPUTS = {
    "deploy.bat",
    "deploy/config.json",
    "deploy/utils.py",
    "deploy/1_prereqs.py",
    "deploy/2_binaries.py",
    "deploy/3_llm.py",
    "deploy/4_build.py",
    "deploy/5_verify.py",
    "deploy/contracts.py",
    "scaffolds/scaffold_files.json",
}

ALLOWED_EXTENSIONS = {".bat", ".py", ".json"}
FORBIDDEN_EXTENSIONS = {".ps1", ".sh", ".yaml", ".yml", ".dockerfile", ".md"}

SYSTEM_RULES = """
Generate only BAT, Python, and JSON files required for the Windows deployment pack.
Do not generate PowerShell files, shell scripts, Dockerfiles, CI files, or unrelated documents.
The deployment pack is internet-enabled and targets a fresh Windows machine.
Optional advanced agentic prompts may exist only as bounded settings, not autonomous workflow control.
Stages are called as direct file paths (not -m module mode).
Every stage must begin with sys.path.insert(0, str(Path(__file__).resolve().parent)).
""".strip()
