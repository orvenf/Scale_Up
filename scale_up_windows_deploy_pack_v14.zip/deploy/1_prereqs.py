"""
Scale Up v14 - deploy/1_prereqs.py
Install build prerequisites: Node.js, MSVC Build Tools, Rust, WebView2.

Called by deploy.bat as a direct file path:
    python.exe deploy\1_prereqs.py --root <pack_root>

sys.path.insert(0, ...) ensures utils imports always work, regardless of CWD.
No -m module mode required.
"""
import platform
import shutil
import subprocess
import sys
from pathlib import Path

# ── THIS MUST BE FIRST — makes 'import utils' work from any CWD ──
sys.path.insert(0, str(Path(__file__).resolve().parent))
import utils

args = utils.parse_common_args()
root, cfg, log = utils.setup(args)
start = utils.stage_timer_start()

utils.log_line(log, "[INFO] Stage 1: prerequisites (Node.js, MSVC, Rust, WebView2)")

arch = platform.machine().lower()
is_arm64 = "arm" in arch

downloads = root / cfg["paths"]["downloads_root"]
utils.ensure_dir(downloads)

# ── vswhere ───────────────────────────────────────────────────
vswhere = utils.download_vswhere_if_needed(root, cfg, log)
if not vswhere:
    utils.fail(log, "vswhere could not be resolved or downloaded")
utils.log_line(log, f"[OK] vswhere: {vswhere}")

# ── Node.js ───────────────────────────────────────────────────
utils.log_line(log, "[...] Checking Node.js...")
# Use find_node_safe() — bare "node" fails when PATH hasn't been refreshed
# in the current Python process after a fresh winget/MSI install.
node_exe = utils.find_node_safe()
if node_exe:
    probe = utils.run_allow_fail(log, root, cfg, [node_exe, "-p", "process.versions.node.split('.')[0]"])
    try:
        node_major = int((probe.stdout or "0").strip())
    except ValueError:
        node_major = 0
else:
    node_major = 0

min_major = int(cfg["versions"]["node_min_major"])
if node_major < min_major:
    utils.log_line(log, f"[...] Node.js {node_major} < {min_major} required, installing...")
    url_key = "node_msi_arm64" if is_arm64 else "node_msi_x64"
    sha_key = "node_msi_arm64_sha256" if is_arm64 else "node_msi_x64_sha256"
    node_msi = downloads / ("node-arm64.msi" if is_arm64 else "node-x64.msi")
    utils.download_file(log, root, cfg,
                        cfg["urls"][url_key], node_msi,
                        cfg["hashes"].get(sha_key, ""))
    utils.run(log, root, cfg, ["msiexec", "/i", str(node_msi), "/qn", "/norestart"])
    utils.refresh_path(root, cfg)
else:
    utils.log_line(log, f"[OK] Node.js already satisfies minimum: {node_major}")

# ── MSVC Build Tools ──────────────────────────────────────────
utils.log_line(log, "[...] Checking MSVC Build Tools + Windows SDK...")
vcvars64 = utils.find_vcvars64_with_sdk(root, cfg, log)
if not vcvars64:
    utils.log_line(log, "[...] Installing MSVC Build Tools...")
    utils.check_disk_space(6.0, root)
    vs_bootstrapper = downloads / "vs_BuildTools.exe"
    utils.download_file(log, root, cfg,
                        cfg["urls"]["vs_buildtools_bootstrapper"],
                        vs_bootstrapper,
                        cfg["hashes"].get("vs_buildtools_bootstrapper_sha256", ""))
    install_path = r"C:\BuildTools"
    components = [
        # FIX-SDK-001: ;includeRecommended installs the correct Windows SDK
        # for the current OS (Win10 or Win11) plus MSVC tools automatically.
        "Microsoft.VisualStudio.Workload.VCTools;includeRecommended",
    ]
    cmd = [str(vs_bootstrapper),
           "--quiet", "--wait", "--norestart", "--nocache",
           "--installPath", install_path]
    for comp in components:
        cmd += ["--add", comp]
    utils.run(log, root, cfg, cmd)
    vcvars64 = utils.find_vcvars64_with_sdk(root, cfg, log)

if not vcvars64:
    utils.fail(log,
        "MSVC Build Tools not found after installation.\n"
        "  Fix: Open Visual Studio Installer → Build Tools → Modify\n"
        "       and ensure both 'MSVC v14x C++ build tools' and\n"
        "       'Windows 10/11 SDK' are checked, then re-run deploy.bat.")
utils.log_line(log, f"[OK] Visual Studio environment: {vcvars64}")

# ── Windows SDK + linker smoke test ──────────────────────────
# Verifies kernel32.lib is reachable and a trivial C program links cleanly.
# This is the exact gate that catches LNK1181 before Cargo wastes 10+ minutes.
utils.verify_vs_env(log, root, cfg, vcvars64)

# ── WebView2 ──────────────────────────────────────────────────
if cfg["windows"]["require_webview2"]:
    utils.log_line(log, "[...] Checking WebView2...")
    webview_check = utils.run_allow_fail(log, root, cfg, [
        "reg", "query",
        r"HKLM\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
    ])
    if webview_check.returncode != 0:
        utils.log_line(log, "[...] Installing WebView2...")
        wv = downloads / "MicrosoftEdgeWebView2Setup.exe"
        utils.download_file(log, root, cfg,
                            cfg["urls"]["webview2_bootstrapper"],
                            wv,
                            cfg["hashes"].get("webview2_bootstrapper_sha256", ""))
        utils.run(log, root, cfg, [str(wv), "/silent", "/install"])
    else:
        utils.log_line(log, "[OK] WebView2 runtime detected")

# ── Rust ──────────────────────────────────────────────────────
utils.log_line(log, "[...] Checking Rust / cargo...")
cargo_probe = utils.run_allow_fail(log, root, cfg, ["cargo", "--version"])
if cargo_probe.returncode != 0:
    utils.log_line(log, "[...] Installing Rust toolchain...")
    url_key = "rustup_init_arm64" if is_arm64 else "rustup_init_x64"
    sha_key = "rustup_init_arm64_sha256" if is_arm64 else "rustup_init_x64_sha256"
    host = "aarch64-pc-windows-msvc" if is_arm64 else "x86_64-pc-windows-msvc"
    rustup = downloads / ("rustup-init-arm64.exe" if is_arm64 else "rustup-init-x64.exe")
    utils.download_file(log, root, cfg,
                        cfg["urls"][url_key], rustup,
                        cfg["hashes"].get(sha_key, ""))
    utils.run(log, root, cfg, [
        str(rustup), "-y",
        "--default-toolchain", cfg["versions"]["rust_channel"],
        "--default-host", host
    ])
    utils.refresh_path(root, cfg)
else:
    utils.log_line(log, "[OK] cargo already available")

# ── Final verification ────────────────────────────────────────
node_final = utils.find_node_safe()
if not node_final:
    utils.fail(log, "Node.js installation did not produce a usable node executable")
if utils.run_allow_fail(log, root, cfg, [node_final, "--version"]).returncode != 0:
    utils.fail(log, "Node.js at known path is not working after install")
if utils.run_allow_fail(log, root, cfg, ["cargo", "--version"]).returncode != 0:
    # cargo may still not be on PATH — check known path too
    cargo_known = str(Path.home() / ".cargo" / "bin" / "cargo.exe")
    if not Path(cargo_known).exists() or utils.run_allow_fail(log, root, cfg, [cargo_known, "--version"]).returncode != 0:
        utils.fail(log, "Rust installation did not produce a usable cargo executable")
if not utils.find_vcvars64(root, cfg, log):
    utils.fail(log, "VS developer environment could not be discovered after installation")

ms = utils.stage_timer_end(root, "1_prereqs", start)
utils.write_marker(root, "01_prereqs.ok")
utils.log_line(log, f"[OK] Stage 1 complete in {ms} ms")
