"""
Scale Up v14 - deploy/3_llm.py
Optional LLM endpoint validation and runtime settings file generation.

Called by deploy.bat as a direct file path:
    python.exe deploy\3_llm.py --root <pack_root>
"""
import urllib.request
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import utils

args = utils.parse_common_args()
root, cfg, log = utils.setup(args)
start = utils.stage_timer_start()

utils.log_line(log, "[INFO] Stage 3: optional LLM validation and runtime settings")

settings_root = root / cfg["paths"]["settings_root"]
utils.ensure_dir(settings_root)

llm  = cfg["llm"]
mode = llm["mode"].lower()

if mode not in ("none", "openai_compatible"):
    utils.fail(log, f"Unsupported LLM mode: {mode}")

if mode == "openai_compatible":
    endpoint = llm["endpoint"]
    if llm.get("require_local_endpoint", True):
        if not (endpoint.startswith("http://127.0.0.1") or
                endpoint.startswith("http://localhost")):
            utils.fail(log, "Configured endpoint is not local; local endpoint is required by policy")
    try:
        with urllib.request.urlopen(
            endpoint.rstrip("/") + "/models",
            timeout=llm["timeout_seconds"]
        ) as resp:
            if resp.status >= 400:
                utils.fail(log, f"LLM endpoint returned HTTP {resp.status}")
        utils.log_line(log, f"[OK] Local LLM endpoint reachable: {endpoint}")
    except Exception as ex:
        if not llm.get("allow_no_llm_mode", True):
            utils.fail(log, f"LLM endpoint validation failed: {ex}")
        utils.log_line(log, f"[WARN] LLM endpoint not reachable, continuing in no-LLM mode: {ex}")
        mode = "none"

runtime_settings = {
    "app_name": cfg["app"]["name"],
    "llm": {
        "mode": mode,
        "provider": llm["provider"],
        "endpoint": llm["endpoint"] if mode != "none" else "",
        "model": llm["model"]
    },
    "agentic_prompts": {
        "enabled": bool(cfg["settings"]["agentic_prompts_default_enabled"]),
        "path": cfg["settings"]["agentic_prompts_path"],
        "optional": bool(cfg["settings"]["agentic_prompts_optional"]),
        "slots": cfg["settings"]["agentic_prompt_slots"]
    }
}
utils.dump_json(settings_root / "app_runtime.json", runtime_settings)
utils.log_line(log, f"[OK] app_runtime.json written (llm mode: {mode})")

# Write empty agentic prompts scaffold if absent
agentic_path = root / cfg["settings"]["agentic_prompts_path"]
if cfg["settings"]["allow_agentic_prompts"] and not agentic_path.exists():
    utils.dump_json(agentic_path, {
        "enabled": False,
        "slots": {
            "planner":   "",
            "extractor": "",
            "composer":  "",
            "verifier":  ""
        },
        "notes": ("Optional bounded prompt overrides. "
                  "Keep empty unless intentional controlled prompt customization is wanted.")
    })
    utils.log_line(log, "[OK] agentic_prompts.json scaffold written")

ms = utils.stage_timer_end(root, "3_llm", start)
utils.write_marker(root, "03_llm.ok")
utils.log_line(log, f"[OK] Stage 3 complete in {ms} ms")
