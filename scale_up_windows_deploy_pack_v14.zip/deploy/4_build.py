"""
Scale Up v14 - deploy/4_build.py
Scaffold source files from manifest, npm install, and Tauri release build.

Merges v8's stage4_scaffold + stage5_build into one idempotent step.

Called by deploy.bat as a direct file path:
    python.exe deploy\4_build.py --root <pack_root>
"""
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import utils

args = utils.parse_common_args()
root, cfg, log = utils.setup(args)
start = utils.stage_timer_start()

utils.log_line(log, "[INFO] Stage 4: scaffold source files + build desktop application")

app_root = root / cfg["paths"]["app_root"]
artifacts_dir = root / cfg["paths"]["artifacts_root"]
utils.ensure_dir(artifacts_dir)
utils.refresh_path(root, cfg)

# ── 1/4 Scaffold ──────────────────────────────────────────────
utils.log_line(log, "[...] 1/4 Scaffolding source files...")

manifest_path = root / "scaffolds" / "scaffold_files.json"
if not manifest_path.exists():
    utils.fail(log, f"scaffold_files.json not found at {manifest_path}")

manifest = utils.load_json(manifest_path)
files = manifest["files"]

# ── Tauri version map ─────────────────────────────────────────
# Inject exact Tauri versions from config into any scaffold file
# that contains the version placeholders. This ensures the scaffold
# never carries stale or wrong versions — config.json is the one
# source of truth.
tv = cfg["versions"]["tauri"]
tauri_crate       = tv["tauri_crate"]
tauri_build_crate = tv["tauri_build_crate"]
tauri_api_npm     = tv["tauri_api_npm"]
tauri_cli_npm     = tv["tauri_cli_npm"]

for entry in files:
    p = entry["path"]
    if p.endswith("src-tauri/Cargo.toml"):
        entry["content"] = (
            "[package]\n"
            f"name = \"scale-up-app\"\n"
            f"version = \"0.9.0\"\n"
            f"edition = \"2021\"\n"
            f"\n"
            f"[build-dependencies]\n"
            f"tauri-build = {{ version = \"={tauri_build_crate}\", features = [] }}\n"
            f"\n"
            f"[dependencies]\n"
            f"tauri = {{ version = \"={tauri_crate}\", features = [] }}\n"
            f"serde = {{ version = \"1\", features = [\"derive\"] }}\n"
            f"serde_json = \"1\"\n"
            f"\n"
            f"[features]\n"
            f"custom-protocol = [\"tauri/custom-protocol\"]\n"
        )
        utils.log_line(log, f"[OK] Cargo.toml pinned: tauri={tauri_crate}  tauri-build={tauri_build_crate}")
    elif p.endswith("package.json"):
        import json as _json
        pkg = _json.loads(entry["content"])
        pkg["devDependencies"]["@tauri-apps/api"] = tauri_api_npm
        pkg["devDependencies"]["@tauri-apps/cli"] = tauri_cli_npm
        entry["content"] = _json.dumps(pkg, indent=2) + "\n"
        utils.log_line(log, f"[OK] package.json pinned: @tauri-apps/api={tauri_api_npm}  @tauri-apps/cli={tauri_cli_npm}")

import base64 as _base64

seen = set()
for entry in files:
    rel = entry["path"]
    if rel in seen:
        raise SystemExit(f"Duplicate scaffold target path: {rel}")
    seen.add(rel)
    target = root / rel
    utils.ensure_dir(target.parent)
    if entry.get("encoding") == "base64":
        target.write_bytes(_base64.b64decode(entry["content"]))
    else:
        target.write_text(entry["content"], encoding="utf-8", newline="\n")

utils.log_line(log, f"[OK] Scaffolded {len(files)} files")

if not app_root.exists():
    utils.fail(log, f"App root does not exist after scaffold: {app_root}")

# ── Preflight: validate Cargo.toml versions before cargo ever runs ──────
# Catches bad version patterns immediately rather than letting cargo fail
# deep in the build with a confusing resolver error.
cargo_toml_path = app_root / "src-tauri" / "Cargo.toml"
if cargo_toml_path.exists():
    cargo_text = cargo_toml_path.read_text(encoding="utf-8")
    tv = cfg["versions"]["tauri"]
    bad_patterns = [
        ("~2.10", "tauri-build ~2.10 does not exist on crates.io (tauri-build is at 2.5.x)"),
        ("~2.9",  "tauri-build ~2.9 does not exist on crates.io"),
        ("~2.8",  "tauri-build ~2.8 does not exist on crates.io"),
    ]
    for pattern, reason in bad_patterns:
        if f"tauri-build" in cargo_text and pattern in cargo_text:
            utils.fail(log, f"[PREFLIGHT] Invalid Cargo.toml: {reason}. "
                            f"Expected tauri-build={tv['tauri_build_crate']}. "
                            f"Fix config.json versions.tauri.tauri_build_crate.")
    # Verify expected exact pins are present
    expected_tauri       = f"={tv['tauri_crate']}"
    expected_tauri_build = f"={tv['tauri_build_crate']}"
    if expected_tauri not in cargo_text:
        utils.fail(log, f"[PREFLIGHT] Cargo.toml does not contain tauri={tv['tauri_crate']}. "
                        f"Scaffold version injection may have failed.")
    if expected_tauri_build not in cargo_text:
        utils.fail(log, f"[PREFLIGHT] Cargo.toml does not contain tauri-build={tv['tauri_build_crate']}. "
                        f"Scaffold version injection may have failed.")
    utils.log_line(log, f"[OK] Preflight: Cargo.toml version pins verified")
else:
    utils.fail(log, "src-tauri/Cargo.toml missing after scaffold")

# Remove stale package-lock.json and node_modules so npm resolves the
# newly scaffolded package.json from scratch.  Without this, npm install
# re-uses the old lockfile and node_modules from a previous run — which
# can keep a mismatched @tauri-apps/* version even after package.json changes.
lock = app_root / "package-lock.json"
if lock.exists():
    lock.unlink()
    utils.log_line(log, "[OK] Removed stale package-lock.json (will re-resolve)")
nm = app_root / "node_modules"
if nm.exists():
    import shutil as _shutil
    _shutil.rmtree(nm)
    utils.log_line(log, "[OK] Removed stale node_modules (will re-install)")

# ── 2/4 npm install ───────────────────────────────────────────
utils.log_line(log, "[...] 2/4 npm install...")
npm_cmd = utils.find_npm()
if cfg["build"]["run_npm_install"]:
    utils.run(log, root, cfg, [npm_cmd, "install"], cwd=app_root)
    utils.log_line(log, "[OK] npm install complete")

# ── 3/4 Frontend build ────────────────────────────────────────
utils.log_line(log, "[...] 3/4 npm run build (frontend)...")
utils.run(log, root, cfg, [npm_cmd, "run", "build"], cwd=app_root)
utils.log_line(log, "[OK] Frontend build complete")

# ── 4/4 Tauri release build ───────────────────────────────────
if cfg["build"]["run_tauri_build"]:
    utils.log_line(log, "[...] 4/4 Tauri release build...")
    utils.check_disk_space(4.0, root)

    vcvars64 = utils.find_vcvars64(root, cfg, log)
    if not vcvars64:
        utils.fail(log, "vcvars64.bat could not be discovered before Tauri build")

    # Re-verify SDK + linker before cargo runs — catches machines where
    # 01_prereqs.ok was pre-set manually or SDK was damaged after Stage 1.
    utils.verify_vs_env(log, root, cfg, vcvars64)

    npm_quoted = f'"{npm_cmd}"'
    utils.run_in_vs_env(log, root, cfg, vcvars64,
                        f'{npm_quoted} run tauri:build',
                        cwd=app_root)
    utils.log_line(log, "[OK] Tauri release build complete")

# ── Copy artifacts ────────────────────────────────────────────
bundle_dir = app_root / "src-tauri" / "target" / "release" / "bundle"
if bundle_dir.exists():
    for child in bundle_dir.rglob("*"):
        if child.is_file():
            rel = child.relative_to(bundle_dir)
            target = artifacts_dir / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(child, target)
    utils.log_line(log, f"[OK] Artifacts copied to {artifacts_dir}")
else:
    utils.fail(log, "Bundle directory not found after Tauri build")

ms = utils.stage_timer_end(root, "4_build", start)
utils.write_marker(root, "04_build.ok")
utils.log_line(log, f"[OK] Stage 4 complete in {ms} ms")
