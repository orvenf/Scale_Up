"""
Scale Up v14 - deploy/utils.py
Shared utilities for all deploy stages.

Execution model (adapted from BoreholeIQ v2 R27 — battle-tested):
  - Stages are called as direct file paths, NOT as Python -m modules
  - Every stage does sys.path.insert(0, deploy_dir) so this import always works
  - --root is the only required argument; config and log are derived from it
  - All state written to runtime/state/ inside the pack root
  - Full SSL fallback for corporate/fresh-machine cert stores
  - stage_timer_end() always creates its parent dir before writing (v8 bug fix)
"""
import argparse
import hashlib
import json
import logging
import os
import shutil
import subprocess
import sys
import time
import urllib.request
from datetime import datetime
from pathlib import Path


# ── Argument parsing ──────────────────────────────────────────
def parse_common_args():
    """All stages take only --root.  Config and log are derived from it."""
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--root", required=True)
    args, _ = parser.parse_known_args()
    return args


def root_path(args) -> Path:
    return Path(args.root).resolve()


def load_config(root: Path) -> dict:
    with open(root / "deploy" / "config.json", "r", encoding="utf-8") as f:
        return json.load(f)


# ── Derived paths (set up after first call to setup()) ────────
_ROOT: Path | None = None
_CFG:  dict | None = None
_LOG:  Path | None = None
_log:  logging.Logger | None = None


def setup(args) -> tuple[Path, dict, Path]:
    """
    Call once at the top of each stage:
        root, cfg, log = utils.setup(args)
    Returns (root_path, config_dict, log_file_path).
    Also configures the module-level logger.
    """
    global _ROOT, _CFG, _LOG, _log
    _ROOT = root_path(args)
    _CFG  = load_config(_ROOT)
    _LOG  = _ROOT / _CFG["paths"]["logs_root"] / "deploy.log"
    _LOG.parent.mkdir(parents=True, exist_ok=True)
    _log  = _setup_logging(_LOG)
    init_dirs(_ROOT, _CFG)
    return _ROOT, _CFG, _LOG


# ── Logging ───────────────────────────────────────────────────
_LOG_FMT = "%(asctime)s [%(levelname)-5s] %(message)s"


def _safe_stream():
    """Return a stdout stream safe for Unicode on Windows cp1252."""
    import io
    try:
        return io.TextIOWrapper(
            sys.stdout.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )
    except Exception:
        return sys.stdout


def _setup_logging(log_path: Path) -> logging.Logger:
    logger = logging.getLogger("scaleup")
    if logger.handlers:
        return logger
    logger.setLevel(logging.DEBUG)
    ch = logging.StreamHandler(_safe_stream())
    ch.setFormatter(logging.Formatter(_LOG_FMT, "%H:%M:%S"))
    logger.addHandler(ch)
    fh = logging.FileHandler(str(log_path), encoding="utf-8", errors="replace")
    fh.setFormatter(logging.Formatter(_LOG_FMT, "%H:%M:%S"))
    logger.addHandler(fh)
    return logger


def log_line(log_path, message: str):
    """Direct log write — used by stages that call log_line(log, ...) explicitly."""
    stamp = time.strftime("%Y-%m-%d %H:%M:%S")
    Path(log_path).parent.mkdir(parents=True, exist_ok=True)
    with open(log_path, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"[{stamp}] {message}\n")
    print(message)


# Convenience wrappers (use after setup())
def banner(text):
    print(f"\n{'=' * 64}\n  {text}\n  Started: {datetime.now():%Y-%m-%d %H:%M:%S}\n{'=' * 64}")

def header(text):
    print(f"\n{'-' * 64}\n  [{datetime.now():%H:%M:%S}] {text}\n{'-' * 64}")

def ok(msg):    _log and _log.info(f"[OK]   {msg}")  or print(f"[OK]   {msg}")
def fail(log_path, msg, code=1):
    log_line(log_path, f"[FAIL] {msg}")
    raise SystemExit(code)
def warn(msg):  _log and _log.warning(f"[WARN] {msg}") or print(f"[WARN] {msg}")
def info(msg):  _log and _log.info(f"[...] {msg}")   or print(f"[...] {msg}")
def skip(msg):  _log and _log.info(f"[SKIP] {msg}")  or print(f"[SKIP] {msg}")


# ── Directory helpers ─────────────────────────────────────────
def ensure_dir(path: Path):
    path.mkdir(parents=True, exist_ok=True)


def init_dirs(root: Path, cfg: dict):
    for key in ["downloads_root", "artifacts_root", "settings_root", "state_root", "logs_root"]:
        ensure_dir(root / cfg["paths"][key])
    ensure_dir(root / "workspace")


# ── JSON helpers ──────────────────────────────────────────────
def load_json(path: Path) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def dump_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ── Disk check ────────────────────────────────────────────────
def check_disk_space(required_gb: float, path=None):
    target = str(path or "C:\\")
    try:
        _, _, free = shutil.disk_usage(target)
        free_gb = free / (1024 ** 3)
        if free_gb < required_gb:
            raise RuntimeError(
                f"Insufficient disk: {free_gb:.1f} GB free, need {required_gb:.1f} GB"
            )
        info(f"Disk OK: {free_gb:.1f} GB free")
    except OSError:
        warn(f"Could not check disk space on {target}")


# ── SSL context with fallback ─────────────────────────────────
_ssl_fallback_ctx = None


def _get_ssl_context(log_path=None):
    global _ssl_fallback_ctx
    if _ssl_fallback_ctx is not None:
        return _ssl_fallback_ctx
    import ssl
    try:
        ctx = ssl.create_default_context()
        _ssl_fallback_ctx = ctx
        return ctx
    except Exception:
        pass
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.set_default_verify_paths()
        _ssl_fallback_ctx = ctx
        return ctx
    except Exception:
        pass
    # FIX-SEC-001: Refuse to proceed without certificate verification.
    # Previous versions fell back to CERT_NONE which silently disabled TLS.
    msg = ("[FATAL] SSL certificate verification unavailable. "
           "Cannot proceed with downloads. Install system CA certificates or "
           "set SSL_CERT_FILE environment variable to a valid CA bundle.")
    log_path and log_line(log_path, msg) or print(msg)
    raise RuntimeError(msg)


def _download_with_context(url: str, dest: Path, ctx, log_path=None):
    req = urllib.request.Request(url, headers={"User-Agent": "ScaleUpDeploy/9.0"})
    with urllib.request.urlopen(req, context=ctx, timeout=120) as resp, \
         open(str(dest), "wb") as fout:
        shutil.copyfileobj(resp, fout)


# ── Download with retry + SSL fallback ───────────────────────
def download_file(log_path, root: Path, cfg: dict, url: str, dest: Path, expected_sha256: str = ""):
    ensure_dir(dest.parent)
    retries = int(cfg["install"].get("download_retries", 3))
    backoff  = int(cfg["install"].get("download_backoff_seconds", 2))
    # Offline cache check
    cache_dir = root / cfg["paths"]["downloads_root"]
    cached = cache_dir / dest.name
    if cached.exists() and cached.stat().st_size > 1024 and cached != dest:
        log_line(log_path, f"[CACHE] {dest.name}")
        shutil.copy2(str(cached), str(dest))
        return dest

    last_error = None
    tmp = dest.with_suffix(dest.suffix + ".part")

    for attempt in range(1, retries + 1):
        try:
            if tmp.exists():
                tmp.unlink()
            log_line(log_path, f"[GET ] {url} -> {dest.name} (attempt {attempt}/{retries})")
            try:
                urllib.request.urlretrieve(url, str(tmp))
            except Exception as e:
                if "CERTIFICATE_VERIFY_FAILED" in str(e) or "SSL" in str(e):
                    # FIX-SEC-001: Use verified fallback context, never CERT_NONE
                    log_line(log_path, "[WARN] SSL cert issue; retrying with system CA bundle")
                    ctx = _get_ssl_context(log_path)
                    _download_with_context(url, tmp, ctx, log_path)
                else:
                    raise
            if not tmp.exists() or tmp.stat().st_size < 1024:
                raise RuntimeError(f"Downloaded file too small or missing: {dest.name}")
            if expected_sha256:
                actual = _sha256(tmp)
                if actual.lower() != expected_sha256.lower():
                    raise RuntimeError(f"SHA256 mismatch for {dest.name}")
            tmp.replace(dest)
            # Save to cache
            if dest != cached:
                cache_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy2(str(dest), str(cached))
            log_line(log_path, f"[OK ] Downloaded: {dest.name}")
            return dest
        except Exception as ex:
            last_error = ex
            log_line(log_path, f"[WARN] Attempt {attempt} failed: {ex}")
            if tmp.exists():
                tmp.unlink()
            if attempt < retries:
                time.sleep(backoff * attempt)

    fail(log_path, f"Failed to download after {retries} attempts: {url}  last error: {last_error}")


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


# ── PATH management ───────────────────────────────────────────
def refresh_path(root: Path, cfg: dict):
    """Refresh os.environ PATH from registry after tool installs."""
    try:
        import winreg
        m = winreg.OpenKey(
            winreg.HKEY_LOCAL_MACHINE,
            r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment"
        )
        mp = winreg.QueryValueEx(m, "Path")[0]
        winreg.CloseKey(m)
        try:
            u = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Environment")
            up = winreg.QueryValueEx(u, "Path")[0]
            winreg.CloseKey(u)
        except Exception:
            up = ""
        os.environ["PATH"] = mp + (";" + up if up else "")
    except Exception:
        pass
    # Inject known tool paths unconditionally — covers fresh installs where
    # the new directory isn't in this process's PATH snapshot yet.
    for p in [
        r"C:\Program Files\nodejs",
        str(Path.home() / ".cargo" / "bin"),
        r"C:\Python314",
        r"C:\Python313",
        r"C:\Python312",
        str(Path.home() / "AppData" / "Local" / "Programs" / "Python" / "Python314"),
        str(Path.home() / "AppData" / "Local" / "Programs" / "Python" / "Python313"),
        str(Path.home() / "AppData" / "Local" / "Programs" / "Python" / "Python312"),
    ]:
        if p and Path(p).exists() and p not in os.environ.get("PATH", ""):
            os.environ["PATH"] = p + ";" + os.environ.get("PATH", "")


# ── base_env — enriched env for subprocesses ─────────────────
def base_env(root: Path, cfg: dict) -> dict:
    refresh_path(root, cfg)
    env = os.environ.copy()
    npm_cache  = root / cfg["paths"]["downloads_root"] / ".." / cfg["build"]["npm_cache_subdir"]
    cargo_home = root / cfg["paths"]["downloads_root"] / ".." / cfg["build"]["cargo_home_subdir"]
    ensure_dir(npm_cache)
    ensure_dir(cargo_home)
    cargo_home_resolved = cargo_home.resolve()
    env["npm_config_cache"] = str(npm_cache.resolve())
    env["CARGO_HOME"]       = str(cargo_home_resolved)

    # Add CARGO_HOME/bin to PATH so cargo.exe is found when rustup was pointed
    # at a non-default CARGO_HOME (pack-local dir instead of ~/.cargo).
    # Without this, `cargo build` inside run_in_vs_env can't find cargo.exe.
    cargo_bin = str(cargo_home_resolved / "bin")
    if cargo_bin not in env.get("PATH", ""):
        env["PATH"] = cargo_bin + ";" + env.get("PATH", "")

    jobs = int(cfg["build"].get("cargo_jobs", 0) or 0)
    if jobs > 0:
        env["CARGO_BUILD_JOBS"] = str(jobs)
    return env


# ── Tool finders ─────────────────────────────────────────────
_NODE_KNOWN_PATHS = [
    r"C:\Program Files\nodejs\node.exe",
    r"C:\Program Files (x86)\nodejs\node.exe",
]

def find_node() -> str:
    # Check known install paths first — shutil.which misses them when PATH
    # hasn't been refreshed in the current process after a fresh MSI install.
    for c in _NODE_KNOWN_PATHS:
        if Path(c).exists():
            return c
    found = shutil.which("node")
    if found:
        return found
    raise RuntimeError("node not found — check PATH or restart deployment")


def find_node_safe() -> str | None:
    """Like find_node() but returns None instead of raising. Use for probes."""
    try:
        return find_node()
    except RuntimeError:
        return None


def find_npm() -> str:
    for c in [r"C:\Program Files\nodejs\npm.cmd",
              r"C:\Program Files\nodejs\npm.exe"]:
        if Path(c).exists():
            return c
    found = shutil.which("npm")
    if found:
        return found
    raise RuntimeError("npm not found — check PATH or restart deployment")


def find_npx() -> str:
    for c in [r"C:\Program Files\nodejs\npx.cmd",
              r"C:\Program Files\nodejs\npx.exe"]:
        if Path(c).exists():
            return c
    found = shutil.which("npx")
    if found:
        return found
    npm = Path(find_npm())
    for c in [npm.parent / "npx.cmd", npm.parent / "npx.exe"]:
        if c.exists():
            return str(c)
    raise RuntimeError("npx not found")


# ── vswhere / vcvars64 ────────────────────────────────────────
def find_vswhere(root: Path, cfg: dict, log_path) -> Path | None:
    candidates = [
        Path(r"C:\Program Files (x86)\Microsoft Visual Studio\Installer\vswhere.exe"),
        Path(r"C:\Program Files\Microsoft Visual Studio\Installer\vswhere.exe"),
        root / cfg["paths"]["downloads_root"] / "vswhere.exe",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


def download_vswhere_if_needed(root: Path, cfg: dict, log_path) -> Path | None:
    vswhere = find_vswhere(root, cfg, log_path)
    if vswhere:
        return vswhere
    dest = root / cfg["paths"]["downloads_root"] / "vswhere.exe"
    sha = cfg["hashes"].get("vswhere_sha256", "")
    try:
        download_file(log_path, root, cfg, cfg["urls"]["vswhere"], dest, sha)
    except Exception as e:
        log_line(log_path, f"[WARN] vswhere download failed: {e}")
    return dest if dest.exists() else None


def find_vcvars64_by_registry(log_path, root: Path, cfg: dict) -> Path | None:
    try:
        import winreg
        for hive in [winreg.HKEY_LOCAL_MACHINE]:
            for key in [
                r"SOFTWARE\Microsoft\VisualStudio\SxS\VS7",
                r"SOFTWARE\WOW6432Node\Microsoft\VisualStudio\SxS\VS7",
            ]:
                for ver in ["17.0", "18.0", "16.0"]:
                    try:
                        k = winreg.OpenKey(hive, key)
                        path = winreg.QueryValueEx(k, ver)[0]
                        winreg.CloseKey(k)
                        candidate = Path(path) / "VC" / "Auxiliary" / "Build" / "vcvars64.bat"
                        if candidate.exists():
                            return candidate
                    except Exception:
                        pass
    except ImportError:
        pass
    return None


def find_vcvars64(root: Path, cfg: dict, log_path) -> Path | None:
    vswhere = find_vswhere(root, cfg, log_path)
    if vswhere:
        proc = run_allow_fail(log_path, root, cfg, [
            str(vswhere), "-latest", "-products", "*",
            "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
            "-property", "installationPath"
        ])
        install_path = (proc.stdout or "").strip()
        if install_path:
            candidate = Path(install_path) / "VC" / "Auxiliary" / "Build" / "vcvars64.bat"
            if candidate.exists():
                return candidate
    return find_vcvars64_by_registry(log_path, root, cfg)


# ── Windows SDK + linker environment verification ────────────
def verify_vs_env(log_path, root: Path, cfg: dict, vcvars_path: Path) -> None:
    """
    Three-gate check that the VS environment is actually usable for Rust/Tauri.

    Gate A — kernel32.lib exists on the resolved SDK lib path.
    Gate B — link.exe is reachable inside the VS env.
    Gate C — A tiny C compile+link smoke test succeeds end-to-end.

    Variable capture uses a temp batch file that writes env vars to a text file
    AFTER vcvars64.bat has run — avoiding the cmd.exe parse-time expansion
    problem where %VAR% in a chained && command is expanded before vcvars runs.
    """
    import tempfile

    log_line(log_path, "[...] Verifying Windows SDK + linker environment...")

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path   = Path(tmp)
        env_file   = tmp_path / "vs_env.txt"
        probe_bat  = tmp_path / "probe.bat"
        src_c      = tmp_path / "t.c"
        out_exe    = tmp_path / "t.exe"

        # Write a batch file that:
        # 1. Calls vcvars64.bat to set up the VS environment
        # 2. Writes the SDK variables to a text file (AFTER expansion)
        # 3. Compiles a trivial C program to smoke-test the linker
        # Using a .bat file sidesteps the parse-time %VAR% expansion issue
        # entirely — each line is parsed and expanded fresh after vcvars runs.
        probe_bat.write_text(
            f'@echo off\r\n'
            f'call "{vcvars_path}" >nul 2>&1\r\n'
            f'echo WindowsSdkDir=%WindowsSdkDir%> "{env_file}"\r\n'
            f'echo WindowsSDKVersion=%WindowsSDKVersion%>> "{env_file}"\r\n'
            f'echo LIB=%LIB%>> "{env_file}"\r\n'
            f'echo int main(void){{return 0;}}> "{src_c}"\r\n'
            f'cl /nologo /W0 "{src_c}" /link /OUT:"{out_exe}" /NOLOGO\r\n'
            f'exit /b %ERRORLEVEL%\r\n',
            encoding="utf-8",
        )

        proc = subprocess.run(
            ["cmd", "/d", "/c", str(probe_bat)],
            capture_output=True, encoding="utf-8", errors="replace",
            env=base_env(root, cfg),
        )
        compile_out = ((proc.stdout or "") + (proc.stderr or "")).strip()

        # ── Gate A: parse the env file ────────────────────────
        sdk_dir = ""
        sdk_ver = ""
        lib_path = ""
        if env_file.exists():
            for line in env_file.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if line.startswith("WindowsSdkDir="):
                    sdk_dir = line.split("=", 1)[1].strip().rstrip("\\")
                elif line.startswith("WindowsSDKVersion="):
                    sdk_ver = line.split("=", 1)[1].strip().rstrip("\\")
                elif line.startswith("LIB="):
                    lib_path = line.split("=", 1)[1].strip()

        log_line(log_path, f"[...] WindowsSdkDir={sdk_dir!r}  WindowsSDKVersion={sdk_ver!r}")

        if not sdk_dir or not sdk_ver:
            fail(
                log_path,
                "[PREFLIGHT] Windows SDK not found in VS environment after vcvars64.bat ran.\n"
                "  WindowsSdkDir and/or WindowsSDKVersion are empty.\n"
                "  Fix: Open Visual Studio Installer → Build Tools → Modify\n"
                "       and ensure 'Windows 10/11 SDK' is checked under\n"
                "       'Desktop development with C++', then re-run deploy.bat."
            )

        # Locate kernel32.lib on the resolved path
        kernel32 = Path(sdk_dir) / "Lib" / sdk_ver / "um" / "x64" / "kernel32.lib"
        if not kernel32.exists():
            # Fallback: scan LIB entries
            found = False
            for entry in lib_path.split(";"):
                candidate = Path(entry.strip()) / "kernel32.lib"
                if candidate.exists():
                    found = True
                    log_line(log_path, f"[OK] kernel32.lib found via LIB: {candidate}")
                    break
            if not found:
                fail(
                    log_path,
                    f"[PREFLIGHT] kernel32.lib not found.\n"
                    f"  Expected: {kernel32}\n"
                    f"  LIB={lib_path[:300]}\n"
                    f"  Fix: Install/repair 'Windows 10/11 SDK' via Visual Studio Installer.\n"
                    f"  Then delete runtime\\state\\01_prereqs.ok and re-run deploy.bat."
                )
        else:
            log_line(log_path, f"[OK] kernel32.lib: {kernel32}")

        # ── Gate B+C: smoke test result ───────────────────────
        if proc.returncode != 0 or not out_exe.exists():
            fail(
                log_path,
                f"[PREFLIGHT] Linker smoke test FAILED (exit {proc.returncode}).\n"
                f"  cl.exe could not compile and link a trivial C program.\n"
                f"  Output: {compile_out[:600]}\n"
                f"  Fix: Run 'Visual Studio Installer → Build Tools → Repair'.\n"
                f"  Then delete runtime\\state\\01_prereqs.ok and re-run deploy.bat."
            )

    log_line(log_path, "[OK] Windows SDK verified and linker smoke test passed")

    log_line(log_path, "[OK] Linker smoke test passed — VS environment is usable")


def find_vcvars64_with_sdk(root: Path, cfg: dict, log_path) -> Path | None:
    """
    Like find_vcvars64, but the vswhere query also requires a Windows SDK component.
    Falls back to the basic find if the SDK-aware query returns nothing (handles
    machines where SDK is installed separately via the Windows SDK installer).
    """
    vswhere = find_vswhere(root, cfg, log_path)
    if vswhere:
        # Try strict query: requires both VC tools AND a Windows SDK component.
        for sdk_component in [
            "Microsoft.VisualStudio.Component.Windows11SDK.26100",
            "Microsoft.VisualStudio.Component.Windows11SDK.22621",
            "Microsoft.VisualStudio.Component.Windows10SDK.20348",
            "Microsoft.VisualStudio.Component.Windows10SDK.19041",
            "Microsoft.VisualStudio.Component.Windows10SDK",
        ]:
            proc = run_allow_fail(log_path, root, cfg, [
                str(vswhere), "-latest", "-products", "*",
                "-requires",
                "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                sdk_component,
                "-property", "installationPath"
            ])
            install_path = (proc.stdout or "").strip()
            if install_path:
                candidate = Path(install_path) / "VC" / "Auxiliary" / "Build" / "vcvars64.bat"
                if candidate.exists():
                    log_line(log_path, f"[OK] VS installation has VC tools + {sdk_component}")
                    return candidate

        # SDK-aware query found nothing — fall back to basic query and warn
        log_line(log_path,
            "[WARN] vswhere could not confirm Windows SDK component via strict query. "
            "Falling back to basic VC-tools-only query. "
            "The linker smoke test below will catch any missing SDK libs."
        )

    return find_vcvars64(root, cfg, log_path)


# ── Subprocess runners ────────────────────────────────────────
def run(log_path, root: Path, cfg: dict, cmd, cwd=None, env=None):
    merged = base_env(root, cfg)
    if env:
        merged.update(env)
    cmd = [str(c) for c in cmd]
    log_line(log_path, f"[CMD ] {' '.join(cmd)}")
    proc = subprocess.run(cmd, cwd=cwd, env=merged, capture_output=True,
                          encoding="utf-8", errors="replace")
    if proc.stdout:
        log_line(log_path, proc.stdout.strip()[-3000:])
    if proc.stderr:
        log_line(log_path, proc.stderr.strip()[-3000:])
    if proc.returncode != 0:
        fail(log_path, f"Command failed (exit {proc.returncode}): {' '.join(cmd)}", proc.returncode)
    return proc


def run_allow_fail(log_path, root: Path, cfg: dict, cmd, cwd=None, env=None):
    merged = base_env(root, cfg)
    if env:
        merged.update(env)
    cmd = [str(c) for c in cmd]
    log_line(log_path, f"[CMD?] {' '.join(cmd)}")
    try:
        proc = subprocess.run(cmd, cwd=cwd, env=merged, capture_output=True,
                              encoding="utf-8", errors="replace")
    except FileNotFoundError:
        # Executable not on PATH yet (e.g. freshly installed, PATH not refreshed in this process).
        # Return a synthetic failed result — callers check returncode, not exceptions.
        log_line(log_path, f"[CMD?] {cmd[0]}: not found on PATH (will install)")

        class _FakeProc:
            returncode = 1
            stdout = ""
            stderr = ""
        return _FakeProc()
    if proc.stdout:
        log_line(log_path, proc.stdout.strip()[-2000:])
    if proc.stderr:
        log_line(log_path, proc.stderr.strip()[-2000:])
    return proc


def capture_vs_env(root: Path, cfg: dict, vcvars_path: Path) -> dict:
    """
    Run vcvars64.bat in a child process, capture the resulting environment
    by writing all env vars to a temp file, and return them as a dict.

    This is the only reliable way to get the SDK LIB/INCLUDE/PATH values
    into a Python dict so they can be passed explicitly to subprocess calls.
    Relying on environment propagation through npm→tauri→cargo→rustc→link.exe
    is fragile — any intermediate process that uses setlocal or resets its
    env will drop LIB, causing LNK1181 even though vcvars ran successfully.
    """
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        env_out  = Path(tmp) / "vs_env_dump.txt"
        dump_bat = Path(tmp) / "dump_env.bat"

        # Write a batch file that:
        # 1. Calls vcvars64.bat to set up the full VS environment
        # 2. Dumps every environment variable to a text file
        # `set` with no arguments prints all env vars as KEY=VALUE lines
        dump_bat.write_text(
            f'@echo off\r\n'
            f'call "{vcvars_path}" >nul 2>&1\r\n'
            f'set > "{env_out}"\r\n',
            encoding="utf-8",
        )

        subprocess.run(
            ["cmd", "/d", "/c", str(dump_bat)],
            env=base_env(root, cfg),
            capture_output=True,
        )

        vs_env = {}
        if env_out.exists():
            for line in env_out.read_text(encoding="utf-8", errors="replace").splitlines():
                if "=" in line:
                    k, _, v = line.partition("=")
                    vs_env[k.strip()] = v.strip()

    return vs_env


def run_in_vs_env(log_path, root: Path, cfg: dict, vcvars_path: Path, command: str, cwd=None):
    """
    Run `command` inside the VS developer environment.

    Captures the full VS environment (LIB, INCLUDE, PATH, WindowsSdkDir, etc.)
    by running vcvars64.bat first and reading back all env vars via a temp file.
    Those vars are merged into base_env() and passed explicitly to Popen.

    This is more reliable than relying on env propagation through the process
    chain (npm → tauri-cli → cargo → rustc → link.exe), which can lose LIB
    if any intermediate process uses setlocal or resets its environment.

    Quoting contract — pass a STRING not a list to Popen:
      cmd /d /c "call "vcvars64.bat" && "npm.cmd" run tauri:build"
      cmd.exe strips the outermost quotes, leaving a valid call && chain.
      If we used a list, list2cmdline would double-escape internal quotes.
    """
    # Capture the full post-vcvars environment into the dict we pass to Popen.
    vs_env = capture_vs_env(root, cfg, vcvars_path)
    merged = base_env(root, cfg)
    # VS env takes precedence for SDK vars (LIB, INCLUDE, PATH, WindowsSdkDir…)
    merged.update(vs_env)
    # Re-apply our critical overrides on top (CARGO_HOME, npm cache, etc.)
    cargo_home = (root / cfg["paths"]["downloads_root"] / ".." / cfg["build"]["cargo_home_subdir"]).resolve()
    merged["CARGO_HOME"] = str(cargo_home)
    cargo_bin = str(cargo_home / "bin")
    if cargo_bin not in merged.get("PATH", ""):
        merged["PATH"] = cargo_bin + ";" + merged.get("PATH", "")

    cmd_str = f'cmd /d /c "call "{vcvars_path}" && {command}"'
    log_line(log_path, f"[CMD ] {cmd_str}")
    log_line(log_path, f"[...] LIB={merged.get('LIB','(not set)')[:120]}")

    proc = subprocess.Popen(
        cmd_str,
        cwd=str(cwd) if cwd else None,
        env=merged,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        encoding="utf-8",
        errors="replace",
    )
    for line in proc.stdout:
        log_line(log_path, line.rstrip("\n"))
    proc.wait()

    if proc.returncode != 0:
        fail(log_path, f"VS env command failed (exit {proc.returncode}): {command}", proc.returncode)
    return proc


# ── State markers ─────────────────────────────────────────────
def write_marker(root: Path, marker_name: str):
    marker = root / "runtime" / "state" / marker_name
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text("ok\n", encoding="utf-8")


# ── Stage timers ──────────────────────────────────────────────
def stage_timer_start() -> float:
    return time.perf_counter()


def stage_timer_end(root: Path, stage_name: str, start_time: float) -> int:
    ms = int((time.perf_counter() - start_time) * 1000)
    path = root / "runtime" / "logs" / "stage_timings.json"
    # Always create parent dir — this was the v8 production bug
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    data[stage_name] = ms
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return ms
